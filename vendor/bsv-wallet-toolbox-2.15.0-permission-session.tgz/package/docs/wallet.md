### API

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

#### Interfaces

| | | |
| --- | --- | --- |
| [AbortActionBatchResult](#interface-abortactionbatchresult) | [FindProvenTxReqsArgs](#interface-findproventxreqsargs) | [ServicesCallHistory](#interface-servicescallhistory) |
| [ActionBatchCommitAction](#interface-actionbatchcommitaction) | [FindProvenTxsArgs](#interface-findproventxsargs) | [SignActionResultX](#interface-signactionresultx) |
| [ActionBatchCommitInput](#interface-actionbatchcommitinput) | [FindSincePagedArgs](#interface-findsincepagedargs) | [SnapshotMerklePathResult](#interface-snapshotmerklepathresult) |
| [ActionBatchCommitMetadata](#interface-actionbatchcommitmetadata) | [FindStaleMerkleRootsArgs](#interface-findstalemerklerootsargs) | [SpentInputTransition](#interface-spentinputtransition) |
| [ActionBatchCommitPlan](#interface-actionbatchcommitplan) | [FindSyncStatesArgs](#interface-findsyncstatesargs) | [StatusForTxidResult](#interface-statusfortxidresult) |
| [ActionBatchFundingOutput](#interface-actionbatchfundingoutput) | [FindTransactionsArgs](#interface-findtransactionsargs) | [StorageActivateNoSendExpiryArgs](#interface-storageactivatenosendexpiryargs) |
| [ActionBatchManifest](#interface-actionbatchmanifest) | [FindTxLabelMapsArgs](#interface-findtxlabelmapsargs) | [StorageActivateNoSendExpiryResult](#interface-storageactivatenosendexpiryresult) |
| [ActionBatchPackItem](#interface-actionbatchpackitem) | [FindTxLabelsArgs](#interface-findtxlabelsargs) | [StorageAdminStats](#interface-storageadminstats) |
| [ActionBatchPlannedAction](#interface-actionbatchplannedaction) | [FindUsersArgs](#interface-findusersargs) | [StorageArmNoSendExpiryArgs](#interface-storagearmnosendexpiryargs) |
| [ActionBatchPlannerState](#interface-actionbatchplannerstate) | [GenerateChangeSdkChangeInput](#interface-generatechangesdkchangeinput) | [StorageCapabilities](#interface-storagecapabilities) |
| [AdminStatsResult](#interface-adminstatsresult) | [GenerateChangeSdkChangeOutput](#interface-generatechangesdkchangeoutput) | [StorageCreateActionResult](#interface-storagecreateactionresult) |
| [AggregatePostBeefTxResult](#interface-aggregatepostbeeftxresult) | [GenerateChangeSdkInput](#interface-generatechangesdkinput) | [StorageCreateTransactionSdkInput](#interface-storagecreatetransactionsdkinput) |
| [ArcConfig](#interface-arcconfig) | [GenerateChangeSdkOutput](#interface-generatechangesdkoutput) | [StorageCreateTransactionSdkOutput](#interface-storagecreatetransactionsdkoutput) |
| [ArcMinerGetTxData](#interface-arcminergettxdata) | [GenerateChangeSdkParams](#interface-generatechangesdkparams) | [StorageFeeModel](#interface-storagefeemodel) |
| [ArcSSEClientOptions](#interface-arcsseclientoptions) | [GenerateChangeSdkResult](#interface-generatechangesdkresult) | [StorageGetBeefOptions](#interface-storagegetbeefoptions) |
| [ArcSSEEvent](#interface-arcsseevent) | [GenerateChangeSdkStorageChange](#interface-generatechangesdkstoragechange) | [StorageIdentity](#interface-storageidentity) |
| [ArcadeLifecycleStatus](#interface-arcadelifecyclestatus) | [GetMerklePathResult](#interface-getmerklepathresult) | [StorageInternalizeActionResult](#interface-storageinternalizeactionresult) |
| [ArcadeRejectionClassification](#interface-arcaderejectionclassification) | [GetRawTxResult](#interface-getrawtxresult) | [StoragePrepareNoSendExpiryResult](#interface-storagepreparenosendexpiryresult) |
| [AuthId](#interface-authid) | [GetReqsAndBeefDetail](#interface-getreqsandbeefdetail) | [StorageProcessActionArgs](#interface-storageprocessactionargs) |
| [BaseBlockHeader](#interface-baseblockheader) | [GetReqsAndBeefResult](#interface-getreqsandbeefresult) | [StorageProcessActionResults](#interface-storageprocessactionresults) |
| [BeginActionBatchArgs](#interface-beginactionbatchargs) | [GetScriptHashHistory](#interface-getscripthashhistory) | [StorageProvenOrReq](#interface-storageprovenorreq) |
| [BeginActionBatchResult](#interface-beginactionbatchresult) | [GetScriptHashHistoryResult](#interface-getscripthashhistoryresult) | [StorageProviderOptions](#interface-storageprovideroptions) |
| [BitailsConfig](#interface-bitailsconfig) | [GetStatusForTxidsResult](#interface-getstatusfortxidsresult) | [StorageReaderOptions](#interface-storagereaderoptions) |
| [BitailsMerkleProof](#interface-bitailsmerkleproof) | [GetUtxoStatusDetails](#interface-getutxostatusdetails) | [StorageReaderWriterOptions](#interface-storagereaderwriteroptions) |
| [BlockHeader](#interface-blockheader) | [GetUtxoStatusResult](#interface-getutxostatusresult) | [StorageSyncReaderOptions](#interface-storagesyncreaderoptions) |
| [Brc177FundingCreateActionMetadata](#interface-brc177fundingcreateactionmetadata) | [GoChaintracksServiceClientOptions](#interface-gochaintracksserviceclientoptions) | [SyncCheckpoint](#interface-synccheckpoint) |
| [Brc177NoSendExpiry](#interface-brc177nosendexpiry) | [HeightRangeApi](#interface-heightrangeapi) | [SyncChunk](#interface-syncchunk) |
| [Brc177ProtectedCreateActionMetadata](#interface-brc177protectedcreateactionmetadata) | [HeightRanges](#interface-heightranges) | [SyncChunkTotals](#interface-syncchunktotals) |
| [BsvExchangeRate](#interface-bsvexchangerate) | [KeyPair](#interface-keypair) | [SyncError](#interface-syncerror) |
| [BulkFileDataCacheApi](#interface-bulkfiledatacacheapi) | [LiveBlockHeader](#interface-liveblockheader) | [SyncMap](#interface-syncmap) |
| [BulkFileDataManagerMergeResult](#interface-bulkfiledatamanagermergeresult) | [ManagedChangeBasketDefaults](#interface-managedchangebasketdefaults) | [SyncProofValidationStorage](#interface-syncproofvalidationstorage) |
| [BulkFileDataManagerOptions](#interface-bulkfiledatamanageroptions) | [ManagedChangePolicy](#interface-managedchangepolicy) | [TableActionBatch](#interface-tableactionbatch) |
| [BulkFileDataManagerStats](#interface-bulkfiledatamanagerstats) | [MerklePathNote](#interface-merklepathnote) | [TableActionBatchBlob](#interface-tableactionbatchblob) |
| [BulkFileDataValidationRequest](#interface-bulkfiledatavalidationrequest) | [MerkleRootValidator](#interface-merklerootvalidator) | [TableActionBatchOutput](#interface-tableactionbatchoutput) |
| [BulkFileDataValidationResult](#interface-bulkfiledatavalidationresult) | [MockChainBlockHeaderRow](#interface-mockchainblockheaderrow) | [TableCertificate](#interface-tablecertificate) |
| [BulkFileDataValidatorApi](#interface-bulkfiledatavalidatorapi) | [MockChainTransactionRow](#interface-mockchaintransactionrow) | [TableCertificateField](#interface-tablecertificatefield) |
| [BulkFileDataValidatorStats](#interface-bulkfiledatavalidatorstats) | [MockChainUtxoRow](#interface-mockchainutxorow) | [TableCertificateX](#interface-tablecertificatex) |
| [BulkFileDownloadBudgetApi](#interface-bulkfiledownloadbudgetapi) | [MonitorOptions](#interface-monitoroptions) | [TableCommission](#interface-tablecommission) |
| [BulkFileDownloadBudgetSnapshot](#interface-bulkfiledownloadbudgetsnapshot) | [NoSendExpiryLifecycleResult](#interface-nosendexpirylifecycleresult) | [TableMonitorEvent](#interface-tablemonitorevent) |
| [BulkHeaderFileInfo](#interface-bulkheaderfileinfo) | [NormalizedArcProviderConfig](#interface-normalizedarcproviderconfig) | [TableOutput](#interface-tableoutput) |
| [BulkHeaderFilesInfo](#interface-bulkheaderfilesinfo) | [OutPoint](#interface-outpoint) | [TableOutputBasket](#interface-tableoutputbasket) |
| [CanonicalFundingCandidate](#interface-canonicalfundingcandidate) | [OutputUtxoClassification](#interface-outpututxoclassification) | [TableOutputTag](#interface-tableoutputtag) |
| [CertOpsWallet](#interface-certopswallet) | [Paged](#interface-paged) | [TableOutputTagMap](#interface-tableoutputtagmap) |
| [Certifier](#interface-certifier) | [PendingSignAction](#interface-pendingsignaction) | [TableOutputX](#interface-tableoutputx) |
| [ChaintracksApi](#interface-chaintracksapi) | [PendingStorageInput](#interface-pendingstorageinput) | [TablePreparedBeef](#interface-tablepreparedbeef) |
| [ChaintracksAppendableFileApi](#interface-chaintracksappendablefileapi) | [PlannerOutput](#interface-planneroutput) | [TableProvenTx](#interface-tableproventx) |
| [ChaintracksAvailabilitySnapshotApi](#interface-chaintracksavailabilitysnapshotapi) | [PostBeefResult](#interface-postbeefresult) | [TableProvenTxReq](#interface-tableproventxreq) |
| [ChaintracksBulkDataStatsApi](#interface-chaintracksbulkdatastatsapi) | [PostBeefResultForTxidApi](#interface-postbeefresultfortxidapi) | [TableProvenTxReqDynamics](#interface-tableproventxreqdynamics) |
| [ChaintracksChainTrackerOptions](#interface-chaintrackschaintrackeroptions) | [PostReqsToNetworkDetails](#interface-postreqstonetworkdetails) | [TableSettings](#interface-tablesettings) |
| [ChaintracksClientApi](#interface-chaintracksclientapi) | [PostReqsToNetworkResult](#interface-postreqstonetworkresult) | [TableSyncState](#interface-tablesyncstate) |
| [ChaintracksDownloadOptions](#interface-chaintracksdownloadoptions) | [PostTxResultForTxid](#interface-posttxresultfortxid) | [TableTransaction](#interface-tabletransaction) |
| [ChaintracksFetchApi](#interface-chaintracksfetchapi) | [PostTxResultForTxidError](#interface-posttxresultfortxiderror) | [TableTxLabel](#interface-tabletxlabel) |
| [ChaintracksFetchOptions](#interface-chaintracksfetchoptions) | [PostTxsResult](#interface-posttxsresult) | [TableTxLabelMap](#interface-tabletxlabelmap) |
| [ChaintracksFsApi](#interface-chaintracksfsapi) | [PrepareActionBatchCommitResult](#interface-prepareactionbatchcommitresult) | [TableUser](#interface-tableuser) |
| [ChaintracksInfoApi](#interface-chaintracksinfoapi) | [PreparedBeefLookupResult](#interface-preparedbeeflookupresult) | [TaskPurgeParams](#interface-taskpurgeparams) |
| [ChaintracksPackageInfoApi](#interface-chaintrackspackageinfoapi) | [PreparedBeefOptions](#interface-preparedbeefoptions) | [TaskReviewUtxosPageResult](#interface-taskreviewutxospageresult) |
| [ChaintracksReadableFileApi](#interface-chaintracksreadablefileapi) | [PreparedBeefPolicy](#interface-preparedbeefpolicy) | [TrustSettings](#interface-trustsettings) |
| [ChaintracksServiceClientOptions](#interface-chaintracksserviceclientoptions) | [PreparedBeefPreparation](#interface-preparedbeefpreparation) | [TrxToken](#interface-trxtoken) |
| [ChaintracksSourceStatusApi](#interface-chaintrackssourcestatusapi) | [PreparedBeefRoot](#interface-preparedbeefroot) | [TscMerkleProofApi](#interface-tscmerkleproofapi) |
| [ChaintracksStorageApi](#interface-chaintracksstorageapi) | [PreparedBeefStorage](#interface-preparedbeefstorage) | [TxScriptOffsets](#interface-txscriptoffsets) |
| [ChaintracksStorageBaseOptions](#interface-chaintracksstoragebaseoptions) | [ProcessSyncChunkResult](#interface-processsyncchunkresult) | [UnlockScriptVerificationResult](#interface-unlockscriptverificationresult) |
| [ChaintracksStorageBulkFileApi](#interface-chaintracksstoragebulkfileapi) | [ProvenOrRawTx](#interface-provenorrawtx) | [UpdateProvenTxReqWithNewProvenTxArgs](#interface-updateproventxreqwithnewproventxargs) |
| [ChaintracksStorageIngestApi](#interface-chaintracksstorageingestapi) | [ProvenTransactionStatus](#interface-proventransactionstatus) | [UpdateProvenTxReqWithNewProvenTxResult](#interface-updateproventxreqwithnewproventxresult) |
| [ChaintracksStorageQueryApi](#interface-chaintracksstoragequeryapi) | [ProvenTxFromTxidResult](#interface-proventxfromtxidresult) | [UtxoReviewClassification](#interface-utxoreviewclassification) |
| [ChaintracksWritableFileApi](#interface-chaintrackswritablefileapi) | [ProvenTxReqHistory](#interface-proventxreqhistory) | [UtxoReviewDiagnostics](#interface-utxoreviewdiagnostics) |
| [CommitActionBatchByDigestArgs](#interface-commitactionbatchbydigestargs) | [ProvenTxReqHistorySummaryApi](#interface-proventxreqhistorysummaryapi) | [ValidateGenerateChangeSdkParamsResult](#interface-validategeneratechangesdkparamsresult) |
| [CommitActionBatchResult](#interface-commitactionbatchresult) | [ProvenTxReqNotify](#interface-proventxreqnotify) | [ValidatedBatchAction](#interface-validatedbatchaction) |
| [CommitNewTxResults](#interface-commitnewtxresults) | [ProviderCallHistory](#interface-providercallhistory) | [ValidatedMerklePathResult](#interface-validatedmerklepathresult) |
| [ContactRecord](#interface-contactrecord) | [PurgeParams](#interface-purgeparams) | [ValidatedPostBeefRequest](#interface-validatedpostbeefrequest) |
| [ContactSource](#interface-contactsource) | [PurgeResults](#interface-purgeresults) | [VerifyAndRepairBeefResult](#interface-verifyandrepairbeefresult) |
| [CreateActionResultX](#interface-createactionresultx) | [PutActionBatchBlobArgs](#interface-putactionbatchblobargs) | [WalletArgs](#interface-walletargs) |
| [DeactivedHeader](#interface-deactivedheader) | [PutActionBatchPackArgs](#interface-putactionbatchpackargs) | [WalletBalance](#interface-walletbalance) |
| [EntitySyncMap](#interface-entitysyncmap) | [RenewActionBatchResult](#interface-renewactionbatchresult) | [WalletServices](#interface-walletservices) |
| [EntityTimeStamp](#interface-entitytimestamp) | [ReorgResult](#interface-reorgresult) | [WalletServicesOptions](#interface-walletservicesoptions) |
| [ExactActionSpendCarrier](#interface-exactactionspendcarrier) | [ReproveHeaderResult](#interface-reproveheaderresult) | [WalletSettings](#interface-walletsettings) |
| [ExchangeRatesIoApi](#interface-exchangeratesioapi) | [ReproveProvenResult](#interface-reproveprovenresult) | [WalletSettingsManagerConfig](#interface-walletsettingsmanagerconfig) |
| [ExtendActionBatchArgs](#interface-extendactionbatchargs) | [ReqHistoryNote](#interface-reqhistorynote) | [WalletSigner](#interface-walletsigner) |
| [ExtendActionBatchResult](#interface-extendactionbatchresult) | [RequestSyncChunkArgs](#interface-requestsyncchunkargs) | [WalletStorage](#interface-walletstorage) |
| [ExtendedVerifiableCertificate](#interface-extendedverifiablecertificate) | [ResumeActionBatchArgs](#interface-resumeactionbatchargs) | [WalletStorageInfo](#interface-walletstorageinfo) |
| [FailedInputReconciliationResult](#interface-failedinputreconciliationresult) | [ResumeActionBatchResult](#interface-resumeactionbatchresult) | [WalletStorageProvider](#interface-walletstorageprovider) |
| [FiatExchangeRates](#interface-fiatexchangerates) | [ReviewActionResult](#interface-reviewactionresult) | [WalletStorageReader](#interface-walletstoragereader) |
| [FindCertificateFieldsArgs](#interface-findcertificatefieldsargs) | [ReviewHeightRangeResult](#interface-reviewheightrangeresult) | [WalletStorageSync](#interface-walletstoragesync) |
| [FindCertificatesArgs](#interface-findcertificatesargs) | [ReviewUtxoOutputsResult](#interface-reviewutxooutputsresult) | [WalletStorageSyncReader](#interface-walletstoragesyncreader) |
| [FindCommissionsArgs](#interface-findcommissionsargs) | [ScriptHashHistoryResponse](#interface-scripthashhistoryresponse) | [WalletStorageWriter](#interface-walletstoragewriter) |
| [FindForUserSincePagedArgs](#interface-findforusersincepagedargs) | [ScriptTemplateParamsBRC29](#interface-scripttemplateparamsbrc29) | [WalletTheme](#interface-wallettheme) |
| [FindMonitorEventsArgs](#interface-findmonitoreventsargs) | [ScriptTemplateUnlock](#interface-scripttemplateunlock) | [WalletToolboxWhatsOnChainConfig](#interface-wallettoolboxwhatsonchainconfig) |
| [FindOutputBasketsArgs](#interface-findoutputbasketsargs) | [ServiceCall](#interface-servicecall) | [WocChainInfo](#interface-wocchaininfo) |
| [FindOutputTagMapsArgs](#interface-findoutputtagmapsargs) | [ServiceCall](#interface-servicecall) | [WocHeader](#interface-wocheader) |
| [FindOutputTagsArgs](#interface-findoutputtagsargs) | [ServiceCallHistory](#interface-servicecallhistory) | [XValidCreateActionInput](#interface-xvalidcreateactioninput) |
| [FindOutputsArgs](#interface-findoutputsargs) | [ServiceCallHistoryCounts](#interface-servicecallhistorycounts) | [XValidCreateActionOutput](#interface-xvalidcreateactionoutput) |
| [FindPartialSincePagedArgs](#interface-findpartialsincepagedargs) | [ServiceToCall](#interface-servicetocall) |  |

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---

##### Interface: AbortActionBatchResult

```ts
export interface AbortActionBatchResult {
    aborted: boolean;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ActionBatchCommitAction

```ts
export interface ActionBatchCommitAction {
    reference: string;
    txid: TXIDHexString;
    rawTx?: number[] | Uint8Array;
    rawTxDigest?: string;
    lockingScriptDigests?: Array<string | undefined>;
    deriveLockingScripts?: boolean;
    plan: ActionBatchCommitPlan;
    metadata: ActionBatchCommitMetadata;
    commissionKeyOffset?: string;
}
```

See also: [ActionBatchCommitMetadata](./client.md#interface-actionbatchcommitmetadata), [ActionBatchCommitPlan](./client.md#interface-actionbatchcommitplan)

###### Property deriveLockingScripts

Version 2 derives the scripts identified above from rawTx.

```ts
deriveLockingScripts?: boolean
```

###### Property lockingScriptDigests

Content-addressed locking scripts aligned to plan.outputs for compact workspaces.

```ts
lockingScriptDigests?: Array<string | undefined>
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ActionBatchCommitInput

```ts
export interface ActionBatchCommitInput extends Omit<StorageCreateTransactionSdkInput, "sourceLockingScript"> {
    sourceLockingScript?: string;
}
```

See also: [StorageCreateTransactionSdkInput](./client.md#interface-storagecreatetransactionsdkinput)

###### Property sourceLockingScript

Version-1 manifests carry this value. Version-2 manifests derive it from
the proven source output and therefore omit it.

```ts
sourceLockingScript?: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ActionBatchCommitMetadata

```ts
export interface ActionBatchCommitMetadata {
    description: string;
    labels: string[];
    isNoSend: boolean;
    isDelayed: boolean;
    inputs: Validation.ValidCreateActionInput[];
    outputs: Validation.ValidCreateActionOutput[];
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ActionBatchCommitPlan

```ts
export interface ActionBatchCommitPlan extends Omit<StorageCreateActionResult, "inputs"> {
    inputs: ActionBatchCommitInput[];
}
```

See also: [ActionBatchCommitInput](./client.md#interface-actionbatchcommitinput), [StorageCreateActionResult](./client.md#interface-storagecreateactionresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ActionBatchFundingOutput

```ts
export interface ActionBatchFundingOutput extends TableOutput {
    sourceTransaction?: number[] | Uint8Array;
}
```

See also: [TableOutput](./storage.md#interface-tableoutput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ActionBatchManifest

```ts
export interface ActionBatchManifest {
    format?: 2;
    batchId: string;
    digest: string;
    actions: ActionBatchCommitAction[];
    inlineBlobs?: Record<string, number[] | Uint8Array>;
    blobChunks?: Record<string, string[]>;
    dependencyBeef?: number[] | Uint8Array;
    dependencyBeefDigest?: string;
    sendWith: TXIDHexString[];
    isDelayed: boolean;
}
```

See also: [ActionBatchCommitAction](./client.md#interface-actionbatchcommitaction)

###### Property blobChunks

Physical chunk digests for logical blobs larger than the provider's advertised blob limit.

```ts
blobChunks?: Record<string, string[]>
```

###### Property format

Omitted for the original manifest format.

```ts
format?: 2
```

###### Property inlineBlobs

Content-addressed blobs carried in the commit request when the batch is below the inline limit.

```ts
inlineBlobs?: Record<string, number[] | Uint8Array>
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ActionBatchPackItem

```ts
export interface ActionBatchPackItem {
    digest: string;
    bytes: number[] | Uint8Array;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ActionBatchPlannedAction

```ts
export interface ActionBatchPlannedAction {
    dcr: StorageCreateActionResult;
    consumedOutpoints: string[];
    commissionKeyOffset?: string;
}
```

See also: [StorageCreateActionResult](./client.md#interface-storagecreateactionresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ActionBatchPlannerState

```ts
export interface ActionBatchPlannerState {
    begin: BeginActionBatchResult;
    sharedBeef: Beef;
    reserved: Map<string, PlannerOutput>;
    explicit: Map<string, PlannerOutput>;
    staged: Map<string, PlannerOutput>;
    discardedStagedTxids: Set<string>;
    consumed: Set<string>;
    estimatedChangeCount: number;
}
```

See also: [BeginActionBatchResult](./client.md#interface-beginactionbatchresult), [PlannerOutput](./client.md#interface-planneroutput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: AdminStatsResult

```ts
export interface AdminStatsResult extends StorageAdminStats {
    servicesStats?: ServicesCallHistory;
    monitorStats?: ServicesCallHistory;
}
```

See also: [ServicesCallHistory](./client.md#interface-servicescallhistory), [StorageAdminStats](./storage.md#interface-storageadminstats)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: AggregatePostBeefTxResult

```ts
export interface AggregatePostBeefTxResult {
    txid: string;
    txidResults: sdk.PostTxResultForTxid[];
    status: AggregateStatus;
    vreq: PostReqsToNetworkDetails;
    successCount: number;
    doubleSpendCount: number;
    statusErrorCount: number;
    serviceErrorCount: number;
    competingTxs: string[];
}
```

See also: [PostReqsToNetworkDetails](./storage.md#interface-postreqstonetworkdetails), [PostTxResultForTxid](./client.md#interface-posttxresultfortxid)

###### Property competingTxs

Any competing double spend txids reported for this txid

```ts
competingTxs: string[]
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ArcConfig

Configuration options shared by ARC-compatible broadcasters.

```ts
export interface ArcConfig {
    apiKey?: string;
    httpClient?: HttpClient;
    deploymentId?: string;
    callbackUrl?: string;
    callbackToken?: string;
    headers?: Record<string, string>;
}
```

###### Property apiKey

Authentication token for the ARC API.

```ts
apiKey?: string
```

###### Property callbackToken

Access token sent to the configured notification callback.

```ts
callbackToken?: string
```

###### Property callbackUrl

Notification callback endpoint for proofs and double-spend notifications.

```ts
callbackUrl?: string
```

###### Property deploymentId

Deployment id sent in the XDeployment-ID header.

```ts
deploymentId?: string
```

###### Property headers

Additional request headers, snapshotted when the provider is constructed.

```ts
headers?: Record<string, string>
```

###### Property httpClient

The explicitly trusted HTTP adapter used to make provider requests.

```ts
httpClient?: HttpClient
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ArcMinerGetTxData

```ts
export interface ArcMinerGetTxData {
    status: number;
    title: string;
    blockHash: string;
    blockHeight: number;
    competingTxs: null | string[];
    extraInfo: string;
    merklePath: string;
    timestamp: string;
    txid: string;
    txStatus: string;
}
```

See also: [blockHash](./services.md#function-blockhash)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ArcSSEClientOptions

```ts
export interface ArcSSEClientOptions {
    baseUrl: string;
    callbackToken: string;
    arcApiKey?: string;
    onEvent: (event: ArcSSEEvent) => void | Promise<void>;
    onError?: (error: Error) => void | Promise<void>;
    lastEventId?: string;
    onLastEventIdChanged?: (lastEventId: string) => void | Promise<void>;
    maxEventBytes?: number;
    maxPendingEvents?: number;
    maxPendingBytes?: number;
    log?: (message: string) => void;
    EventSourceClass: any;
}
```

See also: [ArcSSEEvent](./services.md#interface-arcsseevent)

###### Property EventSourceClass

The react-native-sse EventSource class — passed in to avoid import from wallet-toolbox

```ts
EventSourceClass: any
```

###### Property arcApiKey

Server-level API key for Authorization header (from ArcConfig.apiKey)

```ts
arcApiKey?: string
```

###### Property baseUrl

Base URL of the Arcade instance (e.g. "https://arcade-us-1.bsvb.tech")

```ts
baseUrl: string
```

###### Property callbackToken

Stable per-wallet token matching the X-CallbackToken sent on broadcast

```ts
callbackToken: string
```

###### Property lastEventId

Initial lastEventId for catchup

```ts
lastEventId?: string
```

###### Property log

Optional fixed-message operational logger. The client is silent by default.

```ts
log?: (message: string) => void
```

###### Property maxEventBytes

Maximum UTF-8 bytes admitted for one status event. Default: 262144; maximum: 8388608.

```ts
maxEventBytes?: number
```

###### Property maxPendingBytes

Maximum aggregate bytes retained while earlier work commits. Default: 4194304; maximum: 67108864.

```ts
maxPendingBytes?: number
```

###### Property maxPendingEvents

Maximum received events retained while earlier work commits. Default: 64; maximum: 4096.

```ts
maxPendingEvents?: number
```

###### Property onError

Called when a connection or processing error occurs. Callback failures are contained.

```ts
onError?: (error: Error) => void | Promise<void>
```

###### Property onEvent

Called for each status event received; resolution acknowledges durable processing.

```ts
onEvent: (event: ArcSSEEvent) => void | Promise<void>
```
See also: [ArcSSEEvent](./services.md#interface-arcsseevent)

###### Property onLastEventIdChanged

Called after event processing and before lastEventId advances.

```ts
onLastEventIdChanged?: (lastEventId: string) => void | Promise<void>
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ArcSSEEvent

```ts
export interface ArcSSEEvent {
    txid: string;
    txStatus: string;
    timestamp: string;
    eventId?: string;
    status?: number;
    extraInfo?: string;
    blockHash?: string;
    blockHeight?: number;
    merklePath?: string;
}
```

See also: [blockHash](./services.md#function-blockhash)

###### Property eventId

Transport cursor attached by ArcSSEClient; not part of Arcade's JSON payload.

```ts
eventId?: string
```

###### Property extraInfo

Arcade's validator or network rejection detail.

```ts
extraInfo?: string
```

###### Property status

ARC rejection code supplied by Arcade for classifiable REJECTED events.

```ts
status?: number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ArcadeLifecycleStatus

```ts
export interface ArcadeLifecycleStatus {
    txStatus: string;
    status?: number;
    extraInfo?: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ArcadeRejectionClassification

```ts
export interface ArcadeRejectionClassification {
    terminal: boolean;
    inputConflict: boolean;
    reqStatus: "invalid" | "doubleSpend";
    reason: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: AuthId

```ts
export interface AuthId {
    identityKey: string;
    userId?: number;
    isActive?: boolean;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BaseBlockHeader

These are fields of 80 byte serialized header in order whose double sha256 hash is a block's hash value
and the next block's previousHash value.

All block hash values and merkleRoot values are 32 byte hex string values with the byte order reversed from the serialized byte order.

```ts
export interface BaseBlockHeader {
    version: number;
    previousHash: string;
    merkleRoot: string;
    time: number;
    bits: number;
    nonce: number;
}
```

###### Property bits

Block header bits value. Serialized length is 4 bytes.

```ts
bits: number
```

###### Property merkleRoot

Root hash of the merkle tree of all transactions in this block. Serialized length is 32 bytes.

```ts
merkleRoot: string
```

###### Property nonce

Block header nonce value. Serialized length is 4 bytes.

```ts
nonce: number
```

###### Property previousHash

Hash of previous block's block header. Serialized length is 32 bytes.

```ts
previousHash: string
```

###### Property time

Block header time value. Serialized length is 4 bytes.

```ts
time: number
```

###### Property version

Block header version value. Serialized length is 4 bytes.

```ts
version: number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BeginActionBatchArgs

```ts
export interface BeginActionBatchArgs {
    batchId: string;
    firstAction: Validation.ValidCreateActionArgs;
    firstActionOutputScriptLengths?: number[];
}
```

###### Property firstActionOutputScriptLengths

Exact output-script byte lengths when a large first action is sent in
compact form with empty script fields. This internal storage extension
avoids sending scripts and input proof data before chunked upload begins.

```ts
firstActionOutputScriptLengths?: number[]
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BeginActionBatchResult

```ts
export interface BeginActionBatchResult {
    batchId: string;
    expiresAt: string;
    hardExpiresAt: string;
    changeBasket: TableOutputBasket;
    feeModel: StorageFeeModel;
    commissionSatoshis: number;
    commissionPubKeyHex?: string;
    availableChangeCount: number;
    managedChangePolicy?: {
        maxOutputsPerAction: number;
        migrationInputsPerAction: number;
    };
    reservedOutputs: ActionBatchFundingOutput[];
    explicitOutputs: ActionBatchFundingOutput[];
    inputBeef?: number[] | Uint8Array;
}
```

See also: [ActionBatchFundingOutput](./client.md#interface-actionbatchfundingoutput), [StorageFeeModel](./client.md#interface-storagefeemodel), [TableOutputBasket](./storage.md#interface-tableoutputbasket)

###### Property managedChangePolicy

Internal planner policy; absent on older providers, which use defaults.

```ts
managedChangePolicy?: {
    maxOutputsPerAction: number;
    migrationInputsPerAction: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BitailsConfig

```ts
export interface BitailsConfig {
    apiKey?: string;
    httpClient?: HttpClient;
    requestTimeoutMsecs?: number;
}
```

###### Property apiKey

Authentication token for BitTails API

```ts
apiKey?: string
```

###### Property httpClient

The HTTP client used to make requests to the API.

```ts
httpClient?: HttpClient
```

###### Property requestTimeoutMsecs

Whole-request deadline applied to Bitails calls. Defaults to 30 seconds.

```ts
requestTimeoutMsecs?: number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BitailsMerkleProof

```ts
export interface BitailsMerkleProof {
    index: number;
    txOrId: string;
    target: string;
    nodes: string[];
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BlockHeader

A `BaseBlockHeader` extended with its computed hash and height in its chain.

```ts
export interface BlockHeader extends BaseBlockHeader {
    height: number;
    hash: string;
}
```

See also: [BaseBlockHeader](./client.md#interface-baseblockheader)

###### Property hash

The double sha256 hash of the serialized `BaseBlockHeader` fields.

```ts
hash: string
```

###### Property height

Height of the header, starting from zero.

```ts
height: number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: Brc177FundingCreateActionMetadata

```ts
export interface Brc177FundingCreateActionMetadata {
    kind: "funding";
    anchorSatoshis: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: Brc177NoSendExpiry

```ts
export interface Brc177NoSendExpiry {
    mode: Brc177NoSendExpiryMode;
    value: number;
    label: string;
}
```

See also: [Brc177NoSendExpiryMode](./client.md#type-brc177nosendexpirymode)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: Brc177ProtectedCreateActionMetadata

```ts
export interface Brc177ProtectedCreateActionMetadata {
    kind: "protected";
    expiry: Brc177NoSendExpiry;
    deadline: number;
    anchorTxid: string;
    anchorVout: number;
}
```

See also: [Brc177NoSendExpiry](./client.md#interface-brc177nosendexpiry)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BsvExchangeRate

```ts
export interface BsvExchangeRate {
    timestamp: Date;
    base: "USD";
    rate: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BulkFileDataCacheApi

Persistent backing cache for immutable bulk-header objects.

Implementations may read packaged checkpoint assets, application storage,
or a filesystem. The manager validates the byte length and SHA-256 digest
before using any returned value or persisting a downloaded value.

```ts
export interface BulkFileDataCacheApi {
    get(file: Readonly<BulkHeaderFileInfo>): Promise<Uint8Array | undefined>;
    set(file: Readonly<BulkHeaderFileInfo>, data: Uint8Array): Promise<void>;
    quarantine?(file: Readonly<BulkHeaderFileInfo>, reason: string, rejectedData?: Uint8Array): Promise<void>;
    promoteValidated?(file: Readonly<BulkHeaderFileInfo>, data: Uint8Array): Promise<void>;
    delete?(file: Readonly<BulkHeaderFileInfo>): Promise<void>;
}
```

See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo)

###### Method promoteValidated

Promote a validated legacy entry into the implementation's preferred
immutable namespace. Implementations should make this idempotent.

```ts
promoteValidated?(file: Readonly<BulkHeaderFileInfo>, data: Uint8Array): Promise<void>
```
See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo)

###### Method quarantine

Preserve a rejected object outside the active cache namespace. The manager
calls this before attempting a replacement and never removes a last-good
object merely because a newer source is unavailable.

```ts
quarantine?(file: Readonly<BulkHeaderFileInfo>, reason: string, rejectedData?: Uint8Array): Promise<void>
```
See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BulkFileDataManagerMergeResult

```ts
export interface BulkFileDataManagerMergeResult {
    unchanged: BulkHeaderFileInfo[];
    inserted: BulkHeaderFileInfo[];
    updated: BulkHeaderFileInfo[];
    dropped: BulkHeaderFileInfo[];
}
```

See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BulkFileDataManagerOptions

```ts
export interface BulkFileDataManagerOptions {
    chain: Chain;
    maxPerFile: number;
    maxRetained?: number;
    fetch?: ChaintracksFetchApi;
    fromKnownSourceUrl?: string;
    cache?: BulkFileDataCacheApi;
    downloadBudget?: BulkFileDownloadBudgetApi;
    validator?: BulkFileDataValidatorApi;
    failedLoadRetryMsecs?: number;
}
```

See also: [BulkFileDataCacheApi](./services.md#interface-bulkfiledatacacheapi), [BulkFileDataValidatorApi](./services.md#interface-bulkfiledatavalidatorapi), [BulkFileDownloadBudgetApi](./services.md#interface-bulkfiledownloadbudgetapi), [Chain](./client.md#type-chain), [ChaintracksFetchApi](./services.md#interface-chaintracksfetchapi)

###### Property cache

Persistent cache consulted before any remote bulk-file download.

```ts
cache?: BulkFileDataCacheApi
```
See also: [BulkFileDataCacheApi](./services.md#interface-bulkfiledatacacheapi)

###### Property downloadBudget

Optional process-local or shared reservation budget for remote bytes.

```ts
downloadBudget?: BulkFileDownloadBudgetApi
```
See also: [BulkFileDownloadBudgetApi](./services.md#interface-bulkfiledownloadbudgetapi)

###### Property failedLoadRetryMsecs

Cooldown after a failed load before the same immutable object can retry.

```ts
failedLoadRetryMsecs?: number
```

###### Property validator

Complete-object validator. Node services should inject a worker-backed implementation.

```ts
validator?: BulkFileDataValidatorApi
```
See also: [BulkFileDataValidatorApi](./services.md#interface-bulkfiledatavalidatorapi)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BulkFileDataManagerStats

```ts
export interface BulkFileDataManagerStats {
    memoryHits: number;
    storageHits: number;
    persistentCacheHits: number;
    persistentCacheMisses: number;
    persistentCacheRejects: number;
    coalescedLoads: number;
    downloads: number;
    downloadedBytes: number;
    loadBackoffs: number;
    validation?: BulkFileDataValidatorStats;
    downloadBudget?: BulkFileDownloadBudgetSnapshot;
}
```

See also: [BulkFileDataValidatorStats](./services.md#interface-bulkfiledatavalidatorstats), [BulkFileDownloadBudgetSnapshot](./services.md#interface-bulkfiledownloadbudgetsnapshot)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BulkFileDataValidationRequest

Complete immutable bulk-header object supplied to a validator.

Implementations must validate the exact byte length and digest as well as
every header's linkage, chain work, genesis, and proof of work.

```ts
export interface BulkFileDataValidationRequest {
    fileName: string;
    data: Uint8Array;
    count: number;
    fileHash?: string;
    firstHeight: number;
    prevHash: string;
    prevChainWork: string;
    lastHash?: string | null;
    lastChainWork?: string | null;
    chain?: Chain;
}
```

See also: [Chain](./client.md#type-chain)

###### Property fileHash

Expected base64 SHA-256 digest. Omit only while producing a new export.

```ts
fileHash?: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BulkFileDataValidationResult

```ts
export interface BulkFileDataValidationResult {
    data: Uint8Array;
    fileHash: string;
    lastHeaderHash: string;
    lastChainWork: string;
}
```

###### Property data

The validated bytes. Worker implementations may transfer ownership.

```ts
data: Uint8Array
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BulkFileDataValidatorApi

Asynchronous validation boundary for immutable bulk-header objects.

Portable runtimes may validate in-process. Node services can inject a
worker-backed implementation so proof-of-work validation never blocks the
request event loop.

```ts
export interface BulkFileDataValidatorApi {
    validate(request: BulkFileDataValidationRequest): Promise<BulkFileDataValidationResult>;
    getStats?(): BulkFileDataValidatorStats;
    destroy?(): Promise<void>;
}
```

See also: [BulkFileDataValidationRequest](./services.md#interface-bulkfiledatavalidationrequest), [BulkFileDataValidationResult](./services.md#interface-bulkfiledatavalidationresult), [BulkFileDataValidatorStats](./services.md#interface-bulkfiledatavalidatorstats)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BulkFileDataValidatorStats

```ts
export interface BulkFileDataValidatorStats {
    submitted: number;
    completed: number;
    failed: number;
    rejected: number;
    workerRestarts: number;
    inFlight: number;
    queued: number;
    maxQueueDepth: number;
    totalValidationMsecs: number;
    maxValidationMsecs: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BulkFileDownloadBudgetApi

A deployment-defined budget for remote bulk-header downloads.
Implementations should throw before the request when the requested byte
reservation would exceed the configured budget.

```ts
export interface BulkFileDownloadBudgetApi {
    consume(byteCount: number): void | Promise<void>;
    snapshot?(): BulkFileDownloadBudgetSnapshot;
}
```

See also: [BulkFileDownloadBudgetSnapshot](./services.md#interface-bulkfiledownloadbudgetsnapshot)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BulkFileDownloadBudgetSnapshot

```ts
export interface BulkFileDownloadBudgetSnapshot {
    maxBytes: number;
    consumedBytes: number;
    remainingBytes: number;
    windowStartedAt: number;
    windowMsecs: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BulkHeaderFileInfo

Descriptive information about a single bulk header file.

```ts
export interface BulkHeaderFileInfo {
    fileName: string;
    firstHeight: number;
    count: number;
    prevChainWork: string;
    lastChainWork: string;
    prevHash: string;
    lastHash: string | null;
    fileHash: string | null;
    chain?: Chain;
    data?: Uint8Array;
    validated?: boolean;
    fileId?: number;
    sourceUrl?: string;
}
```

See also: [Chain](./client.md#type-chain)

###### Property chain

Which chain: 'main' or 'test'

```ts
chain?: Chain
```
See also: [Chain](./client.md#type-chain)

###### Property count

count of how many headers the file contains. File size must be 80 * count.

```ts
count: number
```

###### Property fileHash

file contents single sha256 hash as base64 string

```ts
fileHash: string | null
```

###### Property fileId

optional, used for database storage

```ts
fileId?: number
```

###### Property fileName

filename and extension, no path

```ts
fileName: string
```

###### Property firstHeight

chain height of first header in file

```ts
firstHeight: number
```

###### Property lastChainWork

lastChainWork is the cummulative chain work including the last header in this file's data, as a hex string.

```ts
lastChainWork: string
```

###### Property lastHash

block hash of last header in the file in standard hex string block hash encoding

```ts
lastHash: string | null
```

###### Property prevChainWork

prevChainWork is the cummulative chain work up to the first header in this file's data, as a hex string.

```ts
prevChainWork: string
```

###### Property prevHash

previousHash of first header in file in standard hex string block hash encoding

```ts
prevHash: string
```

###### Property sourceUrl

optional, if valid `${sourceUrl}/${fileName}` is the source of this data.

```ts
sourceUrl?: string
```

###### Property validated

Advisory process-local validation state. Never trust this value after it
crosses a network or storage boundary; revalidate the object bytes.

```ts
validated?: boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: BulkHeaderFilesInfo

Describes a collection of bulk block header files.

```ts
export interface BulkHeaderFilesInfo {
    rootFolder: string;
    jsonFilename: string;
    files: BulkHeaderFileInfo[];
    headersPerFile: number;
}
```

See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo)

###### Property files

Array of information about each bulk block header file.

```ts
files: BulkHeaderFileInfo[]
```
See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo)

###### Property headersPerFile

Maximum number of headers in a single file in this collection of files.

```ts
headersPerFile: number
```

###### Property jsonFilename

Sub-path to this resource on rootFolder

```ts
jsonFilename: string
```

###### Property rootFolder

Where this file was fetched or read from.

```ts
rootFolder: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: CanonicalFundingCandidate

```ts
export interface CanonicalFundingCandidate {
    outputId: number;
    satoshis: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: CertOpsWallet

```ts
export interface CertOpsWallet {
    getPublicKey: (args: GetPublicKeyArgs, originator?: OriginatorDomainNameStringUnder250Bytes) => Promise<GetPublicKeyResult>;
    encrypt: (args: WalletEncryptArgs, originator?: OriginatorDomainNameStringUnder250Bytes) => Promise<WalletEncryptResult>;
    decrypt: (args: WalletDecryptArgs, originator?: OriginatorDomainNameStringUnder250Bytes) => Promise<WalletDecryptResult>;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: Certifier

```ts
export interface Certifier {
    name: string;
    description: string;
    identityKey: PubKeyHex;
    trust: number;
    iconUrl?: string;
    baseURL?: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksApi

Full Chaintracks API including startListening with callbacks

```ts
export interface ChaintracksApi extends ChaintracksClientApi {
    startListening(listening?: () => void): Promise<void>;
}
```

See also: [ChaintracksClientApi](./services.md#interface-chaintracksclientapi)

###### Method startListening

Start or resume listening for new headers.

Calls `synchronize` to catch up on headers that were found while not listening.

Begins listening to any number of configured new header notification services.

Begins sending notifications to subscribed listeners only after processing any
previously found headers.

May be called if already listening or synchronizing to listen.

`listening` callback will be called after listening for new live headers has begun.
Alternatively, the `listening` API function which returns a Promise can be awaited.

```ts
startListening(listening?: () => void): Promise<void>
```

Argument Details

+ **listening**
  + callback indicates when listening for new headers has started.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksAppendableFileApi

Supports access and appending data to new or existing named data storage.
New data is always appended to the end of existing data.

```ts
export interface ChaintracksAppendableFileApi extends ChaintracksReadableFileApi {
    append(data: Uint8Array): Promise<void>;
}
```

See also: [ChaintracksReadableFileApi](./services.md#interface-chaintracksreadablefileapi)

###### Method append

```ts
append(data: Uint8Array): Promise<void>
```

Argument Details

+ **data**
  + data to add to the end of existing data.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksAvailabilitySnapshotApi

Constant-time, local-only process state for probes and operators.

```ts
export interface ChaintracksAvailabilitySnapshotApi {
    available: boolean;
    startupError?: string;
    presentHeight?: number;
    presentHeightUpdatedAt?: string;
    presentHeightRefreshInFlight: boolean;
    mainLoopHeartbeatAt?: string;
    sources: ChaintracksSourceStatusApi[];
    bulkData: ChaintracksBulkDataStatsApi;
}
```

See also: [ChaintracksBulkDataStatsApi](./services.md#interface-chaintracksbulkdatastatsapi), [ChaintracksSourceStatusApi](./services.md#interface-chaintrackssourcestatusapi)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksBulkDataStatsApi

```ts
export interface ChaintracksBulkDataStatsApi {
    memoryHits: number;
    storageHits: number;
    persistentCacheHits: number;
    persistentCacheMisses: number;
    persistentCacheRejects: number;
    coalescedLoads: number;
    downloads: number;
    downloadedBytes: number;
    loadBackoffs: number;
    validation?: {
        submitted: number;
        completed: number;
        failed: number;
        rejected: number;
        workerRestarts: number;
        inFlight: number;
        queued: number;
        maxQueueDepth: number;
        totalValidationMsecs: number;
        maxValidationMsecs: number;
    };
    downloadBudget?: {
        maxBytes: number;
        consumedBytes: number;
        remainingBytes: number;
        windowStartedAt: number;
        windowMsecs: number;
    };
}
```

###### Property downloadBudget

Durable download reservation state when configured.

```ts
downloadBudget?: {
    maxBytes: number;
    consumedBytes: number;
    remainingBytes: number;
    windowStartedAt: number;
    windowMsecs: number;
}
```

###### Property validation

Worker or portable validator statistics when the implementation exposes them.

```ts
validation?: {
    submitted: number;
    completed: number;
    failed: number;
    rejected: number;
    workerRestarts: number;
    inFlight: number;
    queued: number;
    maxQueueDepth: number;
    totalValidationMsecs: number;
    maxValidationMsecs: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksChainTrackerOptions

```ts
export interface ChaintracksChainTrackerOptions {
    maxRetries?: number;
    retryDelayMs?: number;
    telemetry?: TelemetryConfig;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksClientApi

Chaintracks client API excluding events and callbacks

```ts
export interface ChaintracksClientApi extends ChainTracker {
    getChain(): Promise<Chain>;
    getInfo(): Promise<ChaintracksInfoApi>;
    getPresentHeight(): Promise<number>;
    getHeaders(height: number, count: number): Promise<string>;
    findChainTipHeader(): Promise<BlockHeader>;
    findChainTipHash(): Promise<string>;
    findHeaderForHeight(height: number): Promise<BlockHeader | undefined>;
    findHeaderForBlockHash(hash: string): Promise<BlockHeader | undefined>;
    addHeader(header: BaseBlockHeader): Promise<void>;
    startListening(): Promise<void>;
    listening(): Promise<void>;
    isListening(): Promise<boolean>;
    isSynchronized(): Promise<boolean>;
    subscribeHeaders(listener: HeaderListener): Promise<string>;
    subscribeReorgs(listener: ReorgListener): Promise<string>;
    unsubscribe(subscriptionId: string): Promise<boolean>;
    isValidRootForHeight(root: string, height: number): Promise<boolean>;
    currentHeight: () => Promise<number>;
}
```

See also: [BaseBlockHeader](./client.md#interface-baseblockheader), [BlockHeader](./client.md#interface-blockheader), [Chain](./client.md#type-chain), [ChaintracksInfoApi](./services.md#interface-chaintracksinfoapi), [HeaderListener](./services.md#type-headerlistener), [ReorgListener](./services.md#type-reorglistener)

###### Method addHeader

Submit a possibly new header for adding

If the header is invalid or a duplicate it will not be added.

This header will be ignored if the previous header has not already been inserted when this header
is considered for insertion.

```ts
addHeader(header: BaseBlockHeader): Promise<void>
```
See also: [BaseBlockHeader](./client.md#interface-baseblockheader)

Returns

immediately

###### Method findChainTipHash

Returns the block hash of the active chain tip.

```ts
findChainTipHash(): Promise<string>
```

###### Method findChainTipHeader

Returns the active chain tip header

```ts
findChainTipHeader(): Promise<BlockHeader>
```
See also: [BlockHeader](./client.md#interface-blockheader)

###### Method findHeaderForBlockHash

Returns block header for a given recent block hash or undefined.

```ts
findHeaderForBlockHash(hash: string): Promise<BlockHeader | undefined>
```
See also: [BlockHeader](./client.md#interface-blockheader)

###### Method findHeaderForHeight

Returns block header for a given block height on active chain.

```ts
findHeaderForHeight(height: number): Promise<BlockHeader | undefined>
```
See also: [BlockHeader](./client.md#interface-blockheader)

###### Method getChain

Confirms the chain

```ts
getChain(): Promise<Chain>
```
See also: [Chain](./client.md#type-chain)

###### Method getHeaders

Adds headers in 80 byte serialized format to an array.
Only adds active headers.
array length divided by 80 is the actual number returned.

```ts
getHeaders(height: number, count: number): Promise<string>
```

Returns

array of headers as serialized hex string

Argument Details

+ **height**
  + of first header
+ **count**
  + of headers, maximum

###### Method getInfo

```ts
getInfo(): Promise<ChaintracksInfoApi>
```
See also: [ChaintracksInfoApi](./services.md#interface-chaintracksinfoapi)

Returns

Summary of configuration and state.

###### Method getPresentHeight

Return the latest chain height from configured bulk ingestors.

```ts
getPresentHeight(): Promise<number>
```

###### Method isListening

Returns true if actively listening for new headers and client api is enabled.

```ts
isListening(): Promise<boolean>
```

###### Method isSynchronized

Returns true if `synchronize` has completed at least once.

```ts
isSynchronized(): Promise<boolean>
```

###### Method listening

Returns a Promise that will resolve when the previous call to startListening
enters the listening-for-new-headers state.

```ts
listening(): Promise<void>
```

###### Method startListening

Start or resume listening for new headers.

Calls `synchronize` to catch up on headers that were found while not listening.

Begins listening to any number of configured new header notification services.

Begins sending notifications to subscribed listeners only after processing any
previously found headers.

May be called if already listening or synchronizing to listen.

The `listening` API function which returns a Promise can be awaited.

```ts
startListening(): Promise<void>
```

###### Method subscribeHeaders

Subscribe to "header" events.

```ts
subscribeHeaders(listener: HeaderListener): Promise<string>
```
See also: [HeaderListener](./services.md#type-headerlistener)

Returns

identifier for this subscription

Throws

ERR_NOT_IMPLEMENTED if callback events are not supported

###### Method subscribeReorgs

Subscribe to "reorganization" events.

```ts
subscribeReorgs(listener: ReorgListener): Promise<string>
```
See also: [ReorgListener](./services.md#type-reorglistener)

Returns

identifier for this subscription

Throws

ERR_NOT_IMPLEMENTED if callback events are not supported

###### Method unsubscribe

Cancels all subscriptions with the given `subscriptionId` which was previously returned
by a `subscribe` method.

```ts
unsubscribe(subscriptionId: string): Promise<boolean>
```

Returns

true if a subscription was canceled

Argument Details

+ **subscriptionId**
  + value previously returned by subscribeToHeaders or subscribeToReorgs

Throws

ERR_NOT_IMPLEMENTED if callback events are not supported

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksDownloadOptions

```ts
export interface ChaintracksDownloadOptions {
    beforeRetry?: (attempt: number) => void | Promise<void>;
    publicNetworkOnly?: boolean;
}
```

###### Property beforeRetry

Called immediately before each retry after the initial request.

```ts
beforeRetry?: (attempt: number) => void | Promise<void>
```

###### Property publicNetworkOnly

Resolve, approve, and DNS-pin only public HTTPS destinations.

```ts
publicNetworkOnly?: boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksFetchApi

Provides a simplified interface based on the

```ts
export interface ChaintracksFetchApi {
    httpClient: HttpClient;
    download(url: string, maxResponseBytes?: number, options?: ChaintracksDownloadOptions): Promise<Uint8Array>;
    fetchJson<R>(url: string): Promise<R>;
    pathJoin(baseUrl: string, subpath: string): string;
}
```

See also: [ChaintracksDownloadOptions](./services.md#interface-chaintracksdownloadoptions)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksFetchOptions

```ts
export interface ChaintracksFetchOptions {
    maxRetries?: number;
    timeoutMsecs?: number;
    maxResponseBytes?: number;
    retryMsecs?: number;
    maxRetryMsecs?: number;
    random?: () => number;
    fetch?: typeof fetch;
    publicNetworkFetch?: typeof fetch;
}
```

###### Property fetch

Fetch implementation for operator-configured sources.

```ts
fetch?: typeof fetch
```

###### Property maxResponseBytes

Maximum materialized response size for binary and JSON requests.

```ts
maxResponseBytes?: number
```

###### Property maxRetries

Number of retries after the initial request. Defaults to three.

```ts
maxRetries?: number
```

###### Property publicNetworkFetch

Public-network fetch implementation; injectable for deterministic tests.

```ts
publicNetworkFetch?: typeof fetch
```

###### Property random

Testable jitter source in the inclusive range 0..1.

```ts
random?: () => number
```

###### Property timeoutMsecs

Deadline covering connection, headers, and response body.

```ts
timeoutMsecs?: number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksFsApi

Supports file-like access to named data storage.

Only minimal functionality required by Chaintracks is supported.

```ts
export interface ChaintracksFsApi {
    delete(path: string): Promise<void>;
    writeFile(path: string, data: Uint8Array): Promise<void>;
    readFile(path: string): Promise<Uint8Array>;
    openReadableFile(path: string): Promise<ChaintracksReadableFileApi>;
    openWritableFile(path: string): Promise<ChaintracksWritableFileApi>;
    openAppendableFile(path: string): Promise<ChaintracksAppendableFileApi>;
    pathJoin(...parts: string[]): string;
}
```

See also: [ChaintracksAppendableFileApi](./services.md#interface-chaintracksappendablefileapi), [ChaintracksReadableFileApi](./services.md#interface-chaintracksreadablefileapi), [ChaintracksWritableFileApi](./services.md#interface-chaintrackswritablefileapi)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksInfoApi

```ts
export interface ChaintracksInfoApi {
    chain: Chain;
    heightBulk: number;
    heightLive: number;
    storage: string;
    bulkIngestors: string[];
    liveIngestors: string[];
    packages: ChaintracksPackageInfoApi[];
    sources?: ChaintracksSourceStatusApi[];
    bulkData?: ChaintracksBulkDataStatsApi;
}
```

See also: [Chain](./client.md#type-chain), [ChaintracksBulkDataStatsApi](./services.md#interface-chaintracksbulkdatastatsapi), [ChaintracksPackageInfoApi](./services.md#interface-chaintrackspackageinfoapi), [ChaintracksSourceStatusApi](./services.md#interface-chaintrackssourcestatusapi)

###### Property bulkData

Local bulk-header retrieval counters. Additive and omitted by older services.

```ts
bulkData?: ChaintracksBulkDataStatsApi
```
See also: [ChaintracksBulkDataStatsApi](./services.md#interface-chaintracksbulkdatastatsapi)

###### Property sources

Last observed source state. Additive and omitted by older services.

```ts
sources?: ChaintracksSourceStatusApi[]
```
See also: [ChaintracksSourceStatusApi](./services.md#interface-chaintrackssourcestatusapi)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksPackageInfoApi

```ts
export interface ChaintracksPackageInfoApi {
    name: string;
    version: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksReadableFileApi

Supports access to named data storage (file like).

```ts
export interface ChaintracksReadableFileApi {
    path: string;
    close(): Promise<void>;
    getLength(): Promise<number>;
    read(length?: number, offset?: number): Promise<Uint8Array>;
}
```

###### Method getLength

Returns the length of the data storage in bytes.

```ts
getLength(): Promise<number>
```

###### Method read

```ts
read(length?: number, offset?: number): Promise<Uint8Array>
```

Argument Details

+ **length**
  + requested length to be returned, may return less than requested.
+ **offset**
  + starting offset in the existing data storage to read from, defaults to 0.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksServiceClientOptions

```ts
export interface ChaintracksServiceClientOptions {
    useAuthrite?: false;
    fetch?: typeof fetch;
    requestTimeoutMsecs?: number;
    maxResponseBytes?: number;
    maxRequestBytes?: number;
}
```

###### Property maxRequestBytes

Maximum JSON request size. Default: 256 KiB.

```ts
maxRequestBytes?: number
```

###### Property maxResponseBytes

Maximum JSON response size. Default: 4 MiB.

```ts
maxResponseBytes?: number
```

###### Property requestTimeoutMsecs

Whole-request deadline, including response-body consumption. Default: 30 seconds.

```ts
requestTimeoutMsecs?: number
```

###### Property useAuthrite

Retained for compatibility with historical callers; this client does not use Authrite.

```ts
useAuthrite?: false
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksSourceStatusApi

```ts
export interface ChaintracksSourceStatusApi {
    name: string;
    role: "bulk" | "live";
    state: "unknown" | "healthy" | "degraded";
    lastSuccess?: string;
    lastFailure?: string;
    error?: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksStorageApi

```ts
export interface ChaintracksStorageApi extends ChaintracksStorageQueryApi, ChaintracksStorageIngestApi {
    log: (...args: any[]) => void;
    bulkManager: BulkFileDataManager;
    destroy(): Promise<void>;
}
```

See also: [BulkFileDataManager](./services.md#class-bulkfiledatamanager), [ChaintracksStorageIngestApi](./services.md#interface-chaintracksstorageingestapi), [ChaintracksStorageQueryApi](./services.md#interface-chaintracksstoragequeryapi)

###### Method destroy

Close and release all resources.

```ts
destroy(): Promise<void>
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksStorageBaseOptions

```ts
export interface ChaintracksStorageBaseOptions {
    chain: Chain;
    liveHeightThreshold: number;
    reorgHeightThreshold: number;
    bulkMigrationChunkSize: number;
    batchInsertLimit: number;
    bulkFileDataManager: BulkFileDataManager | undefined;
}
```

See also: [BulkFileDataManager](./services.md#class-bulkfiledatamanager), [Chain](./client.md#type-chain)

###### Property batchInsertLimit

Maximum number of headers per call to batchInsert

```ts
batchInsertLimit: number
```

###### Property bulkFileDataManager

Controls in memory caching and retrieval of missing bulk header data.

```ts
bulkFileDataManager: BulkFileDataManager | undefined
```
See also: [BulkFileDataManager](./services.md#class-bulkfiledatamanager)

###### Property bulkMigrationChunkSize

How many excess "live" headers to accumulate before migrating them as a chunk to the
bulk header storage.

```ts
bulkMigrationChunkSize: number
```

###### Property chain

Which chain is being tracked: main, test, or stn.

```ts
chain: Chain
```
See also: [Chain](./client.md#type-chain)

###### Property liveHeightThreshold

How much of recent history is required to be kept in "live" block header storage.

Headers with height less than active chain tip height minus `liveHeightThreshold`
are not required to be kept in "live" storage and may be migrated to "bulk" storage.

As no forks, orphans, or reorgs can affect "bulk" block header storage, an
aggressively high number is recommended: At least an order of magnitude more than
the deepest actual reorg you can imagine.

```ts
liveHeightThreshold: number
```

###### Property reorgHeightThreshold

How much of recent history must be processed with full validation and reorg support.

Must be less than or equal to `liveHeightThreshold`.

Headers with height older than active chain tip height minus `reorgHeightThreshold`
may use batch processing when ingesting headers.

```ts
reorgHeightThreshold: number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksStorageBulkFileApi

```ts
export interface ChaintracksStorageBulkFileApi {
    insertBulkFile(file: BulkHeaderFileInfo): Promise<number>;
    updateBulkFile(fileId: number, file: BulkHeaderFileInfo): Promise<number>;
    deleteBulkFile(fileId: number): Promise<number>;
    getBulkFiles(): Promise<BulkHeaderFileInfo[]>;
    getBulkFileData(fileId: number, offset?: number, length?: number): Promise<Uint8Array | undefined>;
    replaceBulkFiles?(files: BulkHeaderFileInfo[]): Promise<BulkHeaderFileInfo[]>;
}
```

See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo)

###### Method replaceBulkFiles

Atomically replace the complete bulk-file metadata set and return the
committed records, including identities allocated to new records.

Implementations must preserve existing stored data when a record with a
`fileId` omits `data`, and must leave the prior set unchanged on failure.
Managers require this capability for updates that affect multiple records.

```ts
replaceBulkFiles?(files: BulkHeaderFileInfo[]): Promise<BulkHeaderFileInfo[]>
```
See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksStorageIngestApi

```ts
export interface ChaintracksStorageIngestApi {
    log: (...args: any[]) => void;
    insertHeader(header: BlockHeader, prev?: LiveBlockHeader): Promise<InsertHeaderResult>;
    pruneLiveBlockHeaders(activeTipHeight: number): Promise<void>;
    migrateLiveToBulk(count: number): Promise<void>;
    deleteOlderLiveBlockHeaders(maxHeight: number): Promise<number>;
    makeAvailable(): Promise<void>;
    migrateLatest(): Promise<void>;
    dropAllData(): Promise<void>;
    destroy(): Promise<void>;
}
```

See also: [BlockHeader](./client.md#interface-blockheader), [InsertHeaderResult](./services.md#type-insertheaderresult), [LiveBlockHeader](./services.md#interface-liveblockheader)

###### Method deleteOlderLiveBlockHeaders

Delete live headers with height less or equal to `maxHeight`
after they have been migrated to bulk storage.

```ts
deleteOlderLiveBlockHeaders(maxHeight: number): Promise<number>
```

Argument Details

+ **maxHeight**
  + delete all records with less or equal `height`

###### Method destroy

Release all resources. Makes the instance unusable.

```ts
destroy(): Promise<void>
```

###### Method insertHeader

Attempts to insert a block header into the chain.

Returns 'added' false and 'dupe' true if header's hash already exists in the live database
Returns 'added' false and 'dupe' false if header's previousHash wasn't found in the live database, or height doesn't increment previous' height.

Computes the header's chainWork from its bits and the previous header's chainWork.

Returns 'added' true if the header was added to the live database.
Returns 'isActiveTip' true if header's chainWork is greater than current active chain tip's chainWork.

If the addition of this header caused a reorg (did not directly extend old active chain tip):
Returns 'reorgDepth' the minimum height difference of the common ancestor to the two chain tips.
Returns 'priorTip' the old active chain tip.
If not a reorg:
Returns 'reorgDepth' of zero.
Returns 'priorTip' the active chain tip before this insert. May be unchanged.

Implementation must call `pruneLiveBlockHeaders` after adding new header.

```ts
insertHeader(header: BlockHeader, prev?: LiveBlockHeader): Promise<InsertHeaderResult>
```
See also: [BlockHeader](./client.md#interface-blockheader), [InsertHeaderResult](./services.md#type-insertheaderresult), [LiveBlockHeader](./services.md#interface-liveblockheader)

Argument Details

+ **header**
  + to insert
+ **prev**
  + if not undefined, the last bulk storage header with total bulk chainWork

###### Method makeAvailable

Async initialization method.

May be called prior to other async methods to control when initialization occurs.

```ts
makeAvailable(): Promise<void>
```

###### Method migrateLatest

Migrate storage schema to latest schema changes.

Typically invoked automatically by `makeAvailable`.

```ts
migrateLatest(): Promise<void>
```

###### Method migrateLiveToBulk

Migrates the oldest `count` LiveBlockHeaders to BulkStorage.
BulkStorage must be configured.
`count` must not exceed `bulkMigrationChunkSize`.
`count` must leave at least `liveHeightThreshold` LiveBlockHeaders.

```ts
migrateLiveToBulk(count: number): Promise<void>
```

Argument Details

+ **count**
  + Steps:
- Copy count oldest active LiveBlockHeaders from live database to buffer.
- Append the buffer of headers to BulkStorage
- Add the buffer's BlockHash, Height pairs to corresponding index table.
- Add the buffer's MerkleRoot, Height pairs to corresponding index table.
- Delete the records from the live database.

###### Method pruneLiveBlockHeaders

Must be called after the addition of new LiveBlockHeaders.

Checks the `StorageEngine` configuration options to see
if BulkStorage is configured and if there is at least one
`bulkMigrationChunkSize` woth of headers in excess of
`liveHeightThreshold` available.

If yes, then calls `migrateLiveToBulk` one or more times.

```ts
pruneLiveBlockHeaders(activeTipHeight: number): Promise<void>
```

Argument Details

+ **activeTipHeight**
  + height of active tip after adds

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksStorageQueryApi

```ts
export interface ChaintracksStorageQueryApi {
    log: (...args: any[]) => void;
    findChainTipHeader(): Promise<LiveBlockHeader>;
    findChainTipHash(): Promise<string>;
    findChainTipHeaderOrUndefined(): Promise<LiveBlockHeader | undefined>;
    findChainTipWork(): Promise<string>;
    findHeaderForHeight(height: number): Promise<LiveBlockHeader | BlockHeader>;
    findHeaderForHeightOrUndefined(height: number): Promise<LiveBlockHeader | BlockHeader | undefined>;
    findCommonAncestor(header1: LiveBlockHeader, header2: LiveBlockHeader): Promise<LiveBlockHeader>;
    findReorgDepth(header1: LiveBlockHeader, header2: LiveBlockHeader): Promise<number>;
    isMerkleRootActive(merkleRoot: string): Promise<boolean>;
    getHeadersUint8Array(height: number, count: number): Promise<Uint8Array>;
    getHeaders(height: number, count: number): Promise<BaseBlockHeader[]>;
    getLiveHeaders(range: HeightRange): Promise<LiveBlockHeader[]>;
    getBulkHeaders(range: HeightRange): Promise<Uint8Array>;
    findLiveHeaderForHeight(height: number): Promise<LiveBlockHeader | null>;
    findLiveHeaderForHeaderId(headerId: number): Promise<LiveBlockHeader>;
    findLiveHeaderForBlockHash(hash: string): Promise<LiveBlockHeader | null>;
    findLiveHeaderForMerkleRoot(merkleRoot: string): Promise<LiveBlockHeader | null>;
    getAvailableHeightRanges(): Promise<{
        bulk: HeightRange;
        live: HeightRange;
    }>;
    findLiveHeightRange(): Promise<HeightRange>;
    findMaxHeaderId(): Promise<number>;
    chain: Chain;
    liveHeightThreshold: number;
    reorgHeightThreshold: number;
    bulkMigrationChunkSize: number;
    batchInsertLimit: number;
}
```

See also: [BaseBlockHeader](./client.md#interface-baseblockheader), [BlockHeader](./client.md#interface-blockheader), [Chain](./client.md#type-chain), [HeightRange](./services.md#class-heightrange), [LiveBlockHeader](./services.md#interface-liveblockheader)

###### Property batchInsertLimit

Maximum number of headers per call to batchInsert

```ts
batchInsertLimit: number
```

###### Property bulkMigrationChunkSize

How many excess "live" headers to accumulate before migrating them as a chunk to the
bulk header storage.

```ts
bulkMigrationChunkSize: number
```

###### Property chain

Which chain is being tracked: "main" or "test".

```ts
chain: Chain
```
See also: [Chain](./client.md#type-chain)

###### Property liveHeightThreshold

How much of recent history is required to be kept in "live" block header storage.

Headers with height older than active chain tip height minus `liveHeightThreshold`
are not required to be kept in "live" storage and may be migrated to "bulk" storage.

```ts
liveHeightThreshold: number
```

###### Property reorgHeightThreshold

How much of recent history must be processed with full validation and reorg support.

May be less than `liveHeightThreshold`.

Headers with height older than active chain tip height minus ``
may use batch processing when ingesting headers.

```ts
reorgHeightThreshold: number
```

###### Method findChainTipHash

Returns the block hash of the active chain tip.

```ts
findChainTipHash(): Promise<string>
```

###### Method findChainTipHeader

Returns the active chain tip header
Throws an error if there is no tip.

```ts
findChainTipHeader(): Promise<LiveBlockHeader>
```
See also: [LiveBlockHeader](./services.md#interface-liveblockheader)

###### Method findChainTipHeaderOrUndefined

Returns the active chain tip header or undefined if there is no tip.

```ts
findChainTipHeaderOrUndefined(): Promise<LiveBlockHeader | undefined>
```
See also: [LiveBlockHeader](./services.md#interface-liveblockheader)

###### Method findChainTipWork

Returns the chainWork value of the active chain tip

```ts
findChainTipWork(): Promise<string>
```

###### Method findCommonAncestor

Given two chain tip headers in a chain reorg scenario,
return their common ancestor header.

```ts
findCommonAncestor(header1: LiveBlockHeader, header2: LiveBlockHeader): Promise<LiveBlockHeader>
```
See also: [LiveBlockHeader](./services.md#interface-liveblockheader)

Argument Details

+ **header1**
  + First header in live part of the chain.
+ **header2**
  + Second header in live part of the chain.

###### Method findHeaderForHeight

Returns block header for a given block height on active chain.

```ts
findHeaderForHeight(height: number): Promise<LiveBlockHeader | BlockHeader>
```
See also: [BlockHeader](./client.md#interface-blockheader), [LiveBlockHeader](./services.md#interface-liveblockheader)

Argument Details

+ **hash**
  + block hash

###### Method findHeaderForHeightOrUndefined

Returns block header for a given block height on active chain.

```ts
findHeaderForHeightOrUndefined(height: number): Promise<LiveBlockHeader | BlockHeader | undefined>
```
See also: [BlockHeader](./client.md#interface-blockheader), [LiveBlockHeader](./services.md#interface-liveblockheader)

Argument Details

+ **hash**
  + block hash

###### Method findLiveHeaderForBlockHash

Returns block header for a given block hash.
Only from the "live" portion of the chain.
Returns null if not found.

```ts
findLiveHeaderForBlockHash(hash: string): Promise<LiveBlockHeader | null>
```
See also: [LiveBlockHeader](./services.md#interface-liveblockheader)

Argument Details

+ **hash**
  + block hash

###### Method findLiveHeaderForHeaderId

Returns block header for a given headerId.

Only from the "live" portion of the chain.

```ts
findLiveHeaderForHeaderId(headerId: number): Promise<LiveBlockHeader>
```
See also: [LiveBlockHeader](./services.md#interface-liveblockheader)

###### Method findLiveHeaderForHeight

Returns block header for a given block height on active chain.

```ts
findLiveHeaderForHeight(height: number): Promise<LiveBlockHeader | null>
```
See also: [LiveBlockHeader](./services.md#interface-liveblockheader)

Argument Details

+ **hash**
  + block hash

###### Method findLiveHeaderForMerkleRoot

Returns block header for a given merkleRoot.
Only from the "live" portion of the chain.

```ts
findLiveHeaderForMerkleRoot(merkleRoot: string): Promise<LiveBlockHeader | null>
```
See also: [LiveBlockHeader](./services.md#interface-liveblockheader)

###### Method findLiveHeightRange

```ts
findLiveHeightRange(): Promise<HeightRange>
```
See also: [HeightRange](./services.md#class-heightrange)

Returns

The current minimum and maximum height active LiveBlockHeaders in the "live" database.

###### Method findMaxHeaderId

```ts
findMaxHeaderId(): Promise<number>
```

Returns

The maximum headerId value used by existing records or -1 if there are none.

###### Method findReorgDepth

This is an original API. Proposed deprecation in favor of `findCommonAncestor`
Given two headers that are both chain tips in a reorg scenario, returns
the depth of the reorg (the greater of the heights of the two provided
headers, minus the height of their last common ancestor)

```ts
findReorgDepth(header1: LiveBlockHeader, header2: LiveBlockHeader): Promise<number>
```
See also: [LiveBlockHeader](./services.md#interface-liveblockheader)

###### Method getAvailableHeightRanges

Returns the height range of both bulk and live storage.
Verifies that the ranges meet these requirements:
- Both may be empty.
- If bulk is empty, live must be empty or start with height zero.
- If bulk is not empty it must start with height zero.
- If bulk is not empty and live is not empty, live must start with the height after bulk.

```ts
getAvailableHeightRanges(): Promise<{
    bulk: HeightRange;
    live: HeightRange;
}>
```
See also: [HeightRange](./services.md#class-heightrange)

###### Method getBulkHeaders

Returns serialized bulk headers in the given range.

```ts
getBulkHeaders(range: HeightRange): Promise<Uint8Array>
```
See also: [HeightRange](./services.md#class-heightrange)

Returns

serialized headers as a Uint8Array.

###### Method getHeaders

Returns an array of deserialized headers.
Only adds bulk and active live headers.

```ts
getHeaders(height: number, count: number): Promise<BaseBlockHeader[]>
```
See also: [BaseBlockHeader](./client.md#interface-baseblockheader)

Returns

array of deserialized headers

Argument Details

+ **height**
  + is the minimum header height to return, must be >= zero.
+ **count**
  + height + count - 1 is the maximum header height to return.

###### Method getHeadersUint8Array

Returns serialized headers as a Uint8Array.
Only adds bulk and active live headers.

```ts
getHeadersUint8Array(height: number, count: number): Promise<Uint8Array>
```

Returns

serialized headers as a Uint8Array.

Argument Details

+ **height**
  + is the minimum header height to return, must be >= zero.
+ **count**
  + height + count - 1 is the maximum header height to return.

###### Method getLiveHeaders

Returns active `LiveBlockHeaders` with height in the given range.

```ts
getLiveHeaders(range: HeightRange): Promise<LiveBlockHeader[]>
```
See also: [HeightRange](./services.md#class-heightrange), [LiveBlockHeader](./services.md#interface-liveblockheader)

Returns

array of active `LiveBlockHeaders`

###### Method isMerkleRootActive

Returns true if the given merkleRoot is found in a block header on the active chain.

```ts
isMerkleRootActive(merkleRoot: string): Promise<boolean>
```

Argument Details

+ **merkleRoot**
  + of block header

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ChaintracksWritableFileApi

Supports creation or re-creation of named data storage from position 0.
Any pre-existing data is initially removed.
Does not support reading existing data.

```ts
export interface ChaintracksWritableFileApi {
    path: string;
    close(): Promise<void>;
    append(data: Uint8Array): Promise<void>;
}
```

###### Method append

```ts
append(data: Uint8Array): Promise<void>
```

Argument Details

+ **data**
  + data to add to the end of existing data.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: CommitActionBatchByDigestArgs

```ts
export interface CommitActionBatchByDigestArgs {
    batchId: string;
    digest: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: CommitActionBatchResult

```ts
export interface CommitActionBatchResult extends StorageProcessActionResults {
    batchId: string;
    manifestDigest: string;
    committedTxids: TXIDHexString[];
    alreadyCommitted: boolean;
}
```

See also: [StorageProcessActionResults](./client.md#interface-storageprocessactionresults)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: CommitNewTxResults

```ts
export interface CommitNewTxResults {
    req: EntityProvenTxReq;
    log?: string;
}
```

See also: [EntityProvenTxReq](./storage.md#class-entityproventxreq)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ContactRecord

```ts
export interface ContactRecord {
    identityKey: PubKeyHex;
    type?: string;
    decryptedFields?: Record<string, string>;
    certifierInfo?: {
        name?: string;
        iconUrl?: string;
        description?: string;
        trust?: number;
    };
}
```

###### Property certifierInfo

Optional local trust metadata. Missing trust defaults to `Infinity`, meaning the user's contact
assertion overrides third-party overlay thresholds by explicit local policy. It does not mean
that an external certifier supplied or cryptographically verified the record. Infinity is
scoped to the local policy decision; it must not be serialized as a universal trust claim.

```ts
certifierInfo?: {
    name?: string;
    iconUrl?: string;
    description?: string;
    trust?: number;
}
```

###### Property decryptedFields

Optional decrypted fields. Whatever the app stored when saving the contact.

```ts
decryptedFields?: Record<string, string>
```

###### Property type

Optional certificate type (e.g. xCert / discordCert) so callers can render a badge.

```ts
type?: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ContactSource

The preferred means of constructing a `Wallet` is with a `WalletArgs` instance.

Minimal interface the wallet uses to short-circuit identity discovery against the user's local
contacts before hitting the overlay. Installing a source is an explicit local trust-policy
decision: its records are authoritative personal assertions, like a self-signed certificate or
locally installed trust anchor. The authority is scoped to this user's saved identity-key
association and local metadata; it is not an independent third-party certifier attestation or
a transferable trust statement for another wallet.

The result shape matches what `discoverByIdentityKey` / `discoverByAttributes` return so callers
do not have to special-case contact-sourced records. Contact results are identifiable by their
default `contact` type and empty certificate proof fields. Do not wire network responses or other
unauthenticated third-party data directly into this interface. Authenticating the local store
proves who saved the record, while the prior user/application validation supplies its identity
authority.

Implementations typically wrap `@bsv/sdk` `ContactsManager` or another on-device source. Reads
are expected to be very fast (single-digit ms against local SQLite is typical).

```ts
export interface ContactSource {
    findByIdentityKey: (identityKey: PubKeyHex) => Promise<ContactRecord | null | undefined>;
    findByAttributes?: (attributes: Record<string, string> | string[]) => Promise<ContactRecord[]>;
}
```

See also: [ContactRecord](./client.md#interface-contactrecord)

###### Property findByAttributes

Look up contacts matching a set of attributes. May be a no-op if attribute search is unsupported.

```ts
findByAttributes?: (attributes: Record<string, string> | string[]) => Promise<ContactRecord[]>
```
See also: [ContactRecord](./client.md#interface-contactrecord)

###### Property findByIdentityKey

Look up a contact by identity key. Return `null` (or undefined) if unknown.

```ts
findByIdentityKey: (identityKey: PubKeyHex) => Promise<ContactRecord | null | undefined>
```
See also: [ContactRecord](./client.md#interface-contactrecord)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: CreateActionResultX

```ts
export interface CreateActionResultX extends CreateActionResult {
    txid?: TXIDHexString;
    tx?: AtomicBEEF;
    noSendChange?: OutpointString[];
    sendWithResults?: SendWithResult[];
    signableTransaction?: SignableTransaction;
    notDelayedResults?: ReviewActionResult[];
}
```

See also: [ReviewActionResult](./client.md#interface-reviewactionresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: DeactivedHeader

```ts
export interface DeactivedHeader {
    whenMsecs: number;
    tries: number;
    header: BlockHeader;
}
```

See also: [BlockHeader](./client.md#interface-blockheader)

###### Property header

The deactivated block header.

```ts
header: BlockHeader
```
See also: [BlockHeader](./client.md#interface-blockheader)

###### Property tries

Number of attempts made to process the header.
Supports returning deactivation notification to the queue if proof data is not yet available.

```ts
tries: number
```

###### Property whenMsecs

To control aging of notification before pursuing updated proof data.

```ts
whenMsecs: number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: EntitySyncMap

```ts
export interface EntitySyncMap {
    entityName: string;
    idMap: Record<number, number>;
    maxUpdated_at?: Date;
    count: number;
}
```

###### Property count

The cummulative count of items of this entity type received over all the `SyncChunk`s
since the `since` was last updated.

This is the `offset` value to use for the next SyncChunk request.

```ts
count: number
```

###### Property idMap

Maps foreign ids to local ids
Some entities don't have idMaps (CertificateField, TxLabelMap and OutputTagMap)

```ts
idMap: Record<number, number>
```

###### Property maxUpdated_at

the maximum updated_at value seen for this entity over chunks received
during this udpate cycle.

```ts
maxUpdated_at?: Date
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: EntityTimeStamp

```ts
export interface EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ExactActionSpendCarrier

```ts
export interface ExactActionSpendCarrier {
    [exactActionSpendSymbol]?: number;
}
```

See also: [exactActionSpendSymbol](./client.md#variable-exactactionspendsymbol)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ExchangeRatesIoApi

```ts
export interface ExchangeRatesIoApi {
    success: true;
    timestamp: number;
    base: "EUR" | "USD";
    date: string;
    rates: Record<string, number>;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ExtendActionBatchArgs

```ts
export interface ExtendActionBatchArgs {
    batchId: string;
    targetSatoshis: number;
    requestedOutputs: number;
    explicitOutpoints: Array<{
        txid: string;
        vout: number;
    }>;
    includeSourceTransactions: boolean;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ExtendActionBatchResult

```ts
export interface ExtendActionBatchResult {
    expiresAt: string;
    reservedOutputs: ActionBatchFundingOutput[];
    explicitOutputs: ActionBatchFundingOutput[];
    inputBeef?: number[] | Uint8Array;
}
```

See also: [ActionBatchFundingOutput](./client.md#interface-actionbatchfundingoutput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ExtendedVerifiableCertificate

```ts
export interface ExtendedVerifiableCertificate extends IdentityCertificate {
    certifierInfo: IdentityCertifier;
    publiclyRevealedKeyring: Record<string, Base64String>;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FailedInputReconciliationResult

```ts
export interface FailedInputReconciliationResult {
    checked: number;
    staleConfirmed: number;
    staleOutpoints: string[];
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FiatExchangeRates

```ts
export interface FiatExchangeRates {
    timestamp: Date;
    base: FiatCurrencyCode;
    rates: Record<string, number>;
    rateTimestamps?: Record<string, Date>;
}
```

See also: [FiatCurrencyCode](./client.md#type-fiatcurrencycode)

###### Property base

Wallet Toolbox normalizes provider responses to USD.

```ts
base: FiatCurrencyCode
```
See also: [FiatCurrencyCode](./client.md#type-fiatcurrencycode)

###### Property rateTimestamps

Optional per-currency freshness timestamps under the same timestamp rules.

```ts
rateTimestamps?: Record<string, Date>
```

###### Property rates

Finite, positive currency-per-USD values. USD must equal exactly 1.

```ts
rates: Record<string, number>
```

###### Property timestamp

Finite timestamp no more than five minutes in the future.

```ts
timestamp: Date
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindCertificateFieldsArgs

```ts
export interface FindCertificateFieldsArgs extends FindSincePagedArgs {
    partial: Partial<TableCertificateField>;
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs), [TableCertificateField](./storage.md#interface-tablecertificatefield)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindCertificatesArgs

```ts
export interface FindCertificatesArgs extends FindSincePagedArgs {
    partial: Partial<TableCertificate>;
    certifiers?: string[];
    types?: string[];
    includeFields?: boolean;
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs), [TableCertificate](./storage.md#interface-tablecertificate)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindCommissionsArgs

```ts
export interface FindCommissionsArgs extends FindSincePagedArgs {
    partial: Partial<TableCommission>;
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs), [TableCommission](./storage.md#interface-tablecommission)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindForUserSincePagedArgs

```ts
export interface FindForUserSincePagedArgs extends FindSincePagedArgs {
    userId: number;
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindMonitorEventsArgs

```ts
export interface FindMonitorEventsArgs extends FindSincePagedArgs {
    partial: Partial<TableMonitorEvent>;
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs), [TableMonitorEvent](./storage.md#interface-tablemonitorevent)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindOutputBasketsArgs

```ts
export interface FindOutputBasketsArgs extends FindSincePagedArgs {
    partial: Partial<TableOutputBasket>;
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs), [TableOutputBasket](./storage.md#interface-tableoutputbasket)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindOutputTagMapsArgs

```ts
export interface FindOutputTagMapsArgs extends FindSincePagedArgs {
    partial: Partial<TableOutputTagMap>;
    tagIds?: number[];
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs), [TableOutputTagMap](./storage.md#interface-tableoutputtagmap)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindOutputTagsArgs

```ts
export interface FindOutputTagsArgs extends FindSincePagedArgs {
    partial: Partial<TableOutputTag>;
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs), [TableOutputTag](./storage.md#interface-tableoutputtag)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindOutputsArgs

```ts
export interface FindOutputsArgs extends FindSincePagedArgs {
    partial: Partial<TableOutput>;
    noScript?: boolean;
    txStatus?: TransactionStatus[];
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs), [TableOutput](./storage.md#interface-tableoutput), [TransactionStatus](./client.md#type-transactionstatus)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindPartialSincePagedArgs

```ts
export interface FindPartialSincePagedArgs<T extends object> extends FindSincePagedArgs {
    partial: Partial<T>;
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindProvenTxReqsArgs

```ts
export interface FindProvenTxReqsArgs extends FindSincePagedArgs {
    partial: Partial<TableProvenTxReq>;
    status?: ProvenTxReqStatus[];
    txids?: string[];
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs), [ProvenTxReqStatus](./client.md#type-proventxreqstatus), [TableProvenTxReq](./storage.md#interface-tableproventxreq)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindProvenTxsArgs

```ts
export interface FindProvenTxsArgs extends FindSincePagedArgs {
    partial: Partial<TableProvenTx>;
    txids?: string[];
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs), [TableProvenTx](./storage.md#interface-tableproventx)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindSincePagedArgs

```ts
export interface FindSincePagedArgs {
    since?: Date;
    paged?: Paged;
    trx?: TrxToken;
    orderDescending?: boolean;
}
```

See also: [Paged](./client.md#interface-paged), [TrxToken](./client.md#interface-trxtoken)

###### Property orderDescending

Support for orderDescending is implemented in StorageKnex for basic table find methods,
excluding certificate_fields table, map tables, and settings (singleton row table).

```ts
orderDescending?: boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindStaleMerkleRootsArgs

```ts
export interface FindStaleMerkleRootsArgs {
    height: number;
    merkleRoot: string;
    trx?: TrxToken;
}
```

See also: [TrxToken](./client.md#interface-trxtoken)

###### Property merkleRoot

The current valid merkle root for the given height.
Any proven transaction with a different merkle root at this height is considered to have a stale proof.

```ts
merkleRoot: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindSyncStatesArgs

```ts
export interface FindSyncStatesArgs extends FindSincePagedArgs {
    partial: Partial<TableSyncState>;
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs), [TableSyncState](./storage.md#interface-tablesyncstate)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindTransactionsArgs

```ts
export interface FindTransactionsArgs extends FindSincePagedArgs {
    partial: Partial<TableTransaction>;
    status?: TransactionStatus[];
    from?: Date;
    to?: Date;
    noRawTx?: boolean;
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs), [TableTransaction](./storage.md#interface-tabletransaction), [TransactionStatus](./client.md#type-transactionstatus)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindTxLabelMapsArgs

```ts
export interface FindTxLabelMapsArgs extends FindSincePagedArgs {
    partial: Partial<TableTxLabelMap>;
    labelIds?: number[];
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs), [TableTxLabelMap](./storage.md#interface-tabletxlabelmap)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindTxLabelsArgs

```ts
export interface FindTxLabelsArgs extends FindSincePagedArgs {
    partial: Partial<TableTxLabel>;
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs), [TableTxLabel](./storage.md#interface-tabletxlabel)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: FindUsersArgs

```ts
export interface FindUsersArgs extends FindSincePagedArgs {
    partial: Partial<TableUser>;
}
```

See also: [FindSincePagedArgs](./client.md#interface-findsincepagedargs), [TableUser](./storage.md#interface-tableuser)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GenerateChangeSdkChangeInput

```ts
export interface GenerateChangeSdkChangeInput {
    outputId: number;
    satoshis: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GenerateChangeSdkChangeOutput

```ts
export interface GenerateChangeSdkChangeOutput {
    satoshis: number;
    lockingScriptLength: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GenerateChangeSdkInput

```ts
export interface GenerateChangeSdkInput {
    satoshis: number;
    unlockingScriptLength: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GenerateChangeSdkOutput

```ts
export interface GenerateChangeSdkOutput {
    satoshis: number;
    lockingScriptLength: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GenerateChangeSdkParams

```ts
export interface GenerateChangeSdkParams {
    fixedInputs: GenerateChangeSdkInput[];
    fixedOutputs: GenerateChangeSdkOutput[];
    feeModel: StorageFeeModel;
    targetNetCount?: number;
    changeInitialSatoshis: number;
    changeFirstSatoshis: number;
    changeLockingScriptLength: number;
    changeUnlockingScriptLength: number;
    maxChangeOutputs?: number;
    surplusPoolShaping?: boolean;
    maxMigrationInputs?: number;
    randomVals?: number[];
    noLogging?: boolean;
    log?: string;
}
```

See also: [GenerateChangeSdkInput](./storage.md#interface-generatechangesdkinput), [GenerateChangeSdkOutput](./storage.md#interface-generatechangesdkoutput), [StorageFeeModel](./client.md#interface-storagefeemodel)

###### Property changeFirstSatoshis

Lowest amount value to assign to a change output.
Drop the output if unable to satisfy.
default 285

```ts
changeFirstSatoshis: number
```

###### Property changeInitialSatoshis

Satoshi amount to initialize optional new change outputs.

```ts
changeInitialSatoshis: number
```

###### Property changeLockingScriptLength

Fixed change locking script length.

For P2PKH template, 25 bytes

```ts
changeLockingScriptLength: number
```

###### Property changeUnlockingScriptLength

Fixed change unlocking script length.

For P2PKH template, 107 bytes

```ts
changeUnlockingScriptLength: number
```

###### Property maxChangeOutputs

Maximum number of change outputs to create in this transaction.
Defaults to `maxChangeOutputsPerTransaction` (8). Set to -1 only when an
operator deliberately wants the basket target to be the sole bound.

Callers may override this to allow more outputs in special cases (e.g.
consolidation transactions) or fewer outputs when a compact transaction
is preferred.

```ts
maxChangeOutputs?: number
```

###### Property maxMigrationInputs

Soft bound on undersized, fee-positive inputs consumed after compulsory
funding to migrate an old wallet gradually. Set to -1 for an intentionally
unbounded migration pass. Ignored unless surplusPoolShaping is true.

```ts
maxMigrationInputs?: number
```

###### Property surplusPoolShaping

When true, targetNetCount shapes only genuine post-funding surplus. The
planner will not add inputs merely to reach the desired pool count.

```ts
surplusPoolShaping?: boolean
```

###### Property targetNetCount

Target for number of new change outputs added minus number of funding change outputs consumed.
If undefined, only a single change output will be added if excess fees must be recaptured.

```ts
targetNetCount?: number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GenerateChangeSdkResult

```ts
export interface GenerateChangeSdkResult {
    allocatedChangeInputs: GenerateChangeSdkChangeInput[];
    changeOutputs: GenerateChangeSdkChangeOutput[];
    size: number;
    fee: number;
    satsPerKb: number;
    maxPossibleSatoshisAdjustment?: {
        fixedOutputIndex: number;
        satoshis: number;
    };
}
```

See also: [GenerateChangeSdkChangeInput](./storage.md#interface-generatechangesdkchangeinput), [GenerateChangeSdkChangeOutput](./storage.md#interface-generatechangesdkchangeoutput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GenerateChangeSdkStorageChange

```ts
export interface GenerateChangeSdkStorageChange extends GenerateChangeSdkChangeInput {
    spendable: boolean;
}
```

See also: [GenerateChangeSdkChangeInput](./storage.md#interface-generatechangesdkchangeinput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GetMerklePathResult

Properties on result returned from `WalletServices` function `getMerkleProof`.

```ts
export interface GetMerklePathResult {
    name?: string;
    merklePath?: MerklePath;
    header?: BlockHeader;
    error?: WalletError;
    notes?: ReqHistoryNote[];
}
```

See also: [BlockHeader](./client.md#interface-blockheader), [ReqHistoryNote](./client.md#interface-reqhistorynote), [WalletError](./client.md#class-walleterror)

###### Property error

The first exception error that occurred during processing, if any.

```ts
error?: WalletError
```
See also: [WalletError](./client.md#class-walleterror)

###### Property merklePath

Multiple proofs may be returned when a transaction also appears in
one or more orphaned blocks

```ts
merklePath?: MerklePath
```

###### Property name

The name of the service returning the proof, or undefined if no proof

```ts
name?: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GetRawTxResult

Properties on result returned from `WalletServices` function `getRawTx`.

```ts
export interface GetRawTxResult {
    txid: string;
    name?: string;
    rawTx?: number[];
    error?: WalletError;
}
```

See also: [WalletError](./client.md#class-walleterror)

###### Property error

The first exception error that occurred during processing, if any.

```ts
error?: WalletError
```
See also: [WalletError](./client.md#class-walleterror)

###### Property name

The name of the service returning the rawTx, or undefined if no rawTx

```ts
name?: string
```

###### Property rawTx

Multiple proofs may be returned when a transaction also appears in
one or more orphaned blocks

```ts
rawTx?: number[]
```

###### Property txid

Transaction hash or rawTx (and of initial request)

```ts
txid: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GetReqsAndBeefDetail

```ts
export interface GetReqsAndBeefDetail {
    txid: string;
    req?: TableProvenTxReq;
    proven?: TableProvenTx;
    status: "readyToSend" | "alreadySent" | "error" | "unknown";
    error?: string;
}
```

See also: [TableProvenTx](./storage.md#interface-tableproventx), [TableProvenTxReq](./storage.md#interface-tableproventxreq)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GetReqsAndBeefResult

```ts
export interface GetReqsAndBeefResult {
    beef: Beef;
    details: GetReqsAndBeefDetail[];
    verified?: boolean;
}
```

See also: [GetReqsAndBeefDetail](./storage.md#interface-getreqsandbeefdetail)

###### Property verified

Internal fast path: this exact BEEF instance already passed validation.

```ts
verified?: boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GetScriptHashHistory

```ts
export interface GetScriptHashHistory {
    txid: string;
    height?: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GetScriptHashHistoryResult

```ts
export interface GetScriptHashHistoryResult {
    name: string;
    status: "success" | "error";
    error?: WalletError;
    history: GetScriptHashHistory[];
}
```

See also: [GetScriptHashHistory](./client.md#interface-getscripthashhistory), [WalletError](./client.md#class-walleterror)

###### Property error

When status is 'error', provides code and description

```ts
error?: WalletError
```
See also: [WalletError](./client.md#class-walleterror)

###### Property history

Transaction txid (and height if mined) that consumes the script hash. May not be a complete history.

```ts
history: GetScriptHashHistory[]
```
See also: [GetScriptHashHistory](./client.md#interface-getscripthashhistory)

###### Property name

The name of the service to which the transaction was submitted for processing

```ts
name: string
```

###### Property status

'success' - the operation was successful, non-error results are valid.
'error' - the operation failed, error may have relevant information.

```ts
status: "success" | "error"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GetStatusForTxidsResult

```ts
export interface GetStatusForTxidsResult {
    name: string;
    status: "success" | "error";
    error?: WalletError;
    results: StatusForTxidResult[];
}
```

See also: [StatusForTxidResult](./client.md#interface-statusfortxidresult), [WalletError](./client.md#class-walleterror)

###### Property error

The first exception error that occurred during processing, if any.

```ts
error?: WalletError
```
See also: [WalletError](./client.md#class-walleterror)

###### Property name

The name of the service returning these results.

```ts
name: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GetUtxoStatusDetails

```ts
export interface GetUtxoStatusDetails {
    height?: number;
    txid?: string;
    index?: number;
    satoshis?: number;
}
```

###### Property height

if isUtxo, the block height containing the matching unspent transaction output

typically there will be only one, but future orphans can result in multiple values

```ts
height?: number
```

###### Property index

if isUtxo, the output index in the transaction containing of the matching unspent transaction output

typically there will be only one, but future orphans can result in multiple values

```ts
index?: number
```

###### Property satoshis

if isUtxo, the amount of the matching unspent transaction output

typically there will be only one, but future orphans can result in multiple values

```ts
satoshis?: number
```

###### Property txid

if isUtxo, the transaction hash (txid) of the transaction containing the matching unspent transaction output

typically there will be only one, but future orphans can result in multiple values

```ts
txid?: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GetUtxoStatusResult

```ts
export interface GetUtxoStatusResult {
    name: string;
    status: "success" | "error";
    error?: WalletError;
    isUtxo?: boolean;
    details: GetUtxoStatusDetails[];
}
```

See also: [GetUtxoStatusDetails](./client.md#interface-getutxostatusdetails), [WalletError](./client.md#class-walleterror)

###### Property details

Additional details about occurances of this output script as a utxo.

Normally there will be one item in the array but due to the possibility of orphan races
there could be more than one block in which it is a valid utxo.

```ts
details: GetUtxoStatusDetails[]
```
See also: [GetUtxoStatusDetails](./client.md#interface-getutxostatusdetails)

###### Property error

When status is 'error', provides code and description

```ts
error?: WalletError
```
See also: [WalletError](./client.md#class-walleterror)

###### Property isUtxo

true if the output is associated with at least one unspent transaction output

```ts
isUtxo?: boolean
```

###### Property name

The name of the service to which the transaction was submitted for processing

```ts
name: string
```

###### Property status

'success' - the operation was successful, non-error results are valid.
'error' - the operation failed, error may have relevant information.

```ts
status: "success" | "error"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: GoChaintracksServiceClientOptions

```ts
export interface GoChaintracksServiceClientOptions {
    apiPrefix?: string;
    fetch?: typeof fetch;
    requestTimeoutMsecs?: number;
    reconnectWaitMsecs?: number;
    reconnectWaitMaxMsecs?: number;
    maxJsonResponseBytes?: number;
    maxBinaryResponseBytes?: number;
    maxSseEventBytes?: number;
    maxReorgHeaders?: number;
    streamIdleTimeoutMsecs?: number;
}
```

###### Property apiPrefix

Path prefix for the go-chaintracks HTTP API.
Arcade exposes this at `/chaintracks/v2`.

```ts
apiPrefix?: string
```

###### Property maxBinaryResponseBytes

Maximum binary header response size. Default: 32 MiB.

```ts
maxBinaryResponseBytes?: number
```

###### Property maxJsonResponseBytes

Maximum decoded JSON response size. Default: 1 MiB.

```ts
maxJsonResponseBytes?: number
```

###### Property maxReorgHeaders

Maximum number of deactivated headers accepted in one reorg event. Default: 4096.

```ts
maxReorgHeaders?: number
```

###### Property maxSseEventBytes

Maximum size of one incomplete or complete SSE event. Default: 1 MiB.

```ts
maxSseEventBytes?: number
```

###### Property reconnectWaitMaxMsecs

Maximum SSE reconnect delay.

```ts
reconnectWaitMaxMsecs?: number
```

###### Property reconnectWaitMsecs

Initial delay before reconnecting a closed or failed SSE stream.

```ts
reconnectWaitMsecs?: number
```

###### Property requestTimeoutMsecs

Timeout for HTTP requests and the initial SSE handshake.

```ts
requestTimeoutMsecs?: number
```

###### Property streamIdleTimeoutMsecs

Maximum delay between SSE chunks before reconnecting. Default: 45 seconds.

```ts
streamIdleTimeoutMsecs?: number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: HeightRangeApi

```ts
export interface HeightRangeApi {
    minHeight: number;
    maxHeight: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: HeightRanges

```ts
export interface HeightRanges {
    bulk: HeightRange;
    live: HeightRange;
}
```

See also: [HeightRange](./services.md#class-heightrange)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: KeyPair

```ts
export interface KeyPair {
    privateKey: string;
    publicKey: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: LiveBlockHeader

The "live" portion of the block chain is recent history that can conceivably be subject to reorganizations.
The additional fields support tracking orphan blocks, chain forks, and chain reorgs.

```ts
export interface LiveBlockHeader extends BlockHeader {
    chainWork: string;
    isChainTip: boolean;
    isActive: boolean;
    headerId: number;
    previousHeaderId: number | null;
}
```

See also: [BlockHeader](./client.md#interface-blockheader)

###### Property chainWork

The cumulative chainwork achieved by the addition of this block to the chain.
Chainwork only matters in selecting the active chain.

```ts
chainWork: string
```

###### Property headerId

As there may be more than one header with identical height values due to orphan tracking,
headers are assigned a unique headerId while part of the "live" portion of the block chain.

```ts
headerId: number
```

###### Property isActive

True only if this header is currently on the active chain.

```ts
isActive: boolean
```

###### Property isChainTip

True only if this header is currently a chain tip. e.g. There is no header that follows it by previousHash or previousHeaderId.

```ts
isChainTip: boolean
```

###### Property previousHeaderId

Every header in the "live" portion of the block chain is linked to an ancestor header through
both its previousHash and previousHeaderId properties.

Due to forks, there may be multiple headers with identical `previousHash` and `previousHeaderId` values.
Of these, only one (the header on the active chain) will have `isActive` === true.

```ts
previousHeaderId: number | null
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ManagedChangeBasketDefaults

```ts
export interface ManagedChangeBasketDefaults {
    name: string;
    numberOfDesiredUTXOs: number;
    minimumDesiredUTXOValue: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ManagedChangePolicy

```ts
export interface ManagedChangePolicy {
    maxOutputsPerAction: number;
    migrationInputsPerAction: number;
    pendingComparisonInputs: number;
}
```

###### Property maxOutputsPerAction

Maximum change outputs created by one action while growing the pool; -1 is unlimited.

```ts
maxOutputsPerAction: number
```

###### Property migrationInputsPerAction

Maximum undersized, fee-positive inputs consumed only to improve the pool; -1 is unlimited.

```ts
migrationInputsPerAction: number
```

###### Property pendingComparisonInputs

A completed-only plan above this input count is compared with pending
alternatives using exact BEEF bytes. This is a comparison trigger, never
a funding limit. -1 disables pending comparison until settled funding is
actually insufficient.

```ts
pendingComparisonInputs: number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: MerklePathNote

```ts
export interface MerklePathNote {
    what: MerklePathNoteWhat;
    name: string;
    status?: number;
    statusText?: string;
    target?: string;
    code?: string;
    description?: string;
    [key: string]: boolean | string | number | undefined;
}
```

See also: [MerklePathNoteWhat](./services.md#type-merklepathnotewhat)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: MerkleRootValidator

```ts
export interface MerkleRootValidator {
    isValidRootForHeight(root: string, height: number): Promise<boolean>;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: MockChainBlockHeaderRow

```ts
export interface MockChainBlockHeaderRow {
    height: number;
    hash: string;
    previousHash: string;
    merkleRoot: string;
    version: number;
    time: number;
    bits: number;
    nonce: number;
    coinbaseTxid: string;
    created_at?: Date | string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: MockChainTransactionRow

```ts
export interface MockChainTransactionRow {
    txid: string;
    rawTx: number[] | Buffer | Uint8Array;
    blockHeight: number | null;
    blockIndex: number | null;
    created_at?: Date | string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: MockChainUtxoRow

```ts
export interface MockChainUtxoRow {
    id?: number;
    txid: string;
    vout: number;
    lockingScript: number[] | Buffer | Uint8Array;
    satoshis: number;
    scriptHash: string;
    spentByTxid: string | null;
    isCoinbase: boolean;
    blockHeight: number | null;
    created_at?: Date | string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: MonitorOptions

```ts
export interface MonitorOptions {
    chain: Chain;
    services: Services | WalletServices;
    storage: MonitorStorage;
    chaintracks: ChaintracksClientApi;
    chaintracksWithEvents?: ChaintracksClientApi;
    maxQueuedDeactivatedHeaders?: number;
    logging?: (...args: unknown[]) => void;
    startupTaskMode?: MonitorStartupTaskMode;
    msecsWaitPerMerkleProofServiceReq: number;
    taskRunWaitMsecs: number;
    abandonedMsecs: number;
    unprovenAttemptsLimitTest: number;
    unprovenAttemptsLimitMain: number;
    maxRebroadcastAttempts: number;
    callbackToken?: string;
    loadLastSSEEventId?: () => Promise<string | undefined>;
    saveLastSSEEventId?: (lastEventId: string) => Promise<void>;
    EventSourceClass?: any;
    onTransactionBroadcasted?: (broadcastResult: ReviewActionResult) => Promise<void>;
    onTransactionProven?: (txStatus: ProvenTransactionStatus) => Promise<void>;
    onTransactionStatusChanged?: (txid: string, newStatus: string) => Promise<void>;
}
```

See also: [Chain](./client.md#type-chain), [ChaintracksClientApi](./services.md#interface-chaintracksclientapi), [MonitorStartupTaskMode](./monitor.md#type-monitorstartuptaskmode), [MonitorStorage](./monitor.md#type-monitorstorage), [ProvenTransactionStatus](./client.md#interface-proventransactionstatus), [ReviewActionResult](./client.md#interface-reviewactionresult), [Services](./services.md#class-services), [WalletServices](./client.md#interface-walletservices)

###### Property EventSourceClass

The react-native-sse EventSource class for SSE support in React Native

```ts
EventSourceClass?: any
```

###### Property callbackToken

Stable callback token for ARC SSE event streaming.
When set, TaskArcadeSSE will open an SSE connection to Arcade's
/events endpoint and receive real-time transaction status updates.
Must match the X-CallbackToken header sent during broadcast.

```ts
callbackToken?: string
```

###### Property loadLastSSEEventId

Load persisted SSE lastEventId (e.g. from SQLite) for catchup on startup

```ts
loadLastSSEEventId?: () => Promise<string | undefined>
```

###### Property logging

Optional bounded operational logger. Monitor library code is silent by default.

```ts
logging?: (...args: unknown[]) => void
```

###### Property maxQueuedDeactivatedHeaders

Maximum deactivated block headers retained for reproof. Default: 4096.

```ts
maxQueuedDeactivatedHeaders?: number
```

###### Property maxRebroadcastAttempts

Maximum number of times a broadcast transaction may be reset to 'unsent' for
rebroadcast after proof check timeout (circuit breaker).

Default 0 means unlimited — the tx is rebroadcast indefinitely until a proof
is found. Set to a positive integer to cap rebroadcast cycles; once the limit
is reached the req is marked 'invalid'.

```ts
maxRebroadcastAttempts: number
```

###### Property msecsWaitPerMerkleProofServiceReq

How many msecs to wait after each getMerkleProof service request.

```ts
msecsWaitPerMerkleProofServiceReq: number
```

###### Property onTransactionBroadcasted

These are hooks for a wallet-toolbox client to get transaction updates.

```ts
onTransactionBroadcasted?: (broadcastResult: ReviewActionResult) => Promise<void>
```
See also: [ReviewActionResult](./client.md#interface-reviewactionresult)

###### Property saveLastSSEEventId

Save SSE lastEventId to persistent storage

```ts
saveLastSSEEventId?: (lastEventId: string) => Promise<void>
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: NoSendExpiryLifecycleResult

```ts
export interface NoSendExpiryLifecycleResult {
    inspected: number;
    cancelled: number;
    observed: number;
    reclaimActivated: number;
    reclaimRetried: number;
    reclaimed: number;
    targetWon: number;
    deferred: number;
    errors: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: NormalizedArcProviderConfig

```ts
export interface NormalizedArcProviderConfig {
    apiKey?: string;
    httpClient: HttpClient;
    deploymentId: string;
    callbackUrl?: string;
    callbackToken?: string;
    headers?: Readonly<Record<string, string>>;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: OutPoint

Identifies a unique transaction output by its `txid` and index `vout`

```ts
export interface OutPoint {
    txid: string;
    vout: number;
}
```

###### Property txid

Transaction double sha256 hash as big endian hex string

```ts
txid: string
```

###### Property vout

zero based output index within the transaction

```ts
vout: number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: OutputUtxoClassification

```ts
export interface OutputUtxoClassification {
    verdict: OutputUtxoVerdict;
    provider: string;
    error?: unknown;
}
```

See also: [OutputUtxoVerdict](./services.md#type-outpututxoverdict)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: Paged

```ts
export interface Paged {
    limit: number;
    offset?: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PendingSignAction

```ts
export interface PendingSignAction {
    reference: string;
    dcr: StorageCreateActionResult;
    args: Validation.ValidCreateActionArgs;
    tx: BsvTransaction;
    amount: number;
    pdi: PendingStorageInput[];
}
```

See also: [PendingStorageInput](./client.md#interface-pendingstorageinput), [StorageCreateActionResult](./client.md#interface-storagecreateactionresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PendingStorageInput

```ts
export interface PendingStorageInput {
    vin: number;
    derivationPrefix: string;
    derivationSuffix: string;
    unlockerPubKey?: string;
    sourceSatoshis: number;
    lockingScript: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PlannerOutput

```ts
export interface PlannerOutput extends ActionBatchFundingOutput {
    basketName?: string;
    tags?: string[];
}
```

See also: [ActionBatchFundingOutput](./client.md#interface-actionbatchfundingoutput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PostBeefResult

```ts
export interface PostBeefResult extends PostTxsResult {
}
```

See also: [PostTxsResult](./client.md#interface-posttxsresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PostBeefResultForTxidApi

```ts
export interface PostBeefResultForTxidApi {
    txid: string;
    status: "success" | "error";
    alreadyKnown?: boolean;
    blockHash?: string;
    blockHeight?: number;
    merklePath?: string;
}
```

See also: [blockHash](./services.md#function-blockhash)

###### Property alreadyKnown

if true, the transaction was already known to this service. Usually treat as a success.

Potentially stop posting to additional transaction processors.

```ts
alreadyKnown?: boolean
```

###### Property status

'success' - The transaction was accepted for processing

```ts
status: "success" | "error"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PostReqsToNetworkDetails

```ts
export interface PostReqsToNetworkDetails {
    txid: string;
    req: EntityProvenTxReq;
    status: PostReqsToNetworkDetailsStatus;
    competingTxs?: string[];
}
```

See also: [EntityProvenTxReq](./storage.md#class-entityproventxreq), [PostReqsToNetworkDetailsStatus](./storage.md#type-postreqstonetworkdetailsstatus)

###### Property competingTxs

Any competing double spend txids reported for this txid

```ts
competingTxs?: string[]
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PostReqsToNetworkResult

```ts
export interface PostReqsToNetworkResult {
    status: "success" | "error";
    beef: Beef;
    details: PostReqsToNetworkDetails[];
    log: string;
}
```

See also: [PostReqsToNetworkDetails](./storage.md#interface-postreqstonetworkdetails)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PostTxResultForTxid

```ts
export interface PostTxResultForTxid {
    txid: string;
    status: "success" | "error";
    alreadyKnown?: boolean;
    doubleSpend?: boolean;
    blockHash?: string;
    blockHeight?: number;
    merklePath?: MerklePath;
    competingTxs?: string[];
    data?: object | string | PostTxResultForTxidError;
    notes?: ReqHistoryNote[];
    serviceError?: boolean;
}
```

See also: [PostTxResultForTxidError](./client.md#interface-posttxresultfortxiderror), [ReqHistoryNote](./client.md#interface-reqhistorynote), [blockHash](./services.md#function-blockhash)

###### Property alreadyKnown

if true, the transaction was already known to this service. Usually treat as a success.

Potentially stop posting to additional transaction processors.

```ts
alreadyKnown?: boolean
```

###### Property doubleSpend

service indicated this broadcast double spends at least one input
`competingTxs` may be an array of txids that were first seen spends of at least one input.

```ts
doubleSpend?: boolean
```

###### Property serviceError

true iff service was unable to process a potentially valid transaction

```ts
serviceError?: boolean
```

###### Property status

'success' - The transaction was accepted for processing

```ts
status: "success" | "error"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PostTxResultForTxidError

```ts
export interface PostTxResultForTxidError {
    status?: string;
    detail?: string;
    more?: object;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PostTxsResult

Properties on array items of result returned from `WalletServices` function `postBeef`.

```ts
export interface PostTxsResult {
    name: string;
    status: "success" | "error";
    error?: WalletError;
    txidResults: PostTxResultForTxid[];
    data?: object;
    notes?: ReqHistoryNote[];
}
```

See also: [PostTxResultForTxid](./client.md#interface-posttxresultfortxid), [ReqHistoryNote](./client.md#interface-reqhistorynote), [WalletError](./client.md#class-walleterror)

###### Property data

Service response object. Use service name and status to infer type of object.

```ts
data?: object
```

###### Property name

The name of the service to which the transaction was submitted for processing

```ts
name: string
```

###### Property status

'success' all txids returned status of 'success'
'error' one or more txids returned status of 'error'. See txidResults for details.

```ts
status: "success" | "error"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PrepareActionBatchCommitResult

```ts
export interface PrepareActionBatchCommitResult {
    missingDigests: string[];
    maxBlobBytes: number;
    maxConcurrentUploads: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PreparedBeefLookupResult

```ts
export interface PreparedBeefLookupResult {
    beef: Beef;
    hitTxids: string[];
    missingTxids: string[];
    corruptCount: number;
    byteLength: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PreparedBeefOptions

```ts
export interface PreparedBeefOptions {
    readEnabled?: boolean;
    writeEnabled?: boolean;
    backfillEnabled?: boolean;
    maxQueueSize?: number;
    maxQueueSizePerUser?: number;
    maxArtifactBytes?: number;
    maxLookupBytes?: number;
    maxArtifactTransactions?: number;
    backfillBatchSize?: number;
    backfillIntervalMs?: number;
}
```

###### Property backfillBatchSize

Maximum roots selected by each low-priority backfill pass.

```ts
backfillBatchSize?: number
```

###### Property backfillEnabled

Gradually prepare existing eligible managed-change roots. Default false.

```ts
backfillEnabled?: boolean
```

###### Property backfillIntervalMs

Delay between backfill passes.

```ts
backfillIntervalMs?: number
```

###### Property maxArtifactBytes

Reject a prepared artifact larger than this many bytes.

```ts
maxArtifactBytes?: number
```

###### Property maxArtifactTransactions

Reject source or prepared BEEF graphs with more transactions.

```ts
maxArtifactTransactions?: number
```

###### Property maxLookupBytes

Bypass prepared lookup when all matching artifacts exceed this total.

```ts
maxLookupBytes?: number
```

###### Property maxQueueSize

Maximum queued roots. New background work is dropped when full.

```ts
maxQueueSize?: number
```

###### Property maxQueueSizePerUser

Maximum queued or running roots for one user.

```ts
maxQueueSizePerUser?: number
```

###### Property readEnabled

Read prepared artifacts on the createAction proof path. Default false.

```ts
readEnabled?: boolean
```

###### Property writeEnabled

Prepare and persist artifacts after foreground work completes. Default false.

```ts
writeEnabled?: boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PreparedBeefPolicy

```ts
export interface PreparedBeefPolicy {
    readEnabled: boolean;
    writeEnabled: boolean;
    backfillEnabled: boolean;
    maxQueueSize: number;
    maxQueueSizePerUser: number;
    maxArtifactBytes: number;
    maxLookupBytes: number;
    maxArtifactTransactions: number;
    backfillBatchSize: number;
    backfillIntervalMs: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PreparedBeefPreparation

```ts
export interface PreparedBeefPreparation {
    userId: number;
    rootTxids: string[];
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PreparedBeefRoot

```ts
export interface PreparedBeefRoot {
    userId: number;
    rootTxid: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PreparedBeefStorage

Knex-owned extension used without adding server cache code to portable providers.

```ts
export interface PreparedBeefStorage extends Pick<StorageProvider, "telemetry" | "getBeefForTransaction" | "getServices"> {
    readonly preparedBeefPolicy: PreparedBeefPolicy;
    preparedBeefReadsEnabled?: () => boolean;
    findPreparedBeefs: (userId: number, rootTxids: string[]) => Promise<TablePreparedBeef[]>;
    readPreparedBeefLookupByteLength: (userId: number, rootTxids: string[]) => Promise<number>;
    readPreparedBeefProofEpoch: () => Promise<number>;
    readPreparedBeefSourceByteLength: (rootTxid: string) => Promise<number | undefined>;
    upsertPreparedBeef: (artifact: TablePreparedBeef, expectedProofEpoch: number) => Promise<boolean>;
    findPreparedBeefBackfillRoots: (limit: number, formatVersion: number) => Promise<PreparedBeefRoot[]>;
}
```

See also: [PreparedBeefPolicy](./storage.md#interface-preparedbeefpolicy), [PreparedBeefRoot](./storage.md#interface-preparedbeefroot), [StorageProvider](./storage.md#class-storageprovider), [TablePreparedBeef](./storage.md#interface-tablepreparedbeef)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ProcessSyncChunkResult

```ts
export interface ProcessSyncChunkResult {
    nextCheckpoint?: SyncCheckpoint;
    done: boolean;
    maxUpdated_at: Date | undefined;
    updates: number;
    inserts: number;
    error?: WalletError;
}
```

See also: [SyncCheckpoint](./client.md#interface-synccheckpoint), [WalletError](./client.md#class-walleterror)

###### Property nextCheckpoint

Present only when requested, after the page and checkpoint commit together.

```ts
nextCheckpoint?: SyncCheckpoint
```
See also: [SyncCheckpoint](./client.md#interface-synccheckpoint)

###### Property error

Optional non-throwing failure from a custom writer. First-party
`StorageProvider` implementations throw instead of setting this field.
`WalletStorageManager.syncToWriter` and `syncFromReader` throw `error`
immediately and do not request another chunk.

```ts
error?: WalletError
```
See also: [WalletError](./client.md#class-walleterror)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ProvenOrRawTx

```ts
export interface ProvenOrRawTx {
    proven?: TableProvenTx;
    rawTx?: number[];
    inputBEEF?: BEEF;
}
```

See also: [TableProvenTx](./storage.md#interface-tableproventx)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ProvenTransactionStatus

The transaction status that a client will receive when subscribing to transaction updates in the Monitor.

```ts
export interface ProvenTransactionStatus {
    txid: string;
    txIndex: number;
    blockHeight: number;
    blockHash: string;
    merklePath: number[];
    merkleRoot: string;
}
```

See also: [blockHash](./services.md#function-blockhash)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ProvenTxFromTxidResult

```ts
export interface ProvenTxFromTxidResult {
    proven?: EntityProvenTx;
    rawTx?: number[];
}
```

See also: [EntityProvenTx](./storage.md#class-entityproventx)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ProvenTxReqHistory

```ts
export interface ProvenTxReqHistory {
    notes?: ReqHistoryNote[];
}
```

See also: [ReqHistoryNote](./client.md#interface-reqhistorynote)

###### Property notes

Keys are Date().toISOString()
Values are a description of what happened.

```ts
notes?: ReqHistoryNote[]
```
See also: [ReqHistoryNote](./client.md#interface-reqhistorynote)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ProvenTxReqHistorySummaryApi

```ts
export interface ProvenTxReqHistorySummaryApi {
    setToCompleted: boolean;
    setToCallback: boolean;
    setToUnmined: boolean;
    setToDoubleSpend: boolean;
    setToSending: boolean;
    setToUnconfirmed: boolean;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ProvenTxReqNotify

```ts
export interface ProvenTxReqNotify {
    transactionIds?: number[];
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ProviderCallHistory

History of service calls for a single service, single provider.

```ts
export interface ProviderCallHistory {
    providerName: string;
    serviceName: string;
    calls: ServiceCall[];
    totalCounts: ServiceCallHistoryCounts;
    resetCounts: ServiceCallHistoryCounts[];
}
```

See also: [ServiceCall](./services.md#interface-servicecall), [ServiceCallHistoryCounts](./client.md#interface-servicecallhistorycounts)

###### Property calls

Most recent service calls.
Array length is limited by Services configuration.

```ts
calls: ServiceCall[]
```
See also: [ServiceCall](./services.md#interface-servicecall)

###### Property resetCounts

Entry [0] is always the current interval being extended by new calls.
when `getServiceCallHistory` with `reset` true is called, a new interval with zero counts is added to the start of array.
Array length is limited by Services configuration.

```ts
resetCounts: ServiceCallHistoryCounts[]
```
See also: [ServiceCallHistoryCounts](./client.md#interface-servicecallhistorycounts)

###### Property totalCounts

Counts since creation of Services instance.

```ts
totalCounts: ServiceCallHistoryCounts
```
See also: [ServiceCallHistoryCounts](./client.md#interface-servicecallhistorycounts)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PurgeParams

```ts
export interface PurgeParams {
    purgeCompleted: boolean;
    purgeFailed: boolean;
    purgeSpent: boolean;
    purgeCompletedAge?: number;
    purgeFailedAge?: number;
    purgeSpentAge?: number;
}
```

###### Property purgeCompletedAge

Minimum age in msecs for transient completed transaction data purge.
Default is 14 days.

```ts
purgeCompletedAge?: number
```

###### Property purgeFailedAge

Minimum age in msecs for failed transaction data purge.
Default is 14 days.

```ts
purgeFailedAge?: number
```

###### Property purgeSpentAge

Minimum age in msecs for failed transaction data purge.
Default is 14 days.

```ts
purgeSpentAge?: number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PurgeResults

```ts
export interface PurgeResults {
    count: number;
    log: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PutActionBatchBlobArgs

```ts
export interface PutActionBatchBlobArgs {
    batchId: string;
    digest: string;
    bytes: number[] | Uint8Array;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: PutActionBatchPackArgs

```ts
export interface PutActionBatchPackArgs {
    batchId: string;
    items: ActionBatchPackItem[];
    maxPackBytes: number;
    maxItems: number;
    preferredEncodings?: ActionBatchPackEncoding[];
}
```

See also: [ActionBatchPackEncoding](./client.md#type-actionbatchpackencoding), [ActionBatchPackItem](./client.md#interface-actionbatchpackitem)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: RenewActionBatchResult

```ts
export interface RenewActionBatchResult {
    expiresAt: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ReorgResult

```ts
export interface ReorgResult {
    oldTip: BlockHeader;
    newTip: BlockHeader;
    deactivatedHeaders: BlockHeader[];
}
```

See also: [BlockHeader](./client.md#interface-blockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ReproveHeaderResult

Returned results from WalletStorageManager reproveHeader method.

```ts
export interface ReproveHeaderResult {
    log: string;
    updated: Array<{
        was: TableProvenTx;
        update: Partial<TableProvenTx>;
        logUpdate: string;
    }>;
    unchanged: TableProvenTx[];
    unavailable: TableProvenTx[];
}
```

See also: [TableProvenTx](./storage.md#interface-tableproventx)

###### Property log

Human readable log of the reproveHeader process.

```ts
log: string
```

###### Property unavailable

List of proven_txs records that were checked but currently proof data is unavailable.

```ts
unavailable: TableProvenTx[]
```
See also: [TableProvenTx](./storage.md#interface-tableproventx)

###### Property unchanged

List of proven_txs records that were checked but currently available proof is unchanged.

```ts
unchanged: TableProvenTx[]
```
See also: [TableProvenTx](./storage.md#interface-tableproventx)

###### Property updated

List of proven_txs records that were updated with new proof data.

```ts
updated: Array<{
    was: TableProvenTx;
    update: Partial<TableProvenTx>;
    logUpdate: string;
}>
```
See also: [TableProvenTx](./storage.md#interface-tableproventx)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ReproveProvenResult

Returned results from WalletStorageManager reproveProven method.

```ts
export interface ReproveProvenResult {
    log: string;
    updated?: {
        update: Partial<TableProvenTx>;
        logUpdate: string;
    };
    unchanged: boolean;
    unavailable: boolean;
}
```

See also: [TableProvenTx](./storage.md#interface-tableproventx)

###### Property log

Human readable log of the reproveProven process.

```ts
log: string
```

###### Property unavailable

True if proof data for proven_txs record is currently unavailable.

```ts
unavailable: boolean
```

###### Property unchanged

True if proof data for proven_txs record was found to be unchanged.

```ts
unchanged: boolean
```

###### Property updated

Valid if proof data for proven_txs record is available and has changed.

```ts
updated?: {
    update: Partial<TableProvenTx>;
    logUpdate: string;
}
```
See also: [TableProvenTx](./storage.md#interface-tableproventx)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ReqHistoryNote

```ts
export interface ReqHistoryNote {
    when?: string;
    what: string;
    [key: string]: boolean | string | number | undefined;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: RequestSyncChunkArgs

```ts
export interface RequestSyncChunkArgs {
    includeNextCheckpoint?: boolean;
    syncStateId?: number;
    fromStorageIdentityKey: string;
    toStorageIdentityKey: string;
    requireMatchingCheckpoint?: boolean;
    identityKey: string;
    since?: Date;
    maxRoughSize: number;
    maxItems: number;
    includeTotals?: boolean;
    offsets: Array<{
        name: string;
        offset: number;
    }>;
}
```

###### Property fromStorageIdentityKey

The storageIdentityKey of the storage supplying the update SyncChunk data.

```ts
fromStorageIdentityKey: string
```

###### Property identityKey

The identity of whose data is being requested.

```ts
identityKey: string
```

###### Property includeNextCheckpoint

Request committed progress with the write response; legacy writers ignore it.

```ts
includeNextCheckpoint?: boolean
```

###### Property includeTotals

Include source-side record totals for this `since` window when the
provider can calculate them efficiently. Older providers ignore this
optional hint and remain wire-compatible.

```ts
includeTotals?: boolean
```

###### Property maxItems

The maximum number of items (records) to be returned.

```ts
maxItems: number
```

###### Property maxRoughSize

A rough limit on how large the response should be.
The item that exceeds the limit is included and ends adding more items.

```ts
maxRoughSize: number
```

###### Property offsets

For each entity in dependency order, the offset at which to start returning items
from `since`.

The entity order is:
0 ProvenTxs
1 ProvenTxReqs
2 OutputBaskets
3 TxLabels
4 OutputTags
5 Transactions
6 TxLabelMaps
7 Commissions
8 Outputs
9 OutputTagMaps
10 Certificates
11 CertificateFields

```ts
offsets: Array<{
    name: string;
    offset: number;
}>
```

###### Property requireMatchingCheckpoint

Require the writer checkpoint to still match before applying a staged transfer.

```ts
requireMatchingCheckpoint?: boolean
```

###### Property since

The max updated_at time received from the storage service receiving the request.
Will be undefiend if this is the first request or if no data was previously sync'ed.

`since` must include items if 'updated_at' is greater or equal. Thus, when not undefined, a sync request should always return at least one item already seen.

```ts
since?: Date
```

###### Property syncStateId

The writer-local sync state selected when the source provider was
registered. New clients include this to disambiguate legacy databases
that contain multiple rows for a reused storage identity key.

```ts
syncStateId?: number
```

###### Property toStorageIdentityKey

The storageIdentityKey of the storage consuming the update SyncChunk data.

```ts
toStorageIdentityKey: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ResumeActionBatchArgs

```ts
export interface ResumeActionBatchArgs {
    batchId: string;
    outpoints: Array<{
        txid: string;
        vout: number;
    }>;
}
```

###### Property outpoints

Exact persisted outputs still held by the client workspace.

```ts
outpoints: Array<{
    txid: string;
    vout: number;
}>
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ResumeActionBatchResult

```ts
export interface ResumeActionBatchResult extends RenewActionBatchResult {
}
```

See also: [RenewActionBatchResult](./client.md#interface-renewactionbatchresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ReviewActionResult

```ts
export interface ReviewActionResult {
    txid: TXIDHexString;
    status: ReviewActionResultStatus;
    competingTxs?: string[];
    competingBeef?: BEEF;
}
```

See also: [ReviewActionResultStatus](./client.md#type-reviewactionresultstatus)

###### Property competingBeef

Merged beef of competingTxs, valid when status is 'doubleSpend'.

```ts
competingBeef?: BEEF
```

###### Property competingTxs

Any competing txids reported for this txid, valid when status is 'doubleSpend'.

```ts
competingTxs?: string[]
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ReviewHeightRangeResult

```ts
export interface ReviewHeightRangeResult {
    log: string;
    reviewedHeights: number;
    mismatchedHeights: number;
    affectedTransactions: number;
    updatedTransactions: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ReviewUtxoOutputsResult

```ts
export interface ReviewUtxoOutputsResult {
    classifications: UtxoReviewClassification[];
    confirmedSpentOutputs: TableOutput[];
    unknownOutputs: TableOutput[];
    diagnostics: UtxoReviewDiagnostics;
}
```

See also: [TableOutput](./storage.md#interface-tableoutput), [UtxoReviewClassification](./storage.md#interface-utxoreviewclassification), [UtxoReviewDiagnostics](./storage.md#interface-utxoreviewdiagnostics)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ScriptHashHistoryResponse

```ts
export interface ScriptHashHistoryResponse {
    ok: boolean;
    status: number;
    statusText: string;
    data?: {
        result: Array<{
            tx_hash: string;
            height?: number;
        }>;
        error?: string;
    };
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ScriptTemplateParamsBRC29

```ts
export interface ScriptTemplateParamsBRC29 {
    derivationPrefix?: string;
    derivationSuffix?: string;
    keyDeriver: KeyDeriverApi;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ScriptTemplateUnlock

```ts
export interface ScriptTemplateUnlock {
    sign: (tx: Transaction, inputIndex: number) => Promise<UnlockingScript>;
    estimateLength: (tx: Transaction, inputIndex: number) => Promise<number>;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ServiceCall

Minimum data tracked for each service call.

```ts
export interface ServiceCall {
    when: Date | string;
    msecs: number;
    success: boolean;
    result?: string;
    error?: {
        message: string;
        code: string;
    };
}
```

###### Property error

Error code and message iff success is false and a exception was thrown.

```ts
error?: {
    message: string;
    code: string;
}
```

###### Property result

Simple text summary of result. e.g. `not a valid utxo` or `valid utxo`

```ts
result?: string
```

###### Property success

true iff service provider successfully processed the request
false iff service provider failed to process the request which includes thrown errors.

```ts
success: boolean
```

###### Property when

string value must be Date's toISOString format.

```ts
when: Date | string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ServiceCall

```ts
export interface ServiceCall {
    when: Date | string;
    msecs: number;
    success: boolean;
    result?: string;
    error?: {
        message: string;
        code: string;
    };
}
```

###### Property error

Error code and message iff success is false and a exception was thrown.

```ts
error?: {
    message: string;
    code: string;
}
```

###### Property result

Simple text summary of result. e.g. `not a valid utxo` or `valid utxo`

```ts
result?: string
```

###### Property success

true iff service provider successfully processed the request
false iff service provider failed to process the request which includes thrown errors.

```ts
success: boolean
```

###### Property when

string value must be Date's toISOString format.

```ts
when: Date | string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ServiceCallHistory

History of service calls for a single service, all providers.

```ts
export interface ServiceCallHistory {
    serviceName: string;
    historyByProvider: Record<string, ProviderCallHistory>;
}
```

See also: [ProviderCallHistory](./client.md#interface-providercallhistory)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ServiceCallHistoryCounts

Counts of service calls over a time interval.

```ts
export interface ServiceCallHistoryCounts {
    success: number;
    failure: number;
    error: number;
    since: Date | string;
    until: Date | string;
}
```

###### Property error

of failures (success false), count of calls with valid error code and message.

```ts
error: number
```

###### Property failure

count of calls returning success false.

```ts
failure: number
```

###### Property since

Counts are of calls over interval `since` to `until`.
string value must be Date's toISOString format.

```ts
since: Date | string
```

###### Property success

count of calls returning success true.

```ts
success: number
```

###### Property until

Counts are of calls over interval `since` to `until`.
string value must be Date's toISOString format.

```ts
until: Date | string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ServiceToCall

```ts
export interface ServiceToCall<T> {
    providerName: string;
    serviceName: string;
    service: T;
    call: ServiceCall;
}
```

See also: [ServiceCall](./services.md#interface-servicecall)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ServicesCallHistory

Type for the service call history returned by Services.getServicesCallHistory.

```ts
export interface ServicesCallHistory {
    version: number;
    getMerklePath: ServiceCallHistory;
    getRawTx: ServiceCallHistory;
    postBeef: ServiceCallHistory;
    getUtxoStatus: ServiceCallHistory;
    getStatusForTxids: ServiceCallHistory;
    getScriptHashHistory: ServiceCallHistory;
    updateFiatExchangeRates: ServiceCallHistory;
}
```

See also: [ServiceCallHistory](./client.md#interface-servicecallhistory)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: SignActionResultX

```ts
export interface SignActionResultX extends SignActionResult {
    txid?: TXIDHexString;
    tx?: AtomicBEEF;
    sendWithResults?: SendWithResult[];
    notDelayedResults?: ReviewActionResult[];
}
```

See also: [ReviewActionResult](./client.md#interface-reviewactionresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: SnapshotMerklePathResult

```ts
export interface SnapshotMerklePathResult extends Omit<GetMerklePathResult, "merklePath"> {
    merklePath?: MerklePath | MerklePath[];
}
```

See also: [GetMerklePathResult](./client.md#interface-getmerklepathresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: SpentInputTransition

```ts
export interface SpentInputTransition {
    outputId: number;
    setSpentBy: boolean;
}
```

###### Property setSpentBy

true if the call set spentBy; false if only spendable was flipped.

```ts
setSpentBy: boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StatusForTxidResult

```ts
export interface StatusForTxidResult {
    txid: string;
    depth: number | undefined;
    status: "mined" | "known" | "unknown";
    terminal?: boolean;
    inputConflict?: boolean;
    providerStatus?: string;
    statusCode?: number;
    description?: string;
    competingTxs?: string[];
}
```

###### Property competingTxs

Competing transaction ids reported by the provider.

```ts
competingTxs?: string[]
```

###### Property depth

roughly depth of block containing txid from chain tip.

```ts
depth: number | undefined
```

###### Property description

Bounded provider detail suitable for durable diagnostics.

```ts
description?: string
```

###### Property inputConflict

The terminal verdict proves this transaction lost an input conflict.

```ts
inputConflict?: boolean
```

###### Property providerStatus

Provider-native lifecycle status retained for reconciliation/audit.

```ts
providerStatus?: string
```

###### Property status

'mined' if depth > 0
'known' if depth === 0
'unknown' if depth === undefined, txid may be old an purged or never processed.

```ts
status: "mined" | "known" | "unknown"
```

###### Property statusCode

Provider-native status code when supplied.

```ts
statusCode?: number
```

###### Property terminal

Provider supplied a durable terminal lifecycle verdict for this txid.

```ts
terminal?: boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageActivateNoSendExpiryArgs

```ts
export interface StorageActivateNoSendExpiryArgs {
    target: Validation.ValidCreateActionArgs;
    fundingReference: string;
    fundingTxid: string;
    anchorVout: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageActivateNoSendExpiryResult

```ts
export interface StorageActivateNoSendExpiryResult {
    action: StorageCreateActionResult;
    expiry: Brc177NoSendExpiry;
    deadline: number;
    anchorTxid: string;
    anchorVout: number;
}
```

See also: [Brc177NoSendExpiry](./client.md#interface-brc177nosendexpiry), [StorageCreateActionResult](./client.md#interface-storagecreateactionresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageAdminStats

```ts
export interface StorageAdminStats {
    requestedBy: string;
    when: string;
    usersDay: number;
    usersWeek: number;
    usersMonth: number;
    usersTotal: number;
    transactionsDay: number;
    transactionsWeek: number;
    transactionsMonth: number;
    transactionsTotal: number;
    txCompletedDay: number;
    txCompletedWeek: number;
    txCompletedMonth: number;
    txCompletedTotal: number;
    txFailedDay: number;
    txFailedWeek: number;
    txFailedMonth: number;
    txFailedTotal: number;
    txAbandonedDay: number;
    txAbandonedWeek: number;
    txAbandonedMonth: number;
    txAbandonedTotal: number;
    txUnprocessedDay: number;
    txUnprocessedWeek: number;
    txUnprocessedMonth: number;
    txUnprocessedTotal: number;
    txSendingDay: number;
    txSendingWeek: number;
    txSendingMonth: number;
    txSendingTotal: number;
    txUnprovenDay: number;
    txUnprovenWeek: number;
    txUnprovenMonth: number;
    txUnprovenTotal: number;
    txUnsignedDay: number;
    txUnsignedWeek: number;
    txUnsignedMonth: number;
    txUnsignedTotal: number;
    txNosendDay: number;
    txNosendWeek: number;
    txNosendMonth: number;
    txNosendTotal: number;
    txNonfinalDay: number;
    txNonfinalWeek: number;
    txNonfinalMonth: number;
    txNonfinalTotal: number;
    txUnfailDay: number;
    txUnfailWeek: number;
    txUnfailMonth: number;
    txUnfailTotal: number;
    satoshisDefaultDay: number;
    satoshisDefaultWeek: number;
    satoshisDefaultMonth: number;
    satoshisDefaultTotal: number;
    satoshisOtherDay: number;
    satoshisOtherWeek: number;
    satoshisOtherMonth: number;
    satoshisOtherTotal: number;
    basketsDay: number;
    basketsWeek: number;
    basketsMonth: number;
    basketsTotal: number;
    labelsDay: number;
    labelsWeek: number;
    labelsMonth: number;
    labelsTotal: number;
    tagsDay: number;
    tagsWeek: number;
    tagsMonth: number;
    tagsTotal: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageArmNoSendExpiryArgs

```ts
export interface StorageArmNoSendExpiryArgs {
    reference: string;
    reclaimTxid: string;
    reclaimRawTx: number[] | Uint8Array;
    reclaimDerivationPrefix: string;
    reclaimDerivationSuffix: string;
    reclaimSatoshis: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageCapabilities

Internal Wallet Toolbox capabilities. These do not extend the BRC-100 wallet interface.

```ts
export interface StorageCapabilities {
    brc177NoSendExpiry?: {
        version: 1;
    };
    actionBatch?: {
        version: 1;
        maxInlineBytes: number;
        maxBlobBytes: number;
        maxConcurrentUploads: number;
        leaseMs: number;
        hardLifetimeMs: number;
        compactBegin?: boolean;
        manifestVersion?: 2;
        commitByDigest?: boolean;
        resume?: boolean;
        maxReservedOutputs?: number;
        packedUploads?: {
            version: 1;
            maxPackBytes: number;
            maxItems: number;
            encodings: ActionBatchPackEncoding[];
            eager: boolean;
        };
    };
}
```

See also: [ActionBatchPackEncoding](./client.md#type-actionbatchpackencoding)

###### Property brc177NoSendExpiry

Built-in BRC-177 pre-funding, durable expiry, and reclaim support.

```ts
brc177NoSendExpiry?: {
    version: 1;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageCreateActionResult

```ts
export interface StorageCreateActionResult {
    inputBeef?: number[] | Uint8Array;
    inputs: StorageCreateTransactionSdkInput[];
    outputs: StorageCreateTransactionSdkOutput[];
    noSendChangeOutputVouts?: number[];
    derivationPrefix: string;
    version: number;
    lockTime: number;
    reference: string;
}
```

See also: [StorageCreateTransactionSdkInput](./client.md#interface-storagecreatetransactionsdkinput), [StorageCreateTransactionSdkOutput](./client.md#interface-storagecreatetransactionsdkoutput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageCreateTransactionSdkInput

```ts
export interface StorageCreateTransactionSdkInput {
    vin: number;
    sourceTxid: string;
    sourceVout: number;
    sourceSatoshis: number;
    sourceLockingScript: string;
    sourceTransaction?: number[] | Uint8Array;
    unlockingScriptLength: number;
    providedBy: StorageProvidedBy;
    type: string;
    spendingDescription?: string;
    derivationPrefix?: string;
    derivationSuffix?: string;
    senderIdentityKey?: string;
}
```

See also: [StorageProvidedBy](./client.md#type-storageprovidedby)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageCreateTransactionSdkOutput

```ts
export interface StorageCreateTransactionSdkOutput extends Validation.ValidCreateActionOutput {
    vout: number;
    providedBy: StorageProvidedBy;
    purpose?: string;
    derivationSuffix?: string;
}
```

See also: [StorageProvidedBy](./client.md#type-storageprovidedby)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageFeeModel

Specifies the available options for computing transaction fees.

```ts
export interface StorageFeeModel {
    model: "sat/kb";
    value?: number;
}
```

###### Property model

Available models. Currently only "sat/kb" is supported.

```ts
model: "sat/kb"
```

###### Property value

When "fee.model" is "sat/kb", this is an integer representing the number of satoshis per kb of block space
the transaction will pay in fees.

If undefined, the default value is used.

```ts
value?: number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageGetBeefOptions

```ts
export interface StorageGetBeefOptions {
    trustSelf?: "known";
    knownTxids?: string[];
    mergeToBeef?: Beef | number[] | Uint8Array;
    maxConcurrency?: number;
    ignoreStorage?: boolean;
    ignoreServices?: boolean;
    ignoreNewProven?: boolean;
    minProofLevel?: number;
    chainTracker?: ChainTracker;
    skipInvalidProofs?: boolean;
}
```

###### Property chainTracker

optional. If valid, any merkleRoot that fails to validate will result in an exception without merging to `mergeToBeef`.

```ts
chainTracker?: ChainTracker
```

###### Property ignoreNewProven

optional. Default is false. If true, raw transactions with proofs missing from `storage` and obtained from `getServices` are not inserted to `storage`.

```ts
ignoreNewProven?: boolean
```

###### Property ignoreServices

optional. Default is false. `getServices` is used for raw transaction and merkle proof lookup

```ts
ignoreServices?: boolean
```

###### Property ignoreStorage

optional. Default is false. `storage` is used for raw transaction and merkle proof lookup

```ts
ignoreStorage?: boolean
```

###### Property knownTxids

list of txids to be included as txidOnly if referenced. Validity is known to caller.

```ts
knownTxids?: string[]
```

###### Property maxConcurrency

Maximum independent ancestor lookups to perform concurrently. Defaults to 8.

```ts
maxConcurrency?: number
```

###### Property mergeToBeef

optional. If defined, raw transactions and merkle paths required by txid are merged to this instance and returned. Otherwise a new Beef is constructed and returned.

```ts
mergeToBeef?: Beef | number[] | Uint8Array
```

###### Property minProofLevel

optional. Default is zero. Ignores available merkle paths until recursion detpth equals or exceeds value

```ts
minProofLevel?: number
```

###### Property skipInvalidProofs

optional. Default is false. If chainTracker is valid and an invalid proof is found: if true, pursues deeper beef. If false, throws WERR_INVALID_MERKLE_ROOT.

```ts
skipInvalidProofs?: boolean
```

###### Property trustSelf

if 'known', txids known to local storage as valid are included as txidOnly

```ts
trustSelf?: "known"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageIdentity

```ts
export interface StorageIdentity {
    storageIdentityKey: string;
    storageName: string;
}
```

###### Property storageIdentityKey

The identity key (public key) assigned to this storage

```ts
storageIdentityKey: string
```

###### Property storageName

The human readable name assigned to this storage.

```ts
storageName: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageInternalizeActionResult

```ts
export interface StorageInternalizeActionResult extends InternalizeActionResult {
    isMerge: boolean;
    txid: string;
    satoshis: number;
    sendWithResults?: SendWithResult[];
    notDelayedResults?: ReviewActionResult[];
}
```

See also: [ReviewActionResult](./client.md#interface-reviewactionresult)

###### Property isMerge

true if internalizing outputs on an existing storage transaction

```ts
isMerge: boolean
```

###### Property notDelayedResults

valid iff not isMerge and txid was unknown to storage and non-delayed broadcast was not success

```ts
notDelayedResults?: ReviewActionResult[]
```
See also: [ReviewActionResult](./client.md#interface-reviewactionresult)

###### Property satoshis

net change in change balance for user due to this internalization

```ts
satoshis: number
```

###### Property sendWithResults

valid iff not isMerge and txid was unknown to storage and non-delayed broadcast was not success

```ts
sendWithResults?: SendWithResult[]
```

###### Property txid

txid of transaction being internalized

```ts
txid: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StoragePrepareNoSendExpiryResult

```ts
export interface StoragePrepareNoSendExpiryResult {
    funding: StorageCreateActionResult;
    anchorSatoshis: number;
    anchorVout: number;
    reclaimFee: number;
    reclaimSatoshis: number;
}
```

See also: [StorageCreateActionResult](./client.md#interface-storagecreateactionresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageProcessActionArgs

```ts
export interface StorageProcessActionArgs {
    isNewTx: boolean;
    isSendWith: boolean;
    isNoSend: boolean;
    isDelayed: boolean;
    reference?: string;
    txid?: string;
    rawTx?: number[] | Uint8Array;
    sendWith: string[];
    logger?: WalletLoggerInterface;
}
```

See also: [logger](./client.md#variable-logger)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageProcessActionResults

```ts
export interface StorageProcessActionResults {
    sendWithResults?: SendWithResult[];
    notDelayedResults?: ReviewActionResult[];
    log?: string;
}
```

See also: [ReviewActionResult](./client.md#interface-reviewactionresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageProvenOrReq

```ts
export interface StorageProvenOrReq {
    proven?: TableProvenTx;
    req?: TableProvenTxReq;
    isNew?: boolean;
}
```

See also: [TableProvenTx](./storage.md#interface-tableproventx), [TableProvenTxReq](./storage.md#interface-tableproventxreq)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageProviderOptions

```ts
export interface StorageProviderOptions extends StorageReaderWriterOptions {
    chain: Chain;
    feeModel: StorageFeeModel;
    commissionSatoshis: number;
    commissionPubKeyHex?: PubKeyHex;
    scriptVerifier?: SpendVerifierInterface;
    actionBatchMaxReservedOutputs?: number;
    managedChangePolicy?: ManagedChangePolicyOptions;
}
```

See also: [Chain](./client.md#type-chain), [ManagedChangePolicyOptions](./storage.md#type-managedchangepolicyoptions), [StorageFeeModel](./client.md#interface-storagefeemodel), [StorageReaderWriterOptions](./storage.md#interface-storagereaderwriteroptions)

###### Property actionBatchMaxReservedOutputs

Maximum persisted outputs one action-batch workspace may reserve.
Defaults to 256; -1 disables this cumulative provider limit.

```ts
actionBatchMaxReservedOutputs?: number
```

###### Property commissionPubKeyHex

If commissionSatoshis is greater than zero, must be a valid public key hex string.
The actual locking script for each commission will use a public key derived
from this key by information stored in the commissions table.

```ts
commissionPubKeyHex?: PubKeyHex
```

###### Property commissionSatoshis

Transactions created by this Storage can charge a fee per transaction.
A value of zero disables commission fees.

```ts
commissionSatoshis: number
```

###### Property managedChangePolicy

Optional wallet-managed liquidity tuning. Values are soft shaping and
comparison budgets; none can prevent an otherwise fundable action. Each
limit accepts -1 for an explicit operator-selected unlimited mode.

```ts
managedChangePolicy?: ManagedChangePolicyOptions
```
See also: [ManagedChangePolicyOptions](./storage.md#type-managedchangepolicyoptions)

###### Property scriptVerifier

Optional verifier for server-side action-batch script checks. This Wallet
Toolbox extension leaves the BRC-100 wallet interface unchanged.

```ts
scriptVerifier?: SpendVerifierInterface
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageReaderOptions

```ts
export interface StorageReaderOptions {
    chain: sdk.Chain;
    telemetry?: TelemetryConfig;
}
```

See also: [Chain](./client.md#type-chain)

###### Property telemetry

Optional provider-neutral storage and database tracing.

```ts
telemetry?: TelemetryConfig
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageReaderWriterOptions

```ts
export interface StorageReaderWriterOptions extends StorageReaderOptions {
}
```

See also: [StorageReaderOptions](./storage.md#interface-storagereaderoptions)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: StorageSyncReaderOptions

```ts
export interface StorageSyncReaderOptions {
    chain: Chain;
}
```

See also: [Chain](./client.md#type-chain)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: SyncCheckpoint

Compact writer progress; omits the durable ID mapping from this response.

```ts
export interface SyncCheckpoint {
    syncStateId: number;
    since?: Date;
    offsets: Array<{
        name: string;
        offset: number;
    }>;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: SyncChunk

Result received from remote `WalletStorage` in response to a `RequestSyncChunkArgs` request.

Each property is undefined if there was no attempt to update it. Typically this is caused by size and count limits on this result.

If all properties are empty arrays the sync process has received all available new and updated items.

```ts
export interface SyncChunk {
    fromStorageIdentityKey: string;
    toStorageIdentityKey: string;
    userIdentityKey: string;
    totals?: SyncChunkTotals;
    user?: TableUser;
    provenTxs?: TableProvenTx[];
    provenTxReqs?: TableProvenTxReq[];
    outputBaskets?: TableOutputBasket[];
    txLabels?: TableTxLabel[];
    outputTags?: TableOutputTag[];
    transactions?: TableTransaction[];
    txLabelMaps?: TableTxLabelMap[];
    commissions?: TableCommission[];
    outputs?: TableOutput[];
    outputTagMaps?: TableOutputTagMap[];
    certificates?: TableCertificate[];
    certificateFields?: TableCertificateField[];
}
```

See also: [SyncChunkTotals](./client.md#interface-syncchunktotals), [TableCertificate](./storage.md#interface-tablecertificate), [TableCertificateField](./storage.md#interface-tablecertificatefield), [TableCommission](./storage.md#interface-tablecommission), [TableOutput](./storage.md#interface-tableoutput), [TableOutputBasket](./storage.md#interface-tableoutputbasket), [TableOutputTag](./storage.md#interface-tableoutputtag), [TableOutputTagMap](./storage.md#interface-tableoutputtagmap), [TableProvenTx](./storage.md#interface-tableproventx), [TableProvenTxReq](./storage.md#interface-tableproventxreq), [TableTransaction](./storage.md#interface-tabletransaction), [TableTxLabel](./storage.md#interface-tabletxlabel), [TableTxLabelMap](./storage.md#interface-tabletxlabelmap), [TableUser](./storage.md#interface-tableuser)

###### Property totals

Optional progress totals requested with `includeTotals`.

```ts
totals?: SyncChunkTotals
```
See also: [SyncChunkTotals](./client.md#interface-syncchunktotals)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: SyncChunkTotals

```ts
export interface SyncChunkTotals {
    totalRecords: number;
    records: {
        provenTxs: number;
        outputBaskets: number;
        outputTags: number;
        txLabels: number;
        transactions: number;
        outputs: number;
        txLabelMaps: number;
        outputTagMaps: number;
        certificates: number;
        certificateFields: number;
        commissions: number;
        provenTxReqs: number;
    };
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: SyncError

```ts
export interface SyncError {
    code: string;
    description: string;
    stack?: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: SyncMap

```ts
export interface SyncMap {
    provenTx: EntitySyncMap;
    outputBasket: EntitySyncMap;
    transaction: EntitySyncMap;
    provenTxReq: EntitySyncMap;
    txLabel: EntitySyncMap;
    txLabelMap: EntitySyncMap;
    output: EntitySyncMap;
    outputTag: EntitySyncMap;
    outputTagMap: EntitySyncMap;
    certificate: EntitySyncMap;
    certificateField: EntitySyncMap;
    commission: EntitySyncMap;
}
```

See also: [EntitySyncMap](./storage.md#interface-entitysyncmap)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: SyncProofValidationStorage

```ts
export interface SyncProofValidationStorage {
    getServices: () => WalletServices;
}
```

See also: [WalletServices](./client.md#interface-walletservices)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableActionBatch

```ts
export interface TableActionBatch extends EntityTimeStamp {
    actionBatchId: number;
    userId: number;
    batchId: string;
    status: ActionBatchStatus;
    expiresAt: Date;
    hardExpiresAt: Date;
    manifestDigest?: string;
    manifest?: string;
    uploadDigests?: string;
    result?: string;
}
```

See also: [ActionBatchStatus](./storage.md#type-actionbatchstatus), [EntityTimeStamp](./client.md#interface-entitytimestamp)

###### Property manifest

JSON-encoded format-2 manifest retained between prepare and commit.

```ts
manifest?: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableActionBatchBlob

```ts
export interface TableActionBatchBlob extends EntityTimeStamp {
    actionBatchBlobId: number;
    actionBatchId: number;
    digest: string;
    bytes: number[] | Uint8Array;
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableActionBatchOutput

```ts
export interface TableActionBatchOutput extends EntityTimeStamp {
    actionBatchId: number;
    outputId: number;
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableCertificate

```ts
export interface TableCertificate extends sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    certificateId: number;
    userId: number;
    type: Base64String;
    serialNumber: Base64String;
    certifier: PubKeyHex;
    subject: PubKeyHex;
    verifier?: PubKeyHex;
    revocationOutpoint: OutpointString;
    signature: HexString;
    isDeleted: boolean;
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableCertificateField

```ts
export interface TableCertificateField extends sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    userId: number;
    certificateId: number;
    fieldName: string;
    fieldValue: string;
    masterKey: Base64String;
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableCertificateX

```ts
export interface TableCertificateX extends TableCertificate {
    fields?: TableCertificateField[];
}
```

See also: [TableCertificate](./storage.md#interface-tablecertificate), [TableCertificateField](./storage.md#interface-tablecertificatefield)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableCommission

```ts
export interface TableCommission extends sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    commissionId: number;
    userId: number;
    transactionId: number;
    satoshis: number;
    keyOffset: string;
    isRedeemed: boolean;
    lockingScript: number[];
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableMonitorEvent

```ts
export interface TableMonitorEvent extends sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    id: number;
    event: string;
    details?: string;
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableOutput

```ts
export interface TableOutput extends sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    outputId: number;
    userId: number;
    transactionId: number;
    basketId?: number;
    spendable: boolean;
    change: boolean;
    outputDescription: DescriptionString5to50Bytes;
    vout: number;
    satoshis: number;
    providedBy: sdk.StorageProvidedBy;
    purpose: string;
    type: string;
    txid?: string;
    senderIdentityKey?: PubKeyHex;
    derivationPrefix?: Base64String;
    derivationSuffix?: Base64String;
    customInstructions?: string;
    spentBy?: number;
    sequenceNumber?: number;
    spendingDescription?: string;
    scriptLength?: number;
    scriptOffset?: number;
    lockingScript?: number[];
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp), [StorageProvidedBy](./client.md#type-storageprovidedby)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableOutputBasket

```ts
export interface TableOutputBasket extends sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    basketId: number;
    userId: number;
    name: string;
    numberOfDesiredUTXOs: number;
    minimumDesiredUTXOValue: number;
    isDeleted: boolean;
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableOutputTag

```ts
export interface TableOutputTag extends sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    outputTagId: number;
    userId: number;
    tag: string;
    isDeleted: boolean;
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableOutputTagMap

```ts
export interface TableOutputTagMap extends sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    outputTagId: number;
    outputId: number;
    isDeleted: boolean;
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableOutputX

```ts
export interface TableOutputX extends TableOutput {
    basket?: TableOutputBasket;
    tags?: TableOutputTag[];
}
```

See also: [TableOutput](./storage.md#interface-tableoutput), [TableOutputBasket](./storage.md#interface-tableoutputbasket), [TableOutputTag](./storage.md#interface-tableoutputtag)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TablePreparedBeef

Rebuildable, user-scoped proof material prepared for a future spend.

This table is deliberately excluded from wallet synchronization. The
authoritative transaction, proof, and output rows can always rebuild it.

```ts
export interface TablePreparedBeef extends sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    preparedBeefId: number;
    userId: number;
    rootTxid: string;
    beef: number[];
    checksum: string;
    formatVersion: number;
    state: PreparedBeefState;
    txCount: number;
    bumpCount: number;
    byteLength: number;
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp), [PreparedBeefState](./storage.md#type-preparedbeefstate)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableProvenTx

```ts
export interface TableProvenTx extends sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    provenTxId: number;
    txid: string;
    height: number;
    index: number;
    merklePath: number[];
    rawTx: number[];
    blockHash: string;
    merkleRoot: string;
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp), [blockHash](./services.md#function-blockhash)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableProvenTxReq

```ts
export interface TableProvenTxReq extends TableProvenTxReqDynamics {
    created_at: Date;
    updated_at: Date;
    provenTxReqId: number;
    provenTxId?: number;
    status: sdk.ProvenTxReqStatus;
    attempts: number;
    notified: boolean;
    txid: string;
    batch?: string;
    history: string;
    notify: string;
    rawTx: number[];
    inputBEEF?: number[];
    wasBroadcast?: boolean;
    rebroadcastAttempts?: number;
}
```

See also: [ProvenTxReqStatus](./client.md#type-proventxreqstatus), [TableProvenTxReqDynamics](./storage.md#interface-tableproventxreqdynamics)

###### Property attempts

Count of how many times a service has been asked about this txid

```ts
attempts: number
```

###### Property batch

If valid, a unique string identifying a batch of transactions to be sent together for processing.

```ts
batch?: string
```

###### Property history

JSON string of processing history.
Parses to `ProvenTxReqHistoryApi`.

```ts
history: string
```

###### Property notified

Set to true when a terminal status has been set and notification has occurred.

```ts
notified: boolean
```

###### Property notify

JSON string of data to drive notifications when this request completes.
Parses to `ProvenTxReqNotifyApi`.

```ts
notify: string
```

###### Property rebroadcastAttempts

Count of how many times this req has been reset to 'unsent' for rebroadcast
after proof check timeout. Used by the circuit-breaker (maxRebroadcastAttempts).
Defaults to 0 (added by migration 2026-04-30-001).

```ts
rebroadcastAttempts?: number
```

###### Property wasBroadcast

Set to true the first time this req transitions to 'unmined' or 'callback' status,
indicating the transaction was successfully broadcast to the network.
Used to distinguish rebroadcast candidates from transactions that were never sent.
Defaults to false (added by migration 2026-04-30-001).

```ts
wasBroadcast?: boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableProvenTxReqDynamics

Table properties that may change after initial record insertion.

```ts
export interface TableProvenTxReqDynamics extends sdk.EntityTimeStamp {
    updated_at: Date;
    provenTxId?: number;
    status: sdk.ProvenTxReqStatus;
    attempts: number;
    notified: boolean;
    batch?: string;
    history: string;
    notify: string;
    wasBroadcast?: boolean;
    rebroadcastAttempts?: number;
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp), [ProvenTxReqStatus](./client.md#type-proventxreqstatus)

###### Property attempts

Count of how many times a service has been asked about this txid

```ts
attempts: number
```

###### Property batch

If valid, a unique string identifying a batch of transactions to be sent together for processing.

```ts
batch?: string
```

###### Property history

JSON string of processing history.
Parses to `ProvenTxReqHistoryApi`.

```ts
history: string
```

###### Property notified

Set to true when a terminal status has been set and notification has occurred.

```ts
notified: boolean
```

###### Property notify

JSON string of data to drive notifications when this request completes.
Parses to `ProvenTxReqNotifyApi`.

```ts
notify: string
```

###### Property rebroadcastAttempts

Count of rebroadcast cycles for this req. Used by the circuit-breaker.
Defaults to 0 (added by migration 2026-04-30-001).

```ts
rebroadcastAttempts?: number
```

###### Property wasBroadcast

Set to true the first time this req transitions to 'unmined' or 'callback' status.
Defaults to false (added by migration 2026-04-30-001).

```ts
wasBroadcast?: boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableSettings

```ts
export interface TableSettings extends sdk.StorageIdentity, sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    storageIdentityKey: string;
    storageName: string;
    chain: sdk.Chain;
    dbtype: "SQLite" | "MySQL" | "IndexedDB";
    maxOutputScript: number;
}
```

See also: [Chain](./client.md#type-chain), [EntityTimeStamp](./client.md#interface-entitytimestamp), [StorageIdentity](./client.md#interface-storageidentity)

###### Property storageIdentityKey

The identity key (public key) assigned to this storage

```ts
storageIdentityKey: string
```

###### Property storageName

The human readable name assigned to this storage.

```ts
storageName: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableSyncState

```ts
export interface TableSyncState extends sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    syncStateId: number;
    userId: number;
    storageIdentityKey: string;
    storageName: string;
    status: sdk.SyncStatus;
    init: boolean;
    refNum: string;
    syncMap: string;
    when?: Date;
    satoshis?: number;
    errorLocal?: string;
    errorOther?: string;
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp), [SyncStatus](./client.md#type-syncstatus)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableTransaction

```ts
export interface TableTransaction extends sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    transactionId: number;
    userId: number;
    provenTxId?: number;
    status: sdk.TransactionStatus;
    reference: Base64String;
    isOutgoing: boolean;
    satoshis: number;
    description: string;
    version?: number;
    lockTime?: number;
    txid?: string;
    inputBEEF?: number[];
    rawTx?: number[];
    noSendExpiryMode?: Brc177NoSendExpiryMode;
    noSendExpiryValue?: number;
    noSendExpiryDeadline?: number;
    noSendExpiryState?: Brc177NoSendExpiryState;
    noSendExpiryAnchorTxid?: string;
    noSendExpiryAnchorVout?: number;
    noSendExpiryReleasedAt?: number;
    noSendExpiryObservedAt?: number;
    noSendExpiryReclaimTxid?: string;
    noSendExpiryReclaimRawTx?: number[];
    noSendExpiryReclaimDerivationPrefix?: string;
    noSendExpiryReclaimDerivationSuffix?: string;
    noSendExpiryReclaimSatoshis?: number;
}
```

See also: [Brc177NoSendExpiryMode](./client.md#type-brc177nosendexpirymode), [Brc177NoSendExpiryState](./client.md#type-brc177nosendexpirystate), [EntityTimeStamp](./client.md#interface-entitytimestamp), [TransactionStatus](./client.md#type-transactionstatus)

###### Property isOutgoing

true if transaction originated in this wallet, change returns to it.
false for a transaction created externally and handed in to this wallet.

```ts
isOutgoing: boolean
```

###### Property lockTime

Optional. Default is zero.
When the transaction can be processed into a block:
>= 500,000,000 values are interpreted as minimum required unix time stamps in seconds
< 500,000,000 values are interpreted as minimum required block height

```ts
lockTime?: number
```

###### Property noSendExpiryDeadline

Resolved Unix seconds for time modes, or the absolute height for blockheight.

```ts
noSendExpiryDeadline?: number
```

###### Property noSendExpiryMode

Internal BRC-177 lifecycle metadata. These fields are synchronized with the action.

```ts
noSendExpiryMode?: Brc177NoSendExpiryMode
```
See also: [Brc177NoSendExpiryMode](./client.md#type-brc177nosendexpirymode)

###### Property reference

max length of 64, hex encoded

```ts
reference: Base64String
```

###### Property version

If not undefined, must match value in associated rawTransaction.

```ts
version?: number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableTxLabel

```ts
export interface TableTxLabel extends sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    txLabelId: number;
    userId: number;
    label: string;
    isDeleted: boolean;
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableTxLabelMap

```ts
export interface TableTxLabelMap extends sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    txLabelId: number;
    transactionId: number;
    isDeleted: boolean;
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TableUser

```ts
export interface TableUser extends sdk.EntityTimeStamp {
    created_at: Date;
    updated_at: Date;
    userId: number;
    identityKey: string;
    activeStorage: string;
}
```

See also: [EntityTimeStamp](./client.md#interface-entitytimestamp)

###### Property activeStorage

The storageIdentityKey value of the active wallet storage.

```ts
activeStorage: string
```

###### Property identityKey

PubKeyHex uniquely identifying user.
Typically 66 hex digits.

```ts
identityKey: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TaskPurgeParams

The database stores a variety of data that may be considered transient.

At one extreme, the data that must be preserved:
  - unspent outputs (UTXOs)
  - in-use metadata (labels, baskets, tags...)

At the other extreme, everything can be preserved to fully log all transaction creation and processing actions.

The following purge actions are available to support sustained operation:
  - Failed transactions, delete all associated data including:
      + Delete tag and label mapping records
      + Delete output records
      + Delete transaction records
      + Delete mapi_responses records
      + Delete proven_tx_reqs records
      + Delete commissions records
      + Update output records marked spentBy failed transactions
  - Completed transactions, delete transient data including:
      + transactions table set truncatedExternalInputs = null
      + transactions table set beef = null
      + transactions table set rawTx = null
      + Delete mapi_responses records
      + proven_tx_reqs table delete records

```ts
export interface TaskPurgeParams extends PurgeParams {
}
```

See also: [PurgeParams](./client.md#interface-purgeparams)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TaskReviewUtxosPageResult

```ts
export interface TaskReviewUtxosPageResult extends UtxoReviewDiagnostics {
    found: boolean;
    userId?: number;
    identityKey: string;
    mode: "all" | "change";
    release: boolean;
    offset: number;
    pageLimit: number;
    sourceScanned: number;
    complete: boolean;
    nextOffset?: number;
    log: string;
}
```

See also: [UtxoReviewDiagnostics](./storage.md#interface-utxoreviewdiagnostics)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TrustSettings

```ts
export interface TrustSettings {
    trustLevel: number;
    trustedCertifiers: Certifier[];
}
```

See also: [Certifier](./client.md#interface-certifier)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TrxToken

Place holder for the transaction control object used by actual storage provider implementation.

```ts
export interface TrxToken {
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TscMerkleProofApi

```ts
export interface TscMerkleProofApi {
    height: number;
    index: number;
    nodes: string[];
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: TxScriptOffsets

```ts
export interface TxScriptOffsets {
    inputs: Array<{
        vin: number;
        offset: number;
        length: number;
    }>;
    outputs: Array<{
        vout: number;
        offset: number;
        length: number;
    }>;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: UnlockScriptVerificationResult

```ts
export interface UnlockScriptVerificationResult {
    verifiedInputs: number;
    skippedInputs: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: UpdateProvenTxReqWithNewProvenTxArgs

```ts
export interface UpdateProvenTxReqWithNewProvenTxArgs {
    provenTxReqId: number;
    txid: string;
    attempts: number;
    status: ProvenTxReqStatus;
    history: string;
    height: number;
    index: number;
    blockHash: string;
    merkleRoot: string;
    merklePath: number[];
}
```

See also: [ProvenTxReqStatus](./client.md#type-proventxreqstatus), [blockHash](./services.md#function-blockhash)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: UpdateProvenTxReqWithNewProvenTxResult

```ts
export interface UpdateProvenTxReqWithNewProvenTxResult {
    status: ProvenTxReqStatus;
    history: string;
    provenTxId: number;
    notified?: boolean;
    notify?: string;
    log?: string;
}
```

See also: [ProvenTxReqStatus](./client.md#type-proventxreqstatus)

###### Property notified

Final durable notification state, when supplied by the storage implementation.

```ts
notified?: boolean
```

###### Property notify

Final durable notification payload, when supplied by the storage implementation.

```ts
notify?: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: UtxoReviewClassification

```ts
export interface UtxoReviewClassification {
    output: TableOutput;
    status: OutputUtxoClassification;
}
```

See also: [OutputUtxoClassification](./services.md#interface-outpututxoclassification), [TableOutput](./storage.md#interface-tableoutput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: UtxoReviewDiagnostics

```ts
export interface UtxoReviewDiagnostics {
    checked: number;
    confirmedUnspent: number;
    confirmedSpent: number;
    unknown: number;
    confirmedSpentSatoshis: number;
    released: number;
    releasedSatoshis: number;
    providers: string[];
    providerCount: number;
    providersTruncated: boolean;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ValidateGenerateChangeSdkParamsResult

```ts
export interface ValidateGenerateChangeSdkParamsResult {
    hasMaxPossibleOutput?: number;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ValidatedBatchAction

```ts
export interface ValidatedBatchAction {
    action: ActionBatchCommitAction;
    tx: Transaction;
    rawTx: Uint8Array;
    externalInputBeef: Uint8Array;
}
```

See also: [ActionBatchCommitAction](./client.md#interface-actionbatchcommitaction)

###### Property externalInputBeef

Proof frontier for inputs outside this atomic batch.

```ts
externalInputBeef: Uint8Array
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ValidatedMerklePathResult

```ts
export interface ValidatedMerklePathResult {
    merklePath: MerklePath;
    header: BlockHeader;
    root: string;
    index: number;
}
```

See also: [BlockHeader](./client.md#interface-blockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: ValidatedPostBeefRequest

```ts
export interface ValidatedPostBeefRequest {
    beefBytes: number[];
    txids: string[];
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: VerifyAndRepairBeefResult

```ts
export interface VerifyAndRepairBeefResult {
    isStructurallyValid: boolean;
    originalRoots: Record<number, string>;
    invalidRoots: Record<number, {
        root: string;
        reproveResults: sdk.ReproveHeaderResult;
    }>;
    verifiedBeef?: Beef;
}
```

See also: [ReproveHeaderResult](./client.md#interface-reproveheaderresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletArgs

```ts
export interface WalletArgs {
    chain: Chain;
    keyDeriver: KeyDeriverApi;
    storage: WalletStorageManager;
    services?: WalletServices;
    monitor?: Monitor;
    privilegedKeyManager?: PrivilegedKeyManager;
    settingsManager?: WalletSettingsManager;
    lookupResolver?: LookupResolver;
    contactSource?: ContactSource;
    makeLogger?: MakeWalletLogger;
    actionBatchMode?: ActionBatchMode;
    scriptVerifier?: SpendVerifierInterface;
    telemetry?: TelemetryConfig;
}
```

See also: [ActionBatchMode](./client.md#type-actionbatchmode), [Chain](./client.md#type-chain), [ContactSource](./client.md#interface-contactsource), [Monitor](./monitor.md#class-monitor), [PrivilegedKeyManager](./client.md#class-privilegedkeymanager), [WalletServices](./client.md#interface-walletservices), [WalletSettingsManager](./client.md#class-walletsettingsmanager), [WalletStorageManager](./storage.md#class-walletstoragemanager)

###### Property actionBatchMode

Internal Wallet Toolbox optimization policy. `auto` (the default)
negotiates the optional action-batch storage capability; `legacy` always
uses per-action storage. This does not change the BRC-100 wallet interface.

```ts
actionBatchMode?: ActionBatchMode
```
See also: [ActionBatchMode](./client.md#type-actionbatchmode)

###### Property contactSource

Optional caller-installed, local contact source consulted before the overlay in
`discoverByIdentityKey` / `discoverByAttributes`. A match is a user-authoritative personal
assertion, not an external certifier attestation, and skips the overlay entirely. Only connect
a locally authenticated/contact-management source whose records the user has independently
chosen to trust. A contact-store signature or encryption authenticates local persistence; it
does not replace that independent validation step.
Pass `forceRefresh: true` on the discover args to bypass both contacts and the overlay
cache.

```ts
contactSource?: ContactSource
```
See also: [ContactSource](./client.md#interface-contactsource)

###### Property makeLogger

Optional. Provide a function conforming to the `MakeWalletLogger` type to enable wallet request logging.

For simple requests using `Console` may be adequate, initialize with
`() => Console`

Aggregate tracing and control over capturing all logged output in one place:
`(log?: string | WalletLoggerInterface) => new WalletLogger(log)`

```ts
makeLogger?: MakeWalletLogger
```

###### Property scriptVerifier

Optional high-performance script verifier used by Wallet Toolbox's
internal transaction checks. This is an implementation extension and does
not change the BRC-100 wallet interface.

```ts
scriptVerifier?: SpendVerifierInterface
```

###### Property telemetry

Optional provider-neutral tracing shared by wallet, lookup, storage, and
permission layers. Disabled unless an enabled sink is supplied.

```ts
telemetry?: TelemetryConfig
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletBalance

```ts
export interface WalletBalance {
    total: number;
    utxos: Array<{
        satoshis: number;
        outpoint: string;
    }>;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletServices

Defines standard interfaces to access functionality implemented by external transaction processing services.

```ts
export interface WalletServices {
    chain: Chain;
    getChainTracker: () => Promise<ChainTracker>;
    getHeaderForHeight: (height: number) => Promise<number[]>;
    getHeight: () => Promise<number>;
    getBsvExchangeRate: () => Promise<number>;
    getFiatExchangeRate: (currency: FiatCurrencyCode, base?: FiatCurrencyCode) => Promise<number>;
    getRawTx: (txid: string, useNext?: boolean) => Promise<GetRawTxResult>;
    getMerklePath: (txid: string, useNext?: boolean) => Promise<GetMerklePathResult>;
    getValidatedMerklePath?: (txid: string, validate: (result: GetMerklePathResult) => Promise<void>) => Promise<GetMerklePathResult>;
    postBeef: (beef: Beef, txids: string[], logger?: WalletLoggerInterface) => Promise<PostBeefResult[]>;
    hashOutputScript: (script: string) => string;
    getStatusForTxids: (txids: string[], useNext?: boolean) => Promise<GetStatusForTxidsResult>;
    isUtxo: (output: TableOutput) => Promise<boolean>;
    getUtxoStatus: (output: string, outputFormat?: GetUtxoStatusOutputFormat, outpoint?: string, useNext?: boolean) => Promise<GetUtxoStatusResult>;
    getScriptHashHistory: (hash: string, useNext?: boolean, logger?: WalletLoggerInterface) => Promise<GetScriptHashHistoryResult>;
    hashToHeader: (hash: string) => Promise<BlockHeader>;
    nLockTimeIsFinal: (txOrLockTime: string | number[] | BsvTransaction | number) => Promise<boolean>;
    getBeefForTxid: (txid: string) => Promise<Beef>;
    getServicesCallHistory: (reset?: boolean) => ServicesCallHistory;
}
```

See also: [BlockHeader](./client.md#interface-blockheader), [Chain](./client.md#type-chain), [FiatCurrencyCode](./client.md#type-fiatcurrencycode), [GetMerklePathResult](./client.md#interface-getmerklepathresult), [GetRawTxResult](./client.md#interface-getrawtxresult), [GetScriptHashHistoryResult](./client.md#interface-getscripthashhistoryresult), [GetStatusForTxidsResult](./client.md#interface-getstatusfortxidsresult), [GetUtxoStatusOutputFormat](./client.md#type-getutxostatusoutputformat), [GetUtxoStatusResult](./client.md#interface-getutxostatusresult), [PostBeefResult](./client.md#interface-postbeefresult), [ServicesCallHistory](./client.md#interface-servicescallhistory), [TableOutput](./storage.md#interface-tableoutput), [getBeefForTxid](./services.md#function-getbeeffortxid), [logger](./client.md#variable-logger)

###### Property chain

The chain being serviced.

```ts
chain: Chain
```
See also: [Chain](./client.md#type-chain)

###### Property getBeefForTxid

Constructs a `Beef` for the given `txid` using only external data retrieval services.

In most cases, the `getBeefForTransaction` method of the `StorageProvider` class should be
used instead to avoid redundantly retrieving data.

```ts
getBeefForTxid: (txid: string) => Promise<Beef>
```

###### Property getBsvExchangeRate

Approximate exchange rate US Dollar / BSV, USD / BSV

This is the US Dollar price of one BSV

```ts
getBsvExchangeRate: () => Promise<number>
```

###### Property getFiatExchangeRate

Approximate exchange rate currency per base.

```ts
getFiatExchangeRate: (currency: FiatCurrencyCode, base?: FiatCurrencyCode) => Promise<number>
```
See also: [FiatCurrencyCode](./client.md#type-fiatcurrencycode)

###### Property getMerklePath

Attempts to obtain the merkle proof associated with a 32 byte transaction hash (txid).

Cycles through configured transaction processing services attempting to get a valid response.

On success:
Result txid is the requested transaction hash
Result proof will be the merkle proof.
Result name will be the responding service's identifying name.
Returns result without incrementing active service.

On failure:
Result txid is the requested transaction hash
Result mapi will be the first mapi response obtained (service name and response), or null
Result error will be the first error thrown (service name and CwiError), or null
Increments to next configured service and tries again until all services have been tried.

```ts
getMerklePath: (txid: string, useNext?: boolean) => Promise<GetMerklePathResult>
```
See also: [GetMerklePathResult](./client.md#interface-getmerklepathresult)

###### Property getRawTx

Attempts to obtain the raw transaction bytes associated with a 32 byte transaction hash (txid).

Cycles through configured transaction processing services attempting to get a valid response.

On success:
Result txid is the requested transaction hash
Result rawTx will be an array containing raw transaction bytes.
Result name will be the responding service's identifying name.
Returns result without incrementing active service.

On failure:
Result txid is the requested transaction hash
Result mapi will be the first mapi response obtained (service name and response), or null
Result error will be the first error thrown (service name and CwiError), or null
Increments to next configured service and tries again until all services have been tried.

```ts
getRawTx: (txid: string, useNext?: boolean) => Promise<GetRawTxResult>
```
See also: [GetRawTxResult](./client.md#interface-getrawtxresult)

###### Property getStatusForTxids

For an array of one or more txids, returns for each wether it is a 'known', 'mined', or 'unknown' transaction.

Primarily useful for determining if a recently broadcast transaction is known to the processing network.

Also returns the current depth from chain tip if 'mined'.

```ts
getStatusForTxids: (txids: string[], useNext?: boolean) => Promise<GetStatusForTxidsResult>
```
See also: [GetStatusForTxidsResult](./client.md#interface-getstatusfortxidsresult)

###### Property getUtxoStatus

Attempts to determine the UTXO status of a transaction output.

Cycles through configured transaction processing services attempting to get a valid response.

```ts
getUtxoStatus: (output: string, outputFormat?: GetUtxoStatusOutputFormat, outpoint?: string, useNext?: boolean) => Promise<GetUtxoStatusResult>
```
See also: [GetUtxoStatusOutputFormat](./client.md#type-getutxostatusoutputformat), [GetUtxoStatusResult](./client.md#interface-getutxostatusresult)

###### Property getValidatedMerklePath

Try each configured proof provider once, accepting a result only after the
caller's validator succeeds. Each call uses its own provider order so
concurrent lookups cannot skip providers. Optional for custom services.

```ts
getValidatedMerklePath?: (txid: string, validate: (result: GetMerklePathResult) => Promise<void>) => Promise<GetMerklePathResult>
```
See also: [GetMerklePathResult](./client.md#interface-getmerklepathresult)

###### Property isUtxo

Calls getUtxoStatus with the hash of the output's lockingScript,
and ensures that the output's outpoint matches an unspent use of that script.

```ts
isUtxo: (output: TableOutput) => Promise<boolean>
```
See also: [TableOutput](./storage.md#interface-tableoutput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletServicesOptions

```ts
export interface WalletServicesOptions {
    chain: Chain;
    telemetry?: TelemetryConfig;
    chainTracker?: ChainTracker;
    taalApiKey?: string;
    bitailsApiKey?: string;
    whatsOnChainApiKey?: string;
    bsvExchangeRate: BsvExchangeRate;
    bsvUpdateMsecs: number;
    fiatExchangeRates: FiatExchangeRates;
    fiatUpdateMsecs: number;
    disableMapiCallback?: boolean;
    exchangeratesapiKey?: string;
    chaintracksFiatExchangeRatesUrl?: string;
    fiatExchangeRatesFetch?: typeof fetch;
    chaintracks?: ChaintracksClientApi;
    arcUrl: string;
    arcConfig: ArcConfig;
    arcGorillaPoolUrl?: string;
    arcGorillaPoolConfig?: ArcConfig;
    arcadeUrl?: string;
    arcadeConfig?: ArcConfig;
}
```

See also: [ArcConfig](./services.md#interface-arcconfig), [BsvExchangeRate](./client.md#interface-bsvexchangerate), [Chain](./client.md#type-chain), [ChaintracksClientApi](./services.md#interface-chaintracksclientapi), [FiatExchangeRates](./client.md#interface-fiatexchangerates), [arcGorillaPoolUrl](./services.md#function-arcgorillapoolurl)

###### Property arcConfig

TAAL ARC service configuration options.

apiKey Default value is undefined.

deploymentId Default value: `wallet-toolbox-${randomBytesHex(16)}`.

callbackUrl Default is undefined.
callbackToken Default is undefined.

```ts
arcConfig: ArcConfig
```
See also: [ArcConfig](./services.md#interface-arcconfig)

###### Property arcGorillaPoolConfig

GorillaPool ARC service configuration options.

apiKey Default is undefined.

deploymentId Default value: `wallet-toolbox-${randomBytesHex(16)}`.

callbackUrl Default is undefined.
callbackToken Default is undefined.

```ts
arcGorillaPoolConfig?: ArcConfig
```
See also: [ArcConfig](./services.md#interface-arcconfig)

###### Property arcGorillaPoolUrl

GorillaPool ARC service provider endpoit to use
Default is:
mainnet: `https://arc.gorillapool.io`
testnet: undefined

```ts
arcGorillaPoolUrl?: string
```

###### Property arcUrl

TAAL ARC service provider endpoit to use
Default is:
mainnet: `https://arc.taal.com`
testnet: `https://arc-test.taal.com`

```ts
arcUrl: string
```

###### Property arcadeConfig

Arcade service configuration options (used to construct the `Arcade` broadcaster).

`callbackToken` must equal the Monitor's `callbackToken` so Arcade routes each
submitted transaction's status events to this wallet's SSE subscription.

`callbackUrl` should be left undefined for the SSE (pull) flow — Arcade rejects
private/loopback webhook URLs.

```ts
arcadeConfig?: ArcConfig
```
See also: [ArcConfig](./services.md#interface-arcconfig)

###### Property arcadeUrl

Optional bsv-blockchain/arcade endpoint to use as the primary transaction broadcaster.

When set, an Arcade broadcaster is registered ahead of the ARC providers (Arcade-first,
ARC fallback) and the Monitor's SSE/proof task (`TaskArcadeSSE`) targets this URL.

Default is undefined (Arcade disabled; ARC providers used as before).
mainnet:   `https://arcade-v2-us-1.bsvblockchain.tech`
teratest:  `https://arcade-v2-ttn-us-1.bsvblockchain.tech`
tstn:      supplied at runtime via the `TSTN_ARCADE_URL` environment variable (not public)

```ts
arcadeUrl?: string
```

###### Property bitailsApiKey

Api key for use accessing Bitails API at
mainnet: `https://api.bitails.io/`
testnet: `https://test-api.bitails.io/`

```ts
bitailsApiKey?: string
```

###### Property bsvExchangeRate

The initial approximate BSV/USD exchange rate.

```ts
bsvExchangeRate: BsvExchangeRate
```
See also: [BsvExchangeRate](./client.md#interface-bsvexchangerate)

###### Property bsvUpdateMsecs

Update interval for BSV/USD exchange rate.
Default is 15 minutes.

```ts
bsvUpdateMsecs: number
```

###### Property chain

'main' or 'test': which BSV chain to use

```ts
chain: Chain
```
See also: [Chain](./client.md#type-chain)

###### Property chainTracker

Optional SDK verifier returned directly by `getChainTracker`.

Use this for a local-primary or otherwise composed verifier. When omitted,
Services preserves the existing behavior of wrapping `chaintracks` in a
`ChaintracksChainTracker`.

```ts
chainTracker?: ChainTracker
```

###### Property chaintracks

Optional Chaintracks client API instance.
Default is a new instance of ChaintracksServiceClient configured to use:
mainnet: `https://mainnet-chaintracks.babbage.systems`
testnet: `https://testnet-chaintracks.babbage.systems`

```ts
chaintracks?: ChaintracksClientApi
```
See also: [ChaintracksClientApi](./services.md#interface-chaintracksclientapi)

###### Property chaintracksFiatExchangeRatesUrl

Due to the default use of a free exchangeratesapiKey with low usage limits,
the `ChaintracksService` can act as a request rate multiplier.

By default the following endpoint is used:
`https://mainnet-chaintracks.babbage.systems/getFiatExchangeRates`

The default transport requires a credential-free public HTTPS address,
pins approved DNS answers, rejects redirects and private/special address
space, and bounds request time and response bytes.

```ts
chaintracksFiatExchangeRatesUrl?: string
```

###### Property disableMapiCallback

MAPI callbacks are deprecated at this time.

```ts
disableMapiCallback?: boolean
```

###### Property exchangeratesapiKey

API key for use accessing fiat exchange rates API at
`https://api.exchangeratesapi.io/v1/latest?access_key=${key}`

The key is encoded as one query value and is never included in provider
error text. Obtain your own api key here:
https://manage.exchangeratesapi.io/signup/free

```ts
exchangeratesapiKey?: string
```

###### Property fiatExchangeRates

The initial approximate fiat exchange rates with USD as base.

```ts
fiatExchangeRates: FiatExchangeRates
```
See also: [FiatExchangeRates](./client.md#interface-fiatexchangerates)

###### Property fiatExchangeRatesFetch

Explicitly trusted transport override for fiat providers. The default
requires credential-free public HTTPS with DNS pinning, no redirects, a
deadline, and a bounded response. Intended for tests or controlled local
development only.

```ts
fiatExchangeRatesFetch?: typeof fetch
```

###### Property fiatUpdateMsecs

Update interval for Fiat exchange rates.
Default is 24 hours.

```ts
fiatUpdateMsecs: number
```

###### Property taalApiKey

As of 2025-08-31 the `taalApiKey` is unused for default configured services.
See `arcConfig` instead.

```ts
taalApiKey?: string
```

###### Property telemetry

Optional provider-neutral service and ChainTracks tracing.

```ts
telemetry?: TelemetryConfig
```

###### Property whatsOnChainApiKey

Api key for use accessing WhatsOnChain API at
mainnet: `https://api.whatsonchain.com/v1/bsv/main`
testnet: `https://api.whatsonchain.com/v1/bsv/test`

```ts
whatsOnChainApiKey?: string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletSettings

```ts
export interface WalletSettings {
    trustSettings: TrustSettings;
    theme?: WalletTheme;
    currency?: string;
    permissionMode?: string;
}
```

See also: [TrustSettings](./client.md#interface-trustsettings), [WalletTheme](./client.md#interface-wallettheme)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletSettingsManagerConfig

```ts
export interface WalletSettingsManagerConfig {
    defaultSettings: WalletSettings;
}
```

See also: [WalletSettings](./client.md#interface-walletsettings)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletSigner

```ts
export interface WalletSigner {
    isWalletSigner: true;
    chain: Chain;
    keyDeriver: KeyDeriverApi;
}
```

See also: [Chain](./client.md#type-chain)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletStorage

This is the `WalletStorage` interface implemented by a class such as `WalletStorageManager`,
which manges an active and set of backup storage providers.

Access and conrol is not directly managed. Typically each request is made with an associated identityKey
and it is left to the providers: physical access or remote channel authentication.

```ts
export interface WalletStorage {
    isStorageProvider: () => boolean;
    isAvailable: () => boolean;
    makeAvailable: () => Promise<TableSettings>;
    migrate: (storageName: string, storageIdentityKey: string) => Promise<string>;
    destroy: () => Promise<void>;
    setServices: (v: WalletServices) => void;
    getServices: () => WalletServices;
    getSettings: () => TableSettings;
    getAuth: () => Promise<AuthId>;
    findOrInsertUser: (identityKey: string) => Promise<{
        user: TableUser;
        isNew: boolean;
    }>;
    abortAction: (args: AbortActionArgs) => Promise<AbortActionResult>;
    createAction: (args: Validation.ValidCreateActionArgs) => Promise<StorageCreateActionResult>;
    processAction: (args: StorageProcessActionArgs) => Promise<StorageProcessActionResults>;
    prepareNoSendExpiry?: (args: Validation.ValidCreateActionArgs) => Promise<StoragePrepareNoSendExpiryResult>;
    activateNoSendExpiry?: (args: StorageActivateNoSendExpiryArgs) => Promise<StorageActivateNoSendExpiryResult>;
    armNoSendExpiry?: (args: StorageArmNoSendExpiryArgs) => Promise<void>;
    getCapabilities: () => Promise<StorageCapabilities>;
    beginActionBatch: (args: BeginActionBatchArgs) => Promise<BeginActionBatchResult>;
    extendActionBatch: (args: ExtendActionBatchArgs) => Promise<ExtendActionBatchResult>;
    renewActionBatch: (batchId: string) => Promise<RenewActionBatchResult>;
    resumeActionBatch?: (args: ResumeActionBatchArgs) => Promise<ResumeActionBatchResult>;
    prepareActionBatchCommit: (manifest: ActionBatchManifest) => Promise<PrepareActionBatchCommitResult>;
    putActionBatchBlob: (args: PutActionBatchBlobArgs) => Promise<void>;
    putActionBatchPack?: (args: PutActionBatchPackArgs) => Promise<void>;
    commitActionBatch: (manifest: ActionBatchManifest) => Promise<CommitActionBatchResult>;
    commitActionBatchByDigest?: (args: CommitActionBatchByDigestArgs) => Promise<CommitActionBatchResult>;
    abortActionBatch: (batchId: string) => Promise<AbortActionBatchResult>;
    internalizeAction: (args: InternalizeActionArgs) => Promise<InternalizeActionResult>;
    findCertificates: (args: FindCertificatesArgs) => Promise<TableCertificateX[]>;
    findOutputBaskets: (args: FindOutputBasketsArgs) => Promise<TableOutputBasket[]>;
    findOutputs: (args: FindOutputsArgs) => Promise<TableOutput[]>;
    findProvenTxReqs: (args: FindProvenTxReqsArgs) => Promise<TableProvenTxReq[]>;
    listActions: (args: Validation.ValidListActionsArgs) => Promise<ListActionsResult>;
    listCertificates: (args: Validation.ValidListCertificatesArgs) => Promise<ListCertificatesResult>;
    listOutputs: (args: Validation.ValidListOutputsArgs) => Promise<ListOutputsResult>;
    insertCertificate: (certificate: TableCertificateX) => Promise<number>;
    relinquishCertificate: (args: RelinquishCertificateArgs) => Promise<number>;
    relinquishOutput: (args: RelinquishOutputArgs) => Promise<number>;
    getStores: () => WalletStorageInfo[];
}
```

See also: [AbortActionBatchResult](./client.md#interface-abortactionbatchresult), [ActionBatchManifest](./client.md#interface-actionbatchmanifest), [AuthId](./client.md#interface-authid), [BeginActionBatchArgs](./client.md#interface-beginactionbatchargs), [BeginActionBatchResult](./client.md#interface-beginactionbatchresult), [CommitActionBatchByDigestArgs](./client.md#interface-commitactionbatchbydigestargs), [CommitActionBatchResult](./client.md#interface-commitactionbatchresult), [ExtendActionBatchArgs](./client.md#interface-extendactionbatchargs), [ExtendActionBatchResult](./client.md#interface-extendactionbatchresult), [FindCertificatesArgs](./client.md#interface-findcertificatesargs), [FindOutputBasketsArgs](./client.md#interface-findoutputbasketsargs), [FindOutputsArgs](./client.md#interface-findoutputsargs), [FindProvenTxReqsArgs](./client.md#interface-findproventxreqsargs), [PrepareActionBatchCommitResult](./client.md#interface-prepareactionbatchcommitresult), [PutActionBatchBlobArgs](./client.md#interface-putactionbatchblobargs), [PutActionBatchPackArgs](./client.md#interface-putactionbatchpackargs), [RenewActionBatchResult](./client.md#interface-renewactionbatchresult), [ResumeActionBatchArgs](./client.md#interface-resumeactionbatchargs), [ResumeActionBatchResult](./client.md#interface-resumeactionbatchresult), [StorageActivateNoSendExpiryArgs](./client.md#interface-storageactivatenosendexpiryargs), [StorageActivateNoSendExpiryResult](./client.md#interface-storageactivatenosendexpiryresult), [StorageArmNoSendExpiryArgs](./client.md#interface-storagearmnosendexpiryargs), [StorageCapabilities](./client.md#interface-storagecapabilities), [StorageCreateActionResult](./client.md#interface-storagecreateactionresult), [StoragePrepareNoSendExpiryResult](./client.md#interface-storagepreparenosendexpiryresult), [StorageProcessActionArgs](./client.md#interface-storageprocessactionargs), [StorageProcessActionResults](./client.md#interface-storageprocessactionresults), [TableCertificateX](./storage.md#interface-tablecertificatex), [TableOutput](./storage.md#interface-tableoutput), [TableOutputBasket](./storage.md#interface-tableoutputbasket), [TableProvenTxReq](./storage.md#interface-tableproventxreq), [TableSettings](./storage.md#interface-tablesettings), [TableUser](./storage.md#interface-tableuser), [WalletServices](./client.md#interface-walletservices), [WalletStorageInfo](./client.md#interface-walletstorageinfo), [abortActionBatch](./storage.md#function-abortactionbatch), [activateNoSendExpiry](./storage.md#function-activatenosendexpiry), [armNoSendExpiry](./storage.md#function-armnosendexpiry), [beginActionBatch](./storage.md#function-beginactionbatch), [commitActionBatch](./storage.md#function-commitactionbatch), [commitActionBatchByDigest](./storage.md#function-commitactionbatchbydigest), [createAction](./storage.md#function-createaction), [extendActionBatch](./storage.md#function-extendactionbatch), [internalizeAction](./storage.md#function-internalizeaction), [listActions](./storage.md#function-listactions), [listCertificates](./storage.md#function-listcertificates), [listOutputs](./storage.md#function-listoutputs), [prepareActionBatchCommit](./storage.md#function-prepareactionbatchcommit), [prepareNoSendExpiry](./storage.md#function-preparenosendexpiry), [processAction](./storage.md#function-processaction), [putActionBatchBlob](./storage.md#function-putactionbatchblob), [putActionBatchPack](./storage.md#function-putactionbatchpack), [renewActionBatch](./storage.md#function-renewactionbatch), [resumeActionBatch](./storage.md#function-resumeactionbatch)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletStorageInfo

Snapshot of the current state of a storage provider configured for an `WalletStorageManager`.

```ts
export interface WalletStorageInfo {
    isActive: boolean;
    isEnabled: boolean;
    isBackup: boolean;
    isConflicting: boolean;
    userId: number;
    storageIdentityKey: string;
    storageName: string;
    storageClass: string;
    endpointURL?: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletStorageProvider

This is the `WalletStorage` interface implemented with authentication checking and
is the actual minimal interface implemented by storage and remoted storage providers.

```ts
export interface WalletStorageProvider extends WalletStorageSync {
    isStorageProvider: () => boolean;
    setServices: (v: WalletServices) => void;
}
```

See also: [WalletServices](./client.md#interface-walletservices), [WalletStorageSync](./client.md#interface-walletstoragesync)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletStorageReader

```ts
export interface WalletStorageReader {
    isAvailable: () => boolean;
    getServices: () => WalletServices;
    getSettings: () => TableSettings;
    findCertificatesAuth: (auth: AuthId, args: FindCertificatesArgs) => Promise<TableCertificateX[]>;
    findOutputBasketsAuth: (auth: AuthId, args: FindOutputBasketsArgs) => Promise<TableOutputBasket[]>;
    findOutputsAuth: (auth: AuthId, args: FindOutputsArgs) => Promise<TableOutput[]>;
    findProvenTxReqs: (args: FindProvenTxReqsArgs) => Promise<TableProvenTxReq[]>;
    listActions: (auth: AuthId, vargs: Validation.ValidListActionsArgs) => Promise<ListActionsResult>;
    listCertificates: (auth: AuthId, vargs: Validation.ValidListCertificatesArgs) => Promise<ListCertificatesResult>;
    listOutputs: (auth: AuthId, vargs: Validation.ValidListOutputsArgs) => Promise<ListOutputsResult>;
}
```

See also: [AuthId](./client.md#interface-authid), [FindCertificatesArgs](./client.md#interface-findcertificatesargs), [FindOutputBasketsArgs](./client.md#interface-findoutputbasketsargs), [FindOutputsArgs](./client.md#interface-findoutputsargs), [FindProvenTxReqsArgs](./client.md#interface-findproventxreqsargs), [TableCertificateX](./storage.md#interface-tablecertificatex), [TableOutput](./storage.md#interface-tableoutput), [TableOutputBasket](./storage.md#interface-tableoutputbasket), [TableProvenTxReq](./storage.md#interface-tableproventxreq), [TableSettings](./storage.md#interface-tablesettings), [WalletServices](./client.md#interface-walletservices), [listActions](./storage.md#function-listactions), [listCertificates](./storage.md#function-listcertificates), [listOutputs](./storage.md#function-listoutputs)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletStorageSync

```ts
export interface WalletStorageSync extends WalletStorageWriter {
    getSyncCheckpoint?: (auth: AuthId, storageIdentityKey: string, storageName: string) => Promise<SyncCheckpoint | undefined>;
    findOrInsertSyncStateAuth: (auth: AuthId, storageIdentityKey: string, storageName: string) => Promise<{
        syncState: TableSyncState;
        isNew: boolean;
    }>;
    setActive: (auth: AuthId, newActiveStorageIdentityKey: string) => Promise<number>;
    getSyncChunk: (args: RequestSyncChunkArgs) => Promise<SyncChunk>;
    processSyncChunk: (args: RequestSyncChunkArgs, chunk: SyncChunk) => Promise<ProcessSyncChunkResult>;
}
```

See also: [AuthId](./client.md#interface-authid), [ProcessSyncChunkResult](./client.md#interface-processsyncchunkresult), [RequestSyncChunkArgs](./client.md#interface-requestsyncchunkargs), [SyncCheckpoint](./client.md#interface-synccheckpoint), [SyncChunk](./client.md#interface-syncchunk), [TableSyncState](./storage.md#interface-tablesyncstate), [WalletStorageWriter](./client.md#interface-walletstoragewriter), [getSyncChunk](./storage.md#function-getsyncchunk)

###### Property getSyncCheckpoint

Compact writer checkpoint. Undefined means a legacy remote provider.

```ts
getSyncCheckpoint?: (auth: AuthId, storageIdentityKey: string, storageName: string) => Promise<SyncCheckpoint | undefined>
```
See also: [AuthId](./client.md#interface-authid), [SyncCheckpoint](./client.md#interface-synccheckpoint)

###### Property setActive

Updagte the `activeStorage` property of the authenticated user by their `userId`.

```ts
setActive: (auth: AuthId, newActiveStorageIdentityKey: string) => Promise<number>
```
See also: [AuthId](./client.md#interface-authid)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletStorageSyncReader

This is the minimal interface required for a WalletStorageProvider to export data to another provider.

```ts
export interface WalletStorageSyncReader {
    makeAvailable: () => Promise<TableSettings>;
    getSyncChunk: (args: RequestSyncChunkArgs) => Promise<SyncChunk>;
}
```

See also: [RequestSyncChunkArgs](./client.md#interface-requestsyncchunkargs), [SyncChunk](./client.md#interface-syncchunk), [TableSettings](./storage.md#interface-tablesettings), [getSyncChunk](./storage.md#function-getsyncchunk)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletStorageWriter

```ts
export interface WalletStorageWriter extends WalletStorageReader {
    makeAvailable: () => Promise<TableSettings>;
    migrate: (storageName: string, storageIdentityKey: string) => Promise<string>;
    destroy: () => Promise<void>;
    findOrInsertUser: (identityKey: string) => Promise<{
        user: TableUser;
        isNew: boolean;
    }>;
    abortAction: (auth: AuthId, args: AbortActionArgs) => Promise<AbortActionResult>;
    createAction: (auth: AuthId, args: Validation.ValidCreateActionArgs) => Promise<StorageCreateActionResult>;
    processAction: (auth: AuthId, args: StorageProcessActionArgs) => Promise<StorageProcessActionResults>;
    prepareNoSendExpiry?: (auth: AuthId, args: Validation.ValidCreateActionArgs) => Promise<StoragePrepareNoSendExpiryResult>;
    activateNoSendExpiry?: (auth: AuthId, args: StorageActivateNoSendExpiryArgs) => Promise<StorageActivateNoSendExpiryResult>;
    armNoSendExpiry?: (auth: AuthId, args: StorageArmNoSendExpiryArgs) => Promise<void>;
    getCapabilities: () => Promise<StorageCapabilities>;
    beginActionBatch: (auth: AuthId, args: BeginActionBatchArgs) => Promise<BeginActionBatchResult>;
    extendActionBatch: (auth: AuthId, args: ExtendActionBatchArgs) => Promise<ExtendActionBatchResult>;
    renewActionBatch: (auth: AuthId, batchId: string) => Promise<RenewActionBatchResult>;
    resumeActionBatch?: (auth: AuthId, args: ResumeActionBatchArgs) => Promise<ResumeActionBatchResult>;
    prepareActionBatchCommit: (auth: AuthId, manifest: ActionBatchManifest) => Promise<PrepareActionBatchCommitResult>;
    putActionBatchBlob: (auth: AuthId, args: PutActionBatchBlobArgs) => Promise<void>;
    putActionBatchPack?: (auth: AuthId, args: PutActionBatchPackArgs) => Promise<void>;
    commitActionBatch: (auth: AuthId, manifest: ActionBatchManifest) => Promise<CommitActionBatchResult>;
    commitActionBatchByDigest?: (auth: AuthId, args: CommitActionBatchByDigestArgs) => Promise<CommitActionBatchResult>;
    abortActionBatch: (auth: AuthId, batchId: string) => Promise<AbortActionBatchResult>;
    internalizeAction: (auth: AuthId, args: InternalizeActionArgs) => Promise<StorageInternalizeActionResult>;
    insertCertificateAuth: (auth: AuthId, certificate: TableCertificateX) => Promise<number>;
    relinquishCertificate: (auth: AuthId, args: RelinquishCertificateArgs) => Promise<number>;
    relinquishOutput: (auth: AuthId, args: RelinquishOutputArgs) => Promise<number>;
}
```

See also: [AbortActionBatchResult](./client.md#interface-abortactionbatchresult), [ActionBatchManifest](./client.md#interface-actionbatchmanifest), [AuthId](./client.md#interface-authid), [BeginActionBatchArgs](./client.md#interface-beginactionbatchargs), [BeginActionBatchResult](./client.md#interface-beginactionbatchresult), [CommitActionBatchByDigestArgs](./client.md#interface-commitactionbatchbydigestargs), [CommitActionBatchResult](./client.md#interface-commitactionbatchresult), [ExtendActionBatchArgs](./client.md#interface-extendactionbatchargs), [ExtendActionBatchResult](./client.md#interface-extendactionbatchresult), [PrepareActionBatchCommitResult](./client.md#interface-prepareactionbatchcommitresult), [PutActionBatchBlobArgs](./client.md#interface-putactionbatchblobargs), [PutActionBatchPackArgs](./client.md#interface-putactionbatchpackargs), [RenewActionBatchResult](./client.md#interface-renewactionbatchresult), [ResumeActionBatchArgs](./client.md#interface-resumeactionbatchargs), [ResumeActionBatchResult](./client.md#interface-resumeactionbatchresult), [StorageActivateNoSendExpiryArgs](./client.md#interface-storageactivatenosendexpiryargs), [StorageActivateNoSendExpiryResult](./client.md#interface-storageactivatenosendexpiryresult), [StorageArmNoSendExpiryArgs](./client.md#interface-storagearmnosendexpiryargs), [StorageCapabilities](./client.md#interface-storagecapabilities), [StorageCreateActionResult](./client.md#interface-storagecreateactionresult), [StorageInternalizeActionResult](./client.md#interface-storageinternalizeactionresult), [StoragePrepareNoSendExpiryResult](./client.md#interface-storagepreparenosendexpiryresult), [StorageProcessActionArgs](./client.md#interface-storageprocessactionargs), [StorageProcessActionResults](./client.md#interface-storageprocessactionresults), [TableCertificateX](./storage.md#interface-tablecertificatex), [TableSettings](./storage.md#interface-tablesettings), [TableUser](./storage.md#interface-tableuser), [WalletStorageReader](./client.md#interface-walletstoragereader), [abortActionBatch](./storage.md#function-abortactionbatch), [activateNoSendExpiry](./storage.md#function-activatenosendexpiry), [armNoSendExpiry](./storage.md#function-armnosendexpiry), [beginActionBatch](./storage.md#function-beginactionbatch), [commitActionBatch](./storage.md#function-commitactionbatch), [commitActionBatchByDigest](./storage.md#function-commitactionbatchbydigest), [createAction](./storage.md#function-createaction), [extendActionBatch](./storage.md#function-extendactionbatch), [internalizeAction](./storage.md#function-internalizeaction), [prepareActionBatchCommit](./storage.md#function-prepareactionbatchcommit), [prepareNoSendExpiry](./storage.md#function-preparenosendexpiry), [processAction](./storage.md#function-processaction), [putActionBatchBlob](./storage.md#function-putactionbatchblob), [putActionBatchPack](./storage.md#function-putactionbatchpack), [renewActionBatch](./storage.md#function-renewactionbatch), [resumeActionBatch](./storage.md#function-resumeactionbatch)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletTheme

```ts
export interface WalletTheme {
    mode: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WalletToolboxWhatsOnChainConfig

```ts
export interface WalletToolboxWhatsOnChainConfig extends WhatsOnChainConfig {
    requestGate?: () => Promise<void>;
    requestTimeoutMsecs?: number;
}
```

###### Property requestGate

Optional request-start gate used by ChainTracks' shared public-rate scheduler.

```ts
requestGate?: () => Promise<void>
```

###### Property requestTimeoutMsecs

Whole-request deadline applied to every explorer call. Defaults to 30 seconds.

```ts
requestTimeoutMsecs?: number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WocChainInfo

```ts
export interface WocChainInfo {
    chain: string;
    blocks: number;
    headers: number;
    bestblockhash: string;
    difficulty: number;
    mediantime: number;
    verificationprogress: number;
    pruned: boolean;
    chainwork: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: WocHeader

```ts
export interface WocHeader {
    hash: string;
    size: number;
    height: number;
    version: number;
    versionHex: string;
    merkleroot: string;
    time: number;
    mediantime: number;
    nonce: number;
    bits: number | string;
    difficulty: number;
    chainwork: string;
    previousblockhash: string;
    confirmations: number;
    txcount: number;
    nextblockhash: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: XValidCreateActionInput

```ts
export interface XValidCreateActionInput extends Validation.ValidCreateActionInput {
    vin: number;
    lockingScript: Script;
    satoshis: number;
    output?: TableOutput;
}
```

See also: [TableOutput](./storage.md#interface-tableoutput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Interface: XValidCreateActionOutput

```ts
export interface XValidCreateActionOutput extends Validation.ValidCreateActionOutput {
    vout: number;
    providedBy: StorageProvidedBy;
    purpose?: string;
    derivationSuffix?: string;
    keyOffset?: string;
}
```

See also: [StorageProvidedBy](./client.md#type-storageprovidedby)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
#### Classes

| | | |
| --- | --- | --- |
| [ARC](#class-arc) | [GoChaintracksServiceClient](#class-gochaintracksserviceclient) | [TaskReconcilePendingTransactions](#class-taskreconcilependingtransactions) |
| [ActionBatchController](#class-actionbatchcontroller) | [HeightRange](#class-heightrange) | [TaskReorg](#class-taskreorg) |
| [ArcSSEClient](#class-arcsseclient) | [InlineBulkFileDataValidator](#class-inlinebulkfiledatavalidator) | [TaskReviewDoubleSpends](#class-taskreviewdoublespends) |
| [Arcade](#class-arcade) | [MergeEntity](#class-mergeentity) | [TaskReviewProvenTxs](#class-taskreviewproventxs) |
| [Bitails](#class-bitails) | [MockChainMigrations](#class-mockchainmigrations) | [TaskReviewStatus](#class-taskreviewstatus) |
| [BulkFileDataManager](#class-bulkfiledatamanager) | [MockChainStorage](#class-mockchainstorage) | [TaskReviewUtxos](#class-taskreviewutxos) |
| [BulkFileDataReader](#class-bulkfiledatareader) | [MockChainTracker](#class-mockchaintracker) | [TaskSendWaiting](#class-tasksendwaiting) |
| [BulkFileDataValidationError](#class-bulkfiledatavalidationerror) | [MockMiner](#class-mockminer) | [TaskUnFail](#class-taskunfail) |
| [BulkHeaderFile](#class-bulkheaderfile) | [MockServices](#class-mockservices) | [WERR_BAD_REQUEST](#class-werr_bad_request) |
| [BulkHeaderFileFs](#class-bulkheaderfilefs) | [Monitor](#class-monitor) | [WERR_BROADCAST_UNAVAILABLE](#class-werr_broadcast_unavailable) |
| [BulkHeaderFileStorage](#class-bulkheaderfilestorage) | [PreparedBeefCoordinator](#class-preparedbeefcoordinator) | [WERR_INSUFFICIENT_FUNDS](#class-werr_insufficient_funds) |
| [BulkHeaderFiles](#class-bulkheaderfiles) | [PrivilegedKeyManager](#class-privilegedkeymanager) | [WERR_INTERNAL](#class-werr_internal) |
| [CanonicalChangeSelector](#class-canonicalchangeselector) | [ScriptTemplateBRC29](#class-scripttemplatebrc29) | [WERR_INVALID_MERKLE_ROOT](#class-werr_invalid_merkle_root) |
| [ChaintracksChainTracker](#class-chaintrackschaintracker) | [SdkWhatsOnChain](#class-sdkwhatsonchain) | [WERR_INVALID_OPERATION](#class-werr_invalid_operation) |
| [ChaintracksFetch](#class-chaintracksfetch) | [ServiceCollection](#class-servicecollection) | [WERR_INVALID_PARAMETER](#class-werr_invalid_parameter) |
| [ChaintracksFetchError](#class-chaintracksfetcherror) | [Services](#class-services) | [WERR_INVALID_PUBLIC_KEY](#class-werr_invalid_public_key) |
| [ChaintracksServiceClient](#class-chaintracksserviceclient) | [SingleWriterMultiReaderLock](#class-singlewritermultireaderlock) | [WERR_MISSING_PARAMETER](#class-werr_missing_parameter) |
| [ChaintracksStorageBase](#class-chaintracksstoragebase) | [StaleSyncProofError](#class-stalesyncprooferror) | [WERR_NETWORK_CHAIN](#class-werr_network_chain) |
| [EntityBase](#class-entitybase) | [StorageProvider](#class-storageprovider) | [WERR_NOT_ACTIVE](#class-werr_not_active) |
| [EntityCertificate](#class-entitycertificate) | [StorageReader](#class-storagereader) | [WERR_NOT_IMPLEMENTED](#class-werr_not_implemented) |
| [EntityCertificateField](#class-entitycertificatefield) | [StorageReaderWriter](#class-storagereaderwriter) | [WERR_REVIEW_ACTIONS](#class-werr_review_actions) |
| [EntityCommission](#class-entitycommission) | [SyncPageBudget](#class-syncpagebudget) | [WERR_UNAUTHORIZED](#class-werr_unauthorized) |
| [EntityOutput](#class-entityoutput) | [TaskArcadeSSE](#class-taskarcadesse) | [WERR_UTXO_REVIEW_INCONCLUSIVE](#class-werr_utxo_review_inconclusive) |
| [EntityOutputBasket](#class-entityoutputbasket) | [TaskCheckForProofs](#class-taskcheckforproofs) | [Wallet](#class-wallet) |
| [EntityOutputTag](#class-entityoutputtag) | [TaskCheckNoSends](#class-taskchecknosends) | [WalletError](#class-walleterror) |
| [EntityOutputTagMap](#class-entityoutputtagmap) | [TaskCleanupActionBatches](#class-taskcleanupactionbatches) | [WalletMonitorTask](#class-walletmonitortask) |
| [EntityProvenTx](#class-entityproventx) | [TaskClock](#class-taskclock) | [WalletSettingsManager](#class-walletsettingsmanager) |
| [EntityProvenTxReq](#class-entityproventxreq) | [TaskFailAbandoned](#class-taskfailabandoned) | [WalletSigner](#class-walletsigner) |
| [EntitySyncState](#class-entitysyncstate) | [TaskMineBlock](#class-taskmineblock) | [WalletStorageManager](#class-walletstoragemanager) |
| [EntityTransaction](#class-entitytransaction) | [TaskMonitorCallHistory](#class-taskmonitorcallhistory) | [WhatsOnChain](#class-whatsonchain) |
| [EntityTxLabel](#class-entitytxlabel) | [TaskNewHeader](#class-tasknewheader) | [WhatsOnChainNoServices](#class-whatsonchainnoservices) |
| [EntityTxLabelMap](#class-entitytxlabelmap) | [TaskNoSendExpiry](#class-tasknosendexpiry) |  |
| [EntityUser](#class-entityuser) | [TaskPurge](#class-taskpurge) |  |

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---

##### Class: ARC

Represents an ARC transaction broadcaster.

```ts
export class ARC {
    readonly name: string;
    readonly URL: string;
    readonly apiKey: string | undefined;
    readonly deploymentId: string;
    readonly callbackUrl: string | undefined;
    readonly callbackToken: string | undefined;
    readonly headers: Record<string, string> | undefined;
    constructor(URL: string, config?: ArcConfig, name?: string);
    constructor(URL: string, apiKey?: string, name?: string);
    constructor(URL: string, config?: string | ArcConfig, name?: string)
    async postRawTx(rawTx: HexString, txids?: string[]): Promise<PostTxResultForTxid>
    async postBeef(beef: Beef, txids: string[]): Promise<PostBeefResult>
    async getTxData(txid: string): Promise<ArcMinerGetTxData>
}
```

See also: [ArcConfig](./services.md#interface-arcconfig), [ArcMinerGetTxData](./services.md#interface-arcminergettxdata), [PostBeefResult](./client.md#interface-postbeefresult), [PostTxResultForTxid](./client.md#interface-posttxresultfortxid)

###### Constructor

Constructs an instance of the ARC broadcaster.

```ts
constructor(URL: string, config?: ArcConfig, name?: string)
```
See also: [ArcConfig](./services.md#interface-arcconfig)

Argument Details

+ **URL**
  + The URL endpoint for the ARC API.
+ **config**
  + Configuration options for the ARC broadcaster.

###### Constructor

Constructs an instance of the ARC broadcaster.

```ts
constructor(URL: string, apiKey?: string, name?: string)
```

Argument Details

+ **URL**
  + The URL endpoint for the ARC API.
+ **apiKey**
  + The API key used for authorization with the ARC API.

###### Method getTxData

This seems to only work for recently submitted txids...but that's all we need to complete postBeef!

```ts
async getTxData(txid: string): Promise<ArcMinerGetTxData>
```
See also: [ArcMinerGetTxData](./services.md#interface-arcminergettxdata)

###### Method postBeef

ARC does not natively support a postBeef end-point aware of multiple txids of interest in the Beef.

It does process multiple new transactions, however, which allows results for all txids of interest
to be collected by the `/v1/tx/${txid}` endpoint.

```ts
async postBeef(beef: Beef, txids: string[]): Promise<PostBeefResult>
```
See also: [PostBeefResult](./client.md#interface-postbeefresult)

###### Method postRawTx

The ARC '/v1/tx' endpoint, as of 2025-02-17 supports all of the following hex string formats:
  1. Single serialized raw transaction.
  2. Single EF serialized raw transaction (untested).
  3. V1 serialized Beef (results returned reflect only the last transaction in the beef)

The ARC '/v1/tx' endpoint, as of 2025-02-17 DOES NOT support the following hex string formats:
  1. V2 serialized Beef

```ts
async postRawTx(rawTx: HexString, txids?: string[]): Promise<PostTxResultForTxid>
```
See also: [PostTxResultForTxid](./client.md#interface-posttxresultfortxid)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: ActionBatchController

```ts
export class ActionBatchController {
    constructor(private readonly wallet: Wallet, readonly mode: ActionBatchMode)
    get hasWorkspace(): boolean
    overlayListActions(persisted: ListActionsResult, args: Validation.ValidListActionsArgs): ListActionsResult
    overlayListOutputs(persisted: ListOutputsResult, args: Validation.ValidListOutputsArgs): ListOutputsResult
    async plan(args: Validation.ValidCreateActionArgs): Promise<StorageCreateActionResult | undefined>
    async process(prior: PendingSignAction | undefined, args: Validation.ValidProcessActionArgs): Promise<StorageProcessActionResults | undefined>
    ownsReference(reference: string): boolean
    async abort(): Promise<boolean>
    async abortAction(referenceOrTxid: string): Promise<boolean>
}
```

See also: [ActionBatchMode](./client.md#type-actionbatchmode), [PendingSignAction](./client.md#interface-pendingsignaction), [StorageCreateActionResult](./client.md#interface-storagecreateactionresult), [StorageProcessActionResults](./client.md#interface-storageprocessactionresults), [Wallet](./client.md#class-wallet)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: ArcSSEClient

```ts
export class ArcSSEClient {
    constructor(options: ArcSSEClientOptions)
    get lastEventId(): string | undefined
    connect(): void
    close(): void
    async fetchEvents(): Promise<number>
}
```

See also: [ArcSSEClientOptions](./services.md#interface-arcsseclientoptions)

###### Method close

Close the connection, discard unacknowledged network events, and reset lifecycle state.

```ts
close(): void
```

###### Method connect

Open the SSE connection. Events are processed serially in exact arrival order.

```ts
connect(): void
```

###### Method fetchEvents

Ensure a connection is open; events still commit asynchronously in arrival order.

```ts
async fetchEvents(): Promise<number>
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: Arcade

```ts
export class Arcade {
    readonly name: string;
    readonly URL: string;
    readonly apiKey: string | undefined;
    readonly deploymentId: string;
    readonly callbackUrl: string | undefined;
    readonly callbackToken: string | undefined;
    readonly headers: Record<string, string> | undefined;
    constructor(URL: string, config?: ArcConfig, name?: string);
    constructor(URL: string, apiKey?: string, name?: string);
    constructor(URL: string, config?: string | ArcConfig, name?: string)
    async postRawTx(rawTx: HexString, txids?: string[]): Promise<PostTxResultForTxid>
    async postBeef(beef: Beef, txids: string[]): Promise<PostBeefResult>
    async getTxData(txid: string): Promise<ArcMinerGetTxData>
    async getStatusForTxids(txids: string[]): Promise<GetStatusForTxidsResult>
    async getMerklePath(txid: string, services: WalletServices): Promise<GetMerklePathResult>
}
```

See also: [ArcConfig](./services.md#interface-arcconfig), [ArcMinerGetTxData](./services.md#interface-arcminergettxdata), [GetMerklePathResult](./client.md#interface-getmerklepathresult), [GetStatusForTxidsResult](./client.md#interface-getstatusfortxidsresult), [PostBeefResult](./client.md#interface-postbeefresult), [PostTxResultForTxid](./client.md#interface-posttxresultfortxid), [WalletServices](./client.md#interface-walletservices)

###### Constructor

```ts
constructor(URL: string, config?: ArcConfig, name?: string)
```
See also: [ArcConfig](./services.md#interface-arcconfig)

Argument Details

+ **URL**
  + The Arcade endpoint base URL.

###### Method getStatusForTxids

Adapt Arcade's lifecycle endpoint to the shared transaction-status
provider contract. This lets monitor reconciliation remain operational
when an explorer such as WhatsOnChain is absent. Only network-observed
states count as known; RECEIVED/PENDING_RETRY and terminal rejection
states remain unknown, while MINED/IMMUTABLE are authoritative mined
observations whose proof is validated separately.

```ts
async getStatusForTxids(txids: string[]): Promise<GetStatusForTxidsResult>
```
See also: [GetStatusForTxidsResult](./client.md#interface-getstatusfortxidsresult)

###### Method getTxData

Look up a transaction's current status (and merkle path once mined) via `GET /tx/{txid}`.

```ts
async getTxData(txid: string): Promise<ArcMinerGetTxData>
```
See also: [ArcMinerGetTxData](./services.md#interface-arcminergettxdata)

###### Method postRawTx

Submit a single transaction to Arcade's `POST /tx` endpoint.

`rawTx` must be a single (raw or Extended Format) transaction hex — NOT BEEF. The canonical
txid is taken from `txids` when supplied (Arcade derives the same txid from the parsed tx).

```ts
async postRawTx(rawTx: HexString, txids?: string[]): Promise<PostTxResultForTxid>
```
See also: [PostTxResultForTxid](./client.md#interface-posttxresultfortxid)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: Bitails

```ts
export class Bitails {
    readonly chain: Chain;
    readonly apiKey: string;
    readonly URL: string;
    readonly httpClient: HttpClient;
    readonly requestTimeoutMsecs: number;
    constructor(chain: Chain = "main", config: BitailsConfig = {})
    getHttpHeaders(): Record<string, string>
    async postBeef(beef: Beef, txids: string[]): Promise<PostBeefResult>
    async postRaws(raws: HexString[], txids?: string[]): Promise<PostBeefResult>
    async getMerklePath(txid: string, services: WalletServices): Promise<GetMerklePathResult>
}
```

See also: [BitailsConfig](./services.md#interface-bitailsconfig), [Chain](./client.md#type-chain), [GetMerklePathResult](./client.md#interface-getmerklepathresult), [PostBeefResult](./client.md#interface-postbeefresult), [WalletServices](./client.md#interface-walletservices)

###### Method postBeef

Bitails does not natively support a postBeef end-point aware of multiple txids of interest in the Beef.

Send rawTx in `txids` order from beef.

```ts
async postBeef(beef: Beef, txids: string[]): Promise<PostBeefResult>
```
See also: [PostBeefResult](./client.md#interface-postbeefresult)

###### Method postRaws

```ts
async postRaws(raws: HexString[], txids?: string[]): Promise<PostBeefResult>
```
See also: [PostBeefResult](./client.md#interface-postbeefresult)

Argument Details

+ **raws**
  + Array of raw transactions to broadcast as hex strings
+ **txids**
  + Array of txids for transactions in raws for which results are requested, remaining raws are supporting only.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: BulkFileDataManager

Manages bulk file data (typically 8MB chunks of 100,000 headers each).

If not cached in memory,
optionally fetches data by `sourceUrl` from CDN on demand,
optionally finds data by `fileId` in a database on demand,
and retains a limited number of files in memory,
subject to the optional `maxRetained` limit.

```ts
export class BulkFileDataManager {
    static createDefaultOptions(chain: Chain): BulkFileDataManagerOptions
    readonly chain: Chain;
    readonly maxPerFile: number;
    readonly fetch?: ChaintracksFetchApi;
    readonly maxRetained?: number;
    readonly fromKnownSourceUrl?: string;
    readonly cache?: BulkFileDataCacheApi;
    readonly downloadBudget?: BulkFileDownloadBudgetApi;
    readonly validator: BulkFileDataValidatorApi;
    readonly failedLoadRetryMsecs: number;
    constructor(options: BulkFileDataManagerOptions | Chain)
    getStats(): BulkFileDataManagerStats
    async deleteBulkFiles(): Promise<void>
    async setStorage(storage: ChaintracksStorageBulkFileApi, log: (...args: any[]) => void): Promise<void>
    heightRangesFromBulkFiles(files: BulkHeaderFileInfo[]): {
        all: HeightRange;
        cdn: HeightRange;
        incremental: HeightRange;
    }
    async createReader(range?: HeightRange, maxBufferSize?: number): Promise<BulkFileDataReader>
    async updateFromUrl(cdnUrl: string): Promise<void>
    async merge(files: BulkHeaderFileInfo[]): Promise<BulkFileDataManagerMergeResult>
    toLogString(what?: BulkFileDataManagerMergeResult | BulkFileData[] | BulkHeaderFileInfo[]): string
    async mergeIncrementalBlockHeaders(newBulkHeaders: BlockHeader[], incrementalChainWork?: string): Promise<void>
    async getBulkFiles(keepData?: boolean): Promise<BulkHeaderFileInfo[]>
    async getHeightRange(): Promise<HeightRange>
    async getDataFromFile(file: BulkHeaderFileInfo, offset?: number, length?: number): Promise<Uint8Array | undefined>
    async findHeaderForHeightOrUndefined(height: number): Promise<BlockHeader | undefined>
    async getFileForHeight(height: number): Promise<BulkHeaderFileInfo | undefined>
    async getLastFile(fromEnd = 1): Promise<BulkHeaderFileInfo | undefined>
    async ReValidate(): Promise<void>
    async exportHeadersToFs(toFs: ChaintracksFsApi, toHeadersPerFile: number, toFolder: string, sourceUrl?: string, maxHeight?: number): Promise<void>
    async destroy(): Promise<void>
}
```

See also: [BlockHeader](./client.md#interface-blockheader), [BulkFileDataCacheApi](./services.md#interface-bulkfiledatacacheapi), [BulkFileDataManagerMergeResult](./services.md#interface-bulkfiledatamanagermergeresult), [BulkFileDataManagerOptions](./services.md#interface-bulkfiledatamanageroptions), [BulkFileDataManagerStats](./services.md#interface-bulkfiledatamanagerstats), [BulkFileDataReader](./services.md#class-bulkfiledatareader), [BulkFileDataValidatorApi](./services.md#interface-bulkfiledatavalidatorapi), [BulkFileDownloadBudgetApi](./services.md#interface-bulkfiledownloadbudgetapi), [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo), [Chain](./client.md#type-chain), [ChaintracksFetchApi](./services.md#interface-chaintracksfetchapi), [ChaintracksFsApi](./services.md#interface-chaintracksfsapi), [ChaintracksStorageBulkFileApi](./services.md#interface-chaintracksstoragebulkfileapi), [HeightRange](./services.md#class-heightrange)

###### Method setStorage

If `bfds` are going to be backed by persistent storage,
must be called before making storage available.

Synchronizes bfds and storage files, after which this manager maintains sync.
There should be no changes to bulk files by direct access to storage bulk file methods.

```ts
async setStorage(storage: ChaintracksStorageBulkFileApi, log: (...args: any[]) => void): Promise<void>
```
See also: [ChaintracksStorageBulkFileApi](./services.md#interface-chaintracksstoragebulkfileapi)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: BulkFileDataReader

```ts
export class BulkFileDataReader {
    readonly manager: BulkFileDataManager;
    readonly range: HeightRange;
    readonly maxBufferSize: number;
    nextHeight: number;
    constructor(manager: BulkFileDataManager, range: HeightRange, maxBufferSize: number)
    async read(): Promise<Uint8Array | undefined>
}
```

See also: [BulkFileDataManager](./services.md#class-bulkfiledatamanager), [HeightRange](./services.md#class-heightrange)

###### Method read

```ts
async read(): Promise<Uint8Array | undefined>
```

Returns

an array containing the next `maxBufferSize` bytes of headers from the files.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: BulkFileDataValidationError

Identifies deterministic rejection of the supplied immutable bytes.
Operational failures such as worker crashes and queue saturation deliberately
use ordinary errors so callers preserve the cache entry and avoid downloading
a replacement that cannot be validated.

```ts
export class BulkFileDataValidationError extends Error {
    constructor(message: string, public readonly data?: Uint8Array)
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: BulkHeaderFile

```ts
export abstract class BulkHeaderFile implements BulkHeaderFileInfo {
    chain?: Chain;
    count: number;
    data?: Uint8Array<ArrayBufferLike>;
    fileHash: string | null;
    fileId?: number;
    fileName: string;
    firstHeight: number;
    lastChainWork: string;
    lastHash: string | null;
    prevChainWork: string;
    prevHash: string;
    sourceUrl?: string;
    validated?: boolean;
    constructor(info: BulkHeaderFileInfo)
    abstract readDataFromFile(length: number, offset: number): Promise<Uint8Array | undefined>;
    protected validateReadBounds(length: number, offset: number): void
    get heightRange(): HeightRange
    async ensureData(): Promise<Uint8Array>
    async computeFileHash(): Promise<string>
    async releaseData(): Promise<void>
    toCdnInfo(): BulkHeaderFileInfo
    toStorageInfo(): BulkHeaderFileInfo
}
```

See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo), [Chain](./client.md#type-chain), [HeightRange](./services.md#class-heightrange)

###### Method computeFileHash

Whenever reloading data from a backing store, validated fileHash must be re-verified

```ts
async computeFileHash(): Promise<string>
```

Returns

the sha256 hash of the file's data as base64 string.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: BulkHeaderFileFs

```ts
export class BulkHeaderFileFs extends BulkHeaderFile {
    constructor(info: BulkHeaderFileInfo, public fs: ChaintracksFsApi, public rootFolder: string)
    override async readDataFromFile(length: number, offset: number): Promise<Uint8Array | undefined>
    override async ensureData(): Promise<Uint8Array>
}
```

See also: [BulkHeaderFile](./services.md#class-bulkheaderfile), [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo), [ChaintracksFsApi](./services.md#interface-chaintracksfsapi)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: BulkHeaderFileStorage

```ts
export class BulkHeaderFileStorage extends BulkHeaderFile {
    constructor(info: BulkHeaderFileInfo, public storage: ChaintracksStorageBase, public fetch?: ChaintracksFetchApi)
    override async readDataFromFile(length: number, offset: number): Promise<Uint8Array | undefined>
    override async ensureData(): Promise<Uint8Array>
}
```

See also: [BulkHeaderFile](./services.md#class-bulkheaderfile), [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo), [ChaintracksFetchApi](./services.md#interface-chaintracksfetchapi), [ChaintracksStorageBase](./services.md#class-chaintracksstoragebase)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: BulkHeaderFiles

```ts
export abstract class BulkHeaderFiles implements BulkHeaderFilesInfo {
    constructor(public rootFolder: string, public jsonFilename: string, public files: BulkHeaderFileInfo[], public headersPerFile: number)
}
```

See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo), [BulkHeaderFilesInfo](./services.md#interface-bulkheaderfilesinfo)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: CanonicalChangeSelector

Stateful form of the canonical selector for allocating many inputs from one
candidate set. It preserves exact / least-over / largest-under ordering but
sorts once instead of filtering and sorting the full set per input.

```ts
export class CanonicalChangeSelector<T extends CanonicalFundingCandidate> {
    constructor(outputs: readonly T[])
    take(targetSatoshis: number, exactSatoshis?: number): T | undefined
    release(outputId: number): void
}
```

See also: [CanonicalFundingCandidate](./storage.md#interface-canonicalfundingcandidate)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: ChaintracksChainTracker

```ts
export class ChaintracksChainTracker implements ChainTracker {
    chaintracks: ChaintracksClientApi;
    cache: Record<number, string>;
    options: ChaintracksChainTrackerOptions;
    readonly telemetry: Telemetry;
    constructor(chain?: Chain, chaintracks?: ChaintracksClientApi, options?: ChaintracksChainTrackerOptions)
    async currentHeight(): Promise<number>
    async isValidRootForHeight(root: string, height: number): Promise<boolean>
}
```

See also: [Chain](./client.md#type-chain), [ChaintracksChainTrackerOptions](./services.md#interface-chaintrackschaintrackeroptions), [ChaintracksClientApi](./services.md#interface-chaintracksclientapi)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: ChaintracksFetch

Bounded fetch implementation shared by ChainTracks sources.

Retry policy lives here so callers never multiply attempts. Every attempt
has a deadline that remains active while the response body is consumed, and
every materialized response has an explicit byte ceiling.

```ts
export class ChaintracksFetch implements ChaintracksFetchApi {
    httpClient: HttpClient = defaultHttpClient();
    constructor(options: ChaintracksFetchOptions = {})
    async download(url: string, maxResponseBytes?: number, options?: ChaintracksDownloadOptions): Promise<Uint8Array>
    async fetchJson<R>(url: string): Promise<R>
    pathJoin(baseUrl: string, subpath: string): string
}
```

See also: [ChaintracksDownloadOptions](./services.md#interface-chaintracksdownloadoptions), [ChaintracksFetchApi](./services.md#interface-chaintracksfetchapi), [ChaintracksFetchOptions](./services.md#interface-chaintracksfetchoptions)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: ChaintracksFetchError

```ts
export class ChaintracksFetchError extends Error {
    constructor(message: string, public readonly url: string, public readonly status: number, public readonly statusText: string, public readonly retryAfterMsecs?: number)
    get retryable(): boolean
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: ChaintracksServiceClient

Connects to a ChaintracksService to implement 'ChaintracksClientApi'

```ts
export class ChaintracksServiceClient implements ChaintracksClientApi {
    static createChaintracksServiceClientOptions(): ChaintracksServiceClientOptions
    options: ChaintracksServiceClientOptions;
    constructor(public chain: Chain, serviceUrl: string, options?: ChaintracksServiceClientOptions)
    readonly serviceUrl: string;
    async subscribeHeaders(_listener: HeaderListener): Promise<string>
    async subscribeReorgs(_listener: ReorgListener): Promise<string>
    async unsubscribe(_subscriptionId: string): Promise<boolean>
    async currentHeight(): Promise<number>
    async isValidRootForHeight(root: string, height: number): Promise<boolean>
    async getJsonOrUndefined<T>(path: string): Promise<T | undefined>
    async getJson<T>(path: string): Promise<T>
    async postJsonVoid<T>(path: string, params: T): Promise<void>
    async addHeader(header: BaseBlockHeader): Promise<void>
    async startListening(): Promise<void>
    async listening(): Promise<void>
    async getChain(): Promise<Chain>
    async isListening(): Promise<boolean>
    async isSynchronized(): Promise<boolean>
    async getPresentHeight(): Promise<number>
    async getInfo(): Promise<ChaintracksInfoApi>
    async findChainTipHeader(): Promise<BlockHeader>
    async findChainTipHash(): Promise<string>
    async getHeaders(height: number, count: number): Promise<string>
    async findHeaderForHeight(height: number): Promise<BlockHeader | undefined>
    async findHeaderForBlockHash(hash: string): Promise<BlockHeader | undefined>
}
```

See also: [BaseBlockHeader](./client.md#interface-baseblockheader), [BlockHeader](./client.md#interface-blockheader), [Chain](./client.md#type-chain), [ChaintracksClientApi](./services.md#interface-chaintracksclientapi), [ChaintracksInfoApi](./services.md#interface-chaintracksinfoapi), [ChaintracksServiceClientOptions](./services.md#interface-chaintracksserviceclientoptions), [HeaderListener](./services.md#type-headerlistener), [ReorgListener](./services.md#type-reorglistener)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: ChaintracksStorageBase

Required interface methods of a Chaintracks Storage Engine implementation.

```ts
export abstract class ChaintracksStorageBase implements ChaintracksStorageQueryApi, ChaintracksStorageIngestApi {
    static createStorageBaseOptions(chain: Chain): ChaintracksStorageBaseOptions
    log: (...args: any[]) => void = () => { };
    chain: Chain;
    liveHeightThreshold: number;
    reorgHeightThreshold: number;
    bulkMigrationChunkSize: number;
    batchInsertLimit: number;
    isAvailable: boolean = false;
    hasMigrated: boolean = false;
    bulkManager: BulkFileDataManager;
    constructor(options: ChaintracksStorageBaseOptions)
    protected validateIncomingHeader(header: BlockHeader): BlockHeader
    protected validateLiveHeaderRecord(header: LiveBlockHeader, allowUnassignedHeaderId = false): LiveBlockHeader
    protected validateHeight(height: number, name = "height"): void
    protected validateHeaderId(headerId: number, name = "headerId"): void
    protected validateHash(hash: string, name = "hash"): void
    protected validateRange(range: HeightRange, maximumLength = MAX_PUBLIC_HEADER_RANGE): void
    protected recordTraversalVisit(seen: Set<number>, header: LiveBlockHeader, operation: string): void
    protected validateStoredParentLink(child: LiveBlockHeader, parent: LiveBlockHeader): void
    async shutdown(): Promise<void>
    async makeAvailable(): Promise<void>
    async migrateLatest(): Promise<void>
    async dropAllData(): Promise<void>
    abstract deleteLiveBlockHeaders(): Promise<void>;
    abstract deleteOlderLiveBlockHeaders(maxHeight: number): Promise<number>;
    abstract findChainTipHeader(): Promise<LiveBlockHeader>;
    abstract findChainTipHeaderOrUndefined(): Promise<LiveBlockHeader | undefined>;
    abstract findLiveHeaderForBlockHash(hash: string): Promise<LiveBlockHeader | null>;
    abstract findLiveHeaderForHeaderId(headerId: number): Promise<LiveBlockHeader>;
    abstract findLiveHeaderForHeight(height: number): Promise<LiveBlockHeader | null>;
    abstract findLiveHeaderForMerkleRoot(merkleRoot: string): Promise<LiveBlockHeader | null>;
    abstract findLiveHeightRange(): Promise<HeightRange>;
    abstract findMaxHeaderId(): Promise<number>;
    abstract liveHeadersForBulk(count: number): Promise<LiveBlockHeader[]>;
    abstract getLiveHeaders(range: HeightRange): Promise<LiveBlockHeader[]>;
    abstract insertHeader(header: BlockHeader): Promise<InsertHeaderResult>;
    abstract destroy(): Promise<void>;
    async getBulkHeaders(range: HeightRange): Promise<Uint8Array>
    async getHeadersUint8Array(height: number, count: number): Promise<Uint8Array>
    async getHeaders(height: number, count: number): Promise<BaseBlockHeader[]>
    async deleteBulkBlockHeaders(): Promise<void>
    async getAvailableHeightRanges(): Promise<{
        bulk: HeightRange;
        live: HeightRange;
    }>
    async pruneLiveBlockHeaders(activeTipHeight: number): Promise<void>
    async findChainTipHash(): Promise<string>
    async findChainTipWork(): Promise<string>
    async findChainWorkForBlockHash(hash: string): Promise<string>
    async findBulkFilesHeaderForHeightOrUndefined(height: number): Promise<BlockHeader | undefined>
    async findHeaderForHeightOrUndefined(height: number): Promise<LiveBlockHeader | BlockHeader | undefined>
    async findHeaderForHeight(height: number): Promise<LiveBlockHeader | BlockHeader>
    async isMerkleRootActive(merkleRoot: string): Promise<boolean>
    async findCommonAncestor(header1: LiveBlockHeader, header2: LiveBlockHeader): Promise<LiveBlockHeader>
    async findReorgDepth(header1: LiveBlockHeader, header2: LiveBlockHeader): Promise<number>
    async migrateLiveToBulk(count: number, ignoreLimits = false): Promise<void>
    async addBulkHeaders(headers: BlockHeader[], bulkRange: HeightRange, priorLiveHeaders: BlockHeader[]): Promise<BlockHeader[]>
}
```

See also: [BaseBlockHeader](./client.md#interface-baseblockheader), [BlockHeader](./client.md#interface-blockheader), [BulkFileDataManager](./services.md#class-bulkfiledatamanager), [Chain](./client.md#type-chain), [ChaintracksStorageBaseOptions](./services.md#interface-chaintracksstoragebaseoptions), [ChaintracksStorageIngestApi](./services.md#interface-chaintracksstorageingestapi), [ChaintracksStorageQueryApi](./services.md#interface-chaintracksstoragequeryapi), [HeightRange](./services.md#class-heightrange), [InsertHeaderResult](./services.md#type-insertheaderresult), [LiveBlockHeader](./services.md#interface-liveblockheader)

###### Method insertHeader

```ts
abstract insertHeader(header: BlockHeader): Promise<InsertHeaderResult>
```
See also: [BlockHeader](./client.md#interface-blockheader), [InsertHeaderResult](./services.md#type-insertheaderresult)

Returns

details of conditions found attempting to insert header

Argument Details

+ **header**
  + Header to attempt to add to live storage.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: EntityBase

```ts
export abstract class EntityBase<T> {
    api: T;
    constructor(api: T)
    abstract get id(): number;
    abstract get entityName(): string;
    abstract get entityTable(): string;
    abstract updateApi(): void;
    abstract equals(ei: T, syncMap?: SyncMap): boolean;
    abstract mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>;
    abstract mergeExisting(storage: EntityStorage, since: Date | undefined, ei: T, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>;
    toApi(): T
}
```

See also: [EntityStorage](./storage.md#type-entitystorage), [SyncMap](./storage.md#interface-syncmap), [TrxToken](./client.md#interface-trxtoken)

###### Method equals

Tests for equality or 'merge' / 'convergent' equality if syncMap is provided.

'convergent' equality must satisfy (A sync B) equals (B sync A)

```ts
abstract equals(ei: T, syncMap?: SyncMap): boolean
```
See also: [SyncMap](./storage.md#interface-syncmap)

###### Method mergeExisting

Perform a 'merge' / 'convergent' equality migration of state
from external `ei` to this existing local EntityUser

```ts
abstract mergeExisting(storage: EntityStorage, since: Date | undefined, ei: T, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>
```
See also: [EntityStorage](./storage.md#type-entitystorage), [SyncMap](./storage.md#interface-syncmap), [TrxToken](./client.md#interface-trxtoken)

Returns

true iff entity state changed and was updated to storage

###### Method mergeNew

Perform a 'merge' / 'convergent' equality migration of state
to this new local entity which was constructed
as a copy of the external object.

```ts
abstract mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>
```
See also: [EntityStorage](./storage.md#type-entitystorage), [SyncMap](./storage.md#interface-syncmap), [TrxToken](./client.md#interface-trxtoken)

Argument Details

+ **userId**
  + local userId

###### Method toApi

An entity may decode properties of the underlying Api object on construction.

The `toApi` method forces an `updateApi` before returning the underlying,
now updated, Api object.

```ts
toApi(): T
```

Returns

The underlying Api object with any entity decoded properties updated.

###### Method updateApi

On construction, an entity may decode properties of the `api` object,
such as JSON stringified objects.

The `updateApi` method must re-encode the current state of those decoded properties
into the `api` object.

Used by the `toApi` method to return an updated `api` object.

```ts
abstract updateApi(): void
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: EntityCertificate

```ts
export class EntityCertificate extends EntityBase<TableCertificate> {
    constructor(api?: TableCertificate)
    override updateApi(): void
    get certificateId()
    set certificateId(v: number)
    get created_at()
    set created_at(v: Date)
    get updated_at()
    set updated_at(v: Date)
    get userId()
    set userId(v: number)
    get type()
    set type(v: string)
    get subject()
    set subject(v: string)
    get verifier()
    set verifier(v: string | undefined)
    get serialNumber()
    set serialNumber(v: string)
    get certifier()
    set certifier(v: string)
    get revocationOutpoint()
    set revocationOutpoint(v: string)
    get signature()
    set signature(v: string)
    get isDeleted()
    set isDeleted(v: boolean)
    override get id(): number
    override set id(v: number)
    override get entityName(): string
    override get entityTable(): string
    override equals(ei: TableCertificate, syncMap?: SyncMap): boolean
    static async mergeFind(storage: EntityStorage, userId: number, ei: TableCertificate, syncMap: SyncMap, trx?: TrxToken): Promise<{
        found: boolean;
        eo: EntityCertificate;
        eiId: number;
    }>
    override async mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>
    override async mergeExisting(storage: EntityStorage, since: Date | undefined, ei: TableCertificate, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>
}
```

See also: [EntityBase](./storage.md#class-entitybase), [EntityStorage](./storage.md#type-entitystorage), [SyncMap](./storage.md#interface-syncmap), [TableCertificate](./storage.md#interface-tablecertificate), [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: EntityCertificateField

```ts
export class EntityCertificateField extends EntityBase<TableCertificateField> {
    constructor(api?: TableCertificateField)
    override updateApi(): void
    get userId()
    set userId(v: number)
    get certificateId()
    set certificateId(v: number)
    get created_at()
    set created_at(v: Date)
    get updated_at()
    set updated_at(v: Date)
    get fieldName()
    set fieldName(v: string)
    get fieldValue()
    set fieldValue(v: string)
    get masterKey()
    set masterKey(v: string)
    override get id(): number
    override get entityName(): string
    override get entityTable(): string
    override equals(ei: TableCertificateField, syncMap?: SyncMap | undefined): boolean
    static async mergeFind(storage: EntityStorage, userId: number, ei: TableCertificateField, syncMap: SyncMap, trx?: TrxToken): Promise<{
        found: boolean;
        eo: EntityCertificateField;
        eiId: number;
    }>
    override async mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>
    override async mergeExisting(storage: EntityStorage, since: Date | undefined, ei: TableCertificateField, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>
}
```

See also: [EntityBase](./storage.md#class-entitybase), [EntityStorage](./storage.md#type-entitystorage), [SyncMap](./storage.md#interface-syncmap), [TableCertificateField](./storage.md#interface-tablecertificatefield), [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: EntityCommission

```ts
export class EntityCommission extends EntityBase<TableCommission> {
    constructor(api?: TableCommission)
    override updateApi(): void
    get commissionId()
    set commissionId(v: number)
    get created_at()
    set created_at(v: Date)
    get updated_at()
    set updated_at(v: Date)
    get transactionId()
    set transactionId(v: number)
    get userId()
    set userId(v: number)
    get isRedeemed()
    set isRedeemed(v: boolean)
    get keyOffset()
    set keyOffset(v: string)
    get lockingScript()
    set lockingScript(v: number[])
    get satoshis()
    set satoshis(v: number)
    override get id(): number
    override set id(v: number)
    override get entityName(): string
    override get entityTable(): string
    override equals(ei: TableCommission, syncMap?: SyncMap | undefined): boolean
    static async mergeFind(storage: EntityStorage, userId: number, ei: TableCommission, syncMap: SyncMap, trx?: TrxToken): Promise<{
        found: boolean;
        eo: EntityCommission;
        eiId: number;
    }>
    override async mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>
    override async mergeExisting(storage: EntityStorage, since: Date | undefined, ei: TableCommission, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>
}
```

See also: [EntityBase](./storage.md#class-entitybase), [EntityStorage](./storage.md#type-entitystorage), [SyncMap](./storage.md#interface-syncmap), [TableCommission](./storage.md#interface-tablecommission), [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: EntityOutput

```ts
export class EntityOutput extends EntityBase<TableOutput> {
    constructor(api?: TableOutput)
    override updateApi(): void
    get outputId()
    set outputId(v: number)
    get created_at()
    set created_at(v: Date)
    get updated_at()
    set updated_at(v: Date)
    get userId()
    set userId(v: number)
    get transactionId()
    set transactionId(v: number)
    get basketId()
    set basketId(v: number | undefined)
    get spentBy()
    set spentBy(v: number | undefined)
    get vout()
    set vout(v: number)
    get satoshis()
    set satoshis(v: number)
    get outputDescription()
    set outputDescription(v: string)
    get spendable()
    set spendable(v: boolean)
    get change()
    set change(v: boolean)
    get txid()
    set txid(v: string | undefined)
    get type()
    set type(v: string)
    get providedBy()
    set providedBy(v: StorageProvidedBy)
    get purpose()
    set purpose(v: string)
    get spendingDescription()
    set spendingDescription(v: string | undefined)
    get derivationPrefix()
    set derivationPrefix(v: string | undefined)
    get derivationSuffix()
    set derivationSuffix(v: string | undefined)
    get senderIdentityKey()
    set senderIdentityKey(v: string | undefined)
    get customInstructions()
    set customInstructions(v: string | undefined)
    get lockingScript()
    set lockingScript(v: number[] | undefined)
    get scriptLength()
    set scriptLength(v: number | undefined)
    get scriptOffset()
    set scriptOffset(v: number | undefined)
    override get id(): number
    override set id(v: number)
    override get entityName(): string
    override get entityTable(): string
    override equals(ei: TableOutput, syncMap?: SyncMap | undefined): boolean
    static async mergeFind(storage: EntityStorage, userId: number, ei: TableOutput, syncMap: SyncMap, trx?: TrxToken): Promise<{
        found: boolean;
        eo: EntityOutput;
        eiId: number;
    }>
    override async mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>
    override async mergeExisting(storage: EntityStorage, since: Date | undefined, ei: TableOutput, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>
}
```

See also: [EntityBase](./storage.md#class-entitybase), [EntityStorage](./storage.md#type-entitystorage), [StorageProvidedBy](./client.md#type-storageprovidedby), [SyncMap](./storage.md#interface-syncmap), [TableOutput](./storage.md#interface-tableoutput), [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: EntityOutputBasket

```ts
export class EntityOutputBasket extends EntityBase<TableOutputBasket> {
    constructor(api?: TableOutputBasket)
    get basketId()
    set basketId(v: number)
    get created_at()
    set created_at(v: Date)
    get updated_at()
    set updated_at(v: Date)
    get userId()
    set userId(v: number)
    get name()
    set name(v: string)
    get numberOfDesiredUTXOs()
    set numberOfDesiredUTXOs(v: number)
    get minimumDesiredUTXOValue()
    set minimumDesiredUTXOValue(v: number)
    get isDeleted()
    set isDeleted(v: boolean)
    override get id()
    override set id(v: number)
    override get entityName(): string
    override get entityTable(): string
    override updateApi(): void
    override equals(ei: TableOutputBasket, syncMap?: SyncMap): boolean
    static async mergeFind(storage: EntityStorage, userId: number, ei: TableOutputBasket, syncMap: SyncMap, trx?: TrxToken): Promise<{
        found: boolean;
        eo: EntityOutputBasket;
        eiId: number;
    }>
    override async mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>
    override async mergeExisting(storage: EntityStorage, since: Date | undefined, ei: TableOutputBasket, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>
}
```

See also: [EntityBase](./storage.md#class-entitybase), [EntityStorage](./storage.md#type-entitystorage), [SyncMap](./storage.md#interface-syncmap), [TableOutputBasket](./storage.md#interface-tableoutputbasket), [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: EntityOutputTag

```ts
export class EntityOutputTag extends EntityBase<TableOutputTag> {
    constructor(api?: TableOutputTag)
    override updateApi(): void
    get outputTagId()
    set outputTagId(v: number)
    get created_at()
    set created_at(v: Date)
    get updated_at()
    set updated_at(v: Date)
    get tag()
    set tag(v: string)
    get userId()
    set userId(v: number)
    get isDeleted()
    set isDeleted(v: boolean)
    override get id(): number
    override set id(v: number)
    override get entityName(): string
    override get entityTable(): string
    override equals(ei: TableOutputTag, syncMap?: SyncMap | undefined): boolean
    static async mergeFind(storage: EntityStorage, userId: number, ei: TableOutputTag, syncMap: SyncMap, trx?: TrxToken): Promise<{
        found: boolean;
        eo: EntityOutputTag;
        eiId: number;
    }>
    override async mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>
    override async mergeExisting(storage: EntityStorage, since: Date | undefined, ei: TableOutputTag, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>
}
```

See also: [EntityBase](./storage.md#class-entitybase), [EntityStorage](./storage.md#type-entitystorage), [SyncMap](./storage.md#interface-syncmap), [TableOutputTag](./storage.md#interface-tableoutputtag), [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: EntityOutputTagMap

```ts
export class EntityOutputTagMap extends EntityBase<TableOutputTagMap> {
    constructor(api?: TableOutputTagMap)
    override updateApi(): void
    get outputTagId()
    set outputTagId(v: number)
    get outputId()
    set outputId(v: number)
    get created_at()
    set created_at(v: Date)
    get updated_at()
    set updated_at(v: Date)
    get isDeleted()
    set isDeleted(v: boolean)
    override get id(): number
    override get entityName(): string
    override get entityTable(): string
    override equals(ei: TableOutputTagMap, syncMap?: SyncMap | undefined): boolean
    static async mergeFind(storage: EntityStorage, userId: number, ei: TableOutputTagMap, syncMap: SyncMap, trx?: TrxToken): Promise<{
        found: boolean;
        eo: EntityOutputTagMap;
        eiId: number;
    }>
    override async mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>
    override async mergeExisting(storage: EntityStorage, since: Date | undefined, ei: TableOutputTagMap, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>
}
```

See also: [EntityBase](./storage.md#class-entitybase), [EntityStorage](./storage.md#type-entitystorage), [SyncMap](./storage.md#interface-syncmap), [TableOutputTagMap](./storage.md#interface-tableoutputtagmap), [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: EntityProvenTx

```ts
export class EntityProvenTx extends EntityBase<TableProvenTx> {
    static async fromTxid(txid: string, services: WalletServices, rawTx?: number[]): Promise<ProvenTxFromTxidResult>
    constructor(api?: TableProvenTx)
    override updateApi(): void
    getMerklePath(validateRoots: boolean = true): MerklePath
    _mp?: MerklePath;
    _mpUnchecked?: MerklePath;
    get provenTxId()
    set provenTxId(v: number)
    get created_at()
    set created_at(v: Date)
    get updated_at()
    set updated_at(v: Date)
    get txid()
    set txid(v: string)
    get height()
    set height(v: number)
    get index()
    set index(v: number)
    get merklePath()
    set merklePath(v: number[])
    get rawTx()
    set rawTx(v: number[])
    get blockHash()
    set blockHash(v: string)
    get merkleRoot()
    set merkleRoot(v: string)
    override get id()
    override set id(v: number)
    override get entityName(): string
    override get entityTable(): string
    override equals(ei: TableProvenTx, syncMap?: SyncMap | undefined): boolean
    static async mergeFind(storage: EntityStorage, userId: number, ei: TableProvenTx, syncMap: SyncMap, trx?: TrxToken): Promise<{
        found: boolean;
        eo: EntityProvenTx;
        eiId: number;
    }>
    override async mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>
    override async mergeExisting(storage: EntityStorage, since: Date | undefined, ei: TableProvenTx, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>
    static readonly getProofAttemptsLimit = 8;
    static readonly getProofMinutes = 60;
    static async fromReq(req: EntityProvenTxReq, gmpResult: GetMerklePathResult, countsAsAttempt: boolean, maxRebroadcastAttempts = 0, rootValidator?: MerkleRootValidator): Promise<EntityProvenTx | undefined>
}
```

See also: [EntityBase](./storage.md#class-entitybase), [EntityProvenTxReq](./storage.md#class-entityproventxreq), [EntityStorage](./storage.md#type-entitystorage), [GetMerklePathResult](./client.md#interface-getmerklepathresult), [MerkleRootValidator](./services.md#interface-merklerootvalidator), [ProvenTxFromTxidResult](./storage.md#interface-proventxfromtxidresult), [SyncMap](./storage.md#interface-syncmap), [TableProvenTx](./storage.md#interface-tableproventx), [TrxToken](./client.md#interface-trxtoken), [WalletServices](./client.md#interface-walletservices), [blockHash](./services.md#function-blockhash)

###### Property getProofAttemptsLimit

How high attempts can go before status is forced to invalid

```ts
static readonly getProofAttemptsLimit = 8
```

###### Property getProofMinutes

How many hours we have to try for a poof

```ts
static readonly getProofMinutes = 60
```

###### Method fromReq

Try to create a new ProvenTx from a ProvenTxReq and GetMerkleProofResultApi

Otherwise it returns undefined and updates req.status to either 'unknown', 'invalid', or 'unconfirmed'

```ts
static async fromReq(req: EntityProvenTxReq, gmpResult: GetMerklePathResult, countsAsAttempt: boolean, maxRebroadcastAttempts = 0, rootValidator?: MerkleRootValidator): Promise<EntityProvenTx | undefined>
```
See also: [EntityProvenTx](./storage.md#class-entityproventx), [EntityProvenTxReq](./storage.md#class-entityproventxreq), [GetMerklePathResult](./client.md#interface-getmerklepathresult), [MerkleRootValidator](./services.md#interface-merklerootvalidator)

###### Method fromTxid

Given a txid and optionally its rawTx, create a new ProvenTx object.

rawTx is fetched if not provided.

Only succeeds (proven is not undefined) if a proof is confirmed for rawTx,
and hash of rawTx is confirmed to match txid

The returned ProvenTx and ProvenTxReq objects have not been added to the storage database,
this is optional and can be done by the caller if appropriate.

```ts
static async fromTxid(txid: string, services: WalletServices, rawTx?: number[]): Promise<ProvenTxFromTxidResult>
```
See also: [ProvenTxFromTxidResult](./storage.md#interface-proventxfromtxidresult), [WalletServices](./client.md#interface-walletservices)

###### Method getMerklePath

```ts
getMerklePath(validateRoots: boolean = true): MerklePath
```

Returns

desirialized `MerklePath` object, value is cached.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: EntityProvenTxReq

```ts
export class EntityProvenTxReq extends EntityBase<TableProvenTxReq> {
    static readonly wasBroadcastStatuses: ProvenTxReqStatus[] = ["unmined", "callback", "unconfirmed", "completed"];
    static async fromStorageTxid(storage: EntityStorage, txid: string, trx?: TrxToken): Promise<EntityProvenTxReq | undefined>
    static async fromStorageId(storage: EntityStorage, id: number, trx?: TrxToken): Promise<EntityProvenTxReq>
    static fromTxid(txid: string, rawTx: number[] | Uint8Array, inputBEEF?: number[] | Uint8Array): EntityProvenTxReq
    history: ProvenTxReqHistory;
    notify: ProvenTxReqNotify;
    packApiHistory()
    packApiNotify()
    unpackApiHistory()
    unpackApiNotify()
    get apiHistory(): string
    get apiNotify(): string
    set apiHistory(v: string)
    set apiNotify(v: string)
    updateApi(): void
    unpackApi(): void
    async refreshFromStorage(storage: EntityStorage | WalletStorageManager, trx?: TrxToken): Promise<void>
    constructor(api?: TableProvenTxReq)
    historySince(since: Date): ProvenTxReqHistory
    historyPretty(since?: Date, _indent = 0): string
    prettyNote(note: ReqHistoryNote): string
    getHistorySummary(): ProvenTxReqHistorySummaryApi
    parseHistoryNote(note: ReqHistoryNote, summary?: ProvenTxReqHistorySummaryApi): string
    addNotifyTransactionId(id: number)
    addHistoryNote(note: ReqHistoryNote, noDupes?: boolean)
    async updateStorage(storage: EntityStorage, trx?: TrxToken)
    async updateStorageDynamicProperties(storage: WalletStorageManager | StorageProvider, trx?: TrxToken)
    async insertOrMerge(storage: EntityStorage, trx?: TrxToken): Promise<EntityProvenTxReq>
    get status()
    set status(v: ProvenTxReqStatus)
    get provenTxReqId()
    set provenTxReqId(v: number)
    get created_at()
    set created_at(v: Date)
    get updated_at()
    set updated_at(v: Date)
    get txid()
    set txid(v: string)
    get inputBEEF()
    set inputBEEF(v: number[] | undefined)
    get rawTx()
    set rawTx(v: number[])
    get attempts()
    set attempts(v: number)
    get provenTxId()
    set provenTxId(v: number | undefined)
    get notified()
    set notified(v: boolean)
    get batch()
    set batch(v: string | undefined)
    get wasBroadcast(): boolean
    set wasBroadcast(v: boolean)
    get rebroadcastAttempts(): number
    set rebroadcastAttempts(v: number)
    applyProofTimeout(maxRebroadcastAttempts = 0): {
        action: "invalid" | "rebroadcast";
        rebroadcastAttempts: number;
    }
    override get id()
    override set id(v: number)
    override get entityName(): string
    override get entityTable(): string
    override equals(ei: TableProvenTxReq, syncMap?: SyncMap | undefined): boolean
    static async mergeFind(storage: EntityStorage, userId: number, ei: TableProvenTxReq, syncMap: SyncMap, trx?: TrxToken): Promise<{
        found: boolean;
        eo: EntityProvenTxReq;
        eiId: number;
    }>
    mapNotifyTransactionIds(syncMap: SyncMap): void
    mergeNotifyTransactionIds(ei: TableProvenTxReq, syncMap?: SyncMap): void
    mergeHistory(ei: TableProvenTxReq, syncMap?: SyncMap, noDupes?: boolean): void
    static isTerminalStatus(status: ProvenTxReqStatus): boolean
    override async mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>
    override async mergeExisting(storage: EntityStorage, since: Date | undefined, ei: TableProvenTxReq, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>
}
```

See also: [EntityBase](./storage.md#class-entitybase), [EntityStorage](./storage.md#type-entitystorage), [ProvenTxReqHistory](./storage.md#interface-proventxreqhistory), [ProvenTxReqHistorySummaryApi](./storage.md#interface-proventxreqhistorysummaryapi), [ProvenTxReqNotify](./storage.md#interface-proventxreqnotify), [ProvenTxReqStatus](./client.md#type-proventxreqstatus), [ReqHistoryNote](./client.md#interface-reqhistorynote), [StorageProvider](./storage.md#class-storageprovider), [SyncMap](./storage.md#interface-syncmap), [TableProvenTxReq](./storage.md#interface-tableproventxreq), [TrxToken](./client.md#interface-trxtoken), [WalletStorageManager](./storage.md#class-walletstoragemanager)

###### Method addHistoryNote

Adds a note to history.
Notes with identical property values to an existing note are ignored.

```ts
addHistoryNote(note: ReqHistoryNote, noDupes?: boolean)
```
See also: [ReqHistoryNote](./client.md#interface-reqhistorynote)

Argument Details

+ **note**
  + Note to add
+ **noDupes**
  + if true, only newest note with same `what` value is retained.

###### Method equals

'convergent' equality must satisfy (A sync B) equals (B sync A)

```ts
override equals(ei: TableProvenTxReq, syncMap?: SyncMap | undefined): boolean
```
See also: [SyncMap](./storage.md#interface-syncmap), [TableProvenTxReq](./storage.md#interface-tableproventxreq)

###### Method historySince

Returns history to only what followed since date.

```ts
historySince(since: Date): ProvenTxReqHistory
```
See also: [ProvenTxReqHistory](./storage.md#interface-proventxreqhistory)

###### Method mergeExisting

When merging `ProvenTxReq`, care is taken to avoid short-cirtuiting notification: `status` must not transition to `completed` without
passing through `notifying`. Thus a full convergent merge passes through these sequence steps:
1. Remote storage completes before local storage.
2. The remotely completed req and ProvenTx sync to local storage.
3. The local storage transitions to `notifying`, after merging the remote attempts and history.
4. The local storage notifies, transitioning to `completed`.
5. Having been updated, the local req, but not ProvenTx sync to remote storage, but do not merge because the earlier `completed` wins.
6. Convergent equality is achieved (completing work - history and attempts are equal)

On terminal failure: `doubleSpend` trumps `invalid` as it contains more data.

```ts
override async mergeExisting(storage: EntityStorage, since: Date | undefined, ei: TableProvenTxReq, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>
```
See also: [EntityStorage](./storage.md#type-entitystorage), [SyncMap](./storage.md#interface-syncmap), [TableProvenTxReq](./storage.md#interface-tableproventxreq), [TrxToken](./client.md#interface-trxtoken)

###### Method updateStorage

Updates database record with current state of this EntityUser

```ts
async updateStorage(storage: EntityStorage, trx?: TrxToken)
```
See also: [EntityStorage](./storage.md#type-entitystorage), [TrxToken](./client.md#interface-trxtoken)

###### Method updateStorageDynamicProperties

Update storage with changes to non-static properties:
  updated_at
  provenTxId
  status
  history
  notify
  notified
  attempts
  batch

```ts
async updateStorageDynamicProperties(storage: WalletStorageManager | StorageProvider, trx?: TrxToken)
```
See also: [StorageProvider](./storage.md#class-storageprovider), [TrxToken](./client.md#interface-trxtoken), [WalletStorageManager](./storage.md#class-walletstoragemanager)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: EntitySyncState

```ts
export class EntitySyncState extends EntityBase<TableSyncState> {
    constructor(api?: TableSyncState)
    validateSyncMap(sm: SyncMap)
    static async fromStorage(storage: WalletStorageSync, userIdentityKey: string, remoteSettings: TableSettings): Promise<EntitySyncState>
    async updateStorage(storage: EntityStorage, notSyncMap?: boolean, trx?: TrxToken)
    override updateApi(notSyncMap?: boolean): void
    set created_at(v: Date)
    get created_at()
    set updated_at(v: Date)
    get updated_at()
    set userId(v: number)
    get userId()
    set storageIdentityKey(v: string)
    get storageIdentityKey()
    set storageName(v: string)
    get storageName()
    set init(v: boolean)
    get init()
    set refNum(v: string)
    get refNum()
    set status(v: SyncStatus)
    get status(): SyncStatus
    set when(v: Date | undefined)
    get when()
    set satoshis(v: number | undefined)
    get satoshis()
    get apiErrorLocal()
    get apiErrorOther()
    get apiSyncMap()
    override get id(): number
    set id(id: number)
    override get entityName(): string
    override get entityTable(): string
    static mergeIdMap(fromMap: Record<number, number>, toMap: Record<number, number>)
    mergeSyncMap(iSyncMap: SyncMap)
    errorLocal: SyncError | undefined;
    errorOther: SyncError | undefined;
    syncMap: SyncMap;
    override equals(ei: TableSyncState, syncMap?: SyncMap | undefined): boolean
    override async mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>
    override async mergeExisting(storage: EntityStorage, since: Date | undefined, ei: TableSyncState, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>
    makeRequestSyncChunkArgs(forIdentityKey: string, forStorageIdentityKey: string, maxRoughSize?: number, maxItems?: number): RequestSyncChunkArgs
    makeSyncCheckpoint(): SyncCheckpoint
    static syncChunkSummary(c: SyncChunk): string {
        let log = `SYNC CHUNK SUMMARY
  from storage: ${c.fromStorageIdentityKey}
  to storage: ${c.toStorageIdentityKey}
  for user: ${c.userIdentityKey}
`;
        if (c.user != null)
            log += `  USER activeStorage ${c.user.activeStorage}\n`;
        log += formatSyncSection("PROVEN_TXS", c.provenTxs, r => `${r.provenTxId} ${r.txid}`);
        log += formatSyncSection("PROVEN_TX_REQS", c.provenTxReqs, r => `${r.provenTxReqId} ${r.txid} ${r.status} ${r.provenTxId || ""}`);
        log += formatSyncSection("TRANSACTIONS", c.transactions, r => `${r.transactionId} ${r.txid} ${r.status} ${r.provenTxId || ""} sats:${r.satoshis}`);
        log += formatSyncSection("OUTPUTS", c.outputs, r => `${r.outputId} ${r.txid}.${r.vout} ${r.transactionId} ${r.spendable ? "spendable" : ""} sats:${r.satoshis}`);
        return log;
    }
    async processSyncChunk(writer: EntityStorage, args: RequestSyncChunkArgs, chunk: SyncChunk, trx?: TrxToken): Promise<{
        done: boolean;
        maxUpdated_at: Date | undefined;
        updates: number;
        inserts: number;
    }>
}
```

See also: [EntityBase](./storage.md#class-entitybase), [EntityStorage](./storage.md#type-entitystorage), [RequestSyncChunkArgs](./client.md#interface-requestsyncchunkargs), [SyncCheckpoint](./client.md#interface-synccheckpoint), [SyncChunk](./client.md#interface-syncchunk), [SyncError](./storage.md#interface-syncerror), [SyncMap](./storage.md#interface-syncmap), [SyncStatus](./client.md#type-syncstatus), [TableSettings](./storage.md#interface-tablesettings), [TableSyncState](./storage.md#interface-tablesyncstate), [TrxToken](./client.md#interface-trxtoken), [WalletStorageSync](./client.md#interface-walletstoragesync)

###### Method makeSyncCheckpoint

Return progress without the potentially large writer-local ID maps.

```ts
makeSyncCheckpoint(): SyncCheckpoint
```
See also: [SyncCheckpoint](./client.md#interface-synccheckpoint)

###### Method mergeSyncMap

Merge additions to the syncMap

```ts
mergeSyncMap(iSyncMap: SyncMap)
```
See also: [SyncMap](./storage.md#interface-syncmap)

###### Method updateStorage

Handles both insert and update based on id value: zero indicates insert.

```ts
async updateStorage(storage: EntityStorage, notSyncMap?: boolean, trx?: TrxToken)
```
See also: [EntityStorage](./storage.md#type-entitystorage), [TrxToken](./client.md#interface-trxtoken)

Argument Details

+ **notSyncMap**
  + if not new and true, excludes updating syncMap in storage.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: EntityTransaction

```ts
export class EntityTransaction extends EntityBase<TableTransaction> {
    getBsvTx(): BsvTransaction | undefined
    getBsvTxIns(): TransactionInput[]
    async getInputs(storage: EntityStorage, trx?: TrxToken): Promise<TableOutput[]>
    constructor(api?: TableTransaction)
    override updateApi(): void
    get transactionId()
    set transactionId(v: number)
    get created_at()
    set created_at(v: Date)
    get updated_at()
    set updated_at(v: Date)
    get version()
    set version(v: number | undefined)
    get lockTime()
    set lockTime(v: number | undefined)
    get isOutgoing()
    set isOutgoing(v: boolean)
    get status()
    set status(v: TransactionStatus)
    get userId()
    set userId(v: number)
    get provenTxId()
    set provenTxId(v: number | undefined)
    get satoshis()
    set satoshis(v: number)
    get txid()
    set txid(v: string | undefined)
    get reference()
    set reference(v: string)
    get inputBEEF()
    set inputBEEF(v: number[] | undefined)
    get description()
    set description(v: string)
    get rawTx()
    set rawTx(v: number[] | undefined)
    get noSendExpiryMode()
    set noSendExpiryMode(v)
    get noSendExpiryValue()
    set noSendExpiryValue(v)
    get noSendExpiryDeadline()
    set noSendExpiryDeadline(v)
    get noSendExpiryState()
    set noSendExpiryState(v)
    get noSendExpiryAnchorTxid()
    set noSendExpiryAnchorTxid(v)
    get noSendExpiryAnchorVout()
    set noSendExpiryAnchorVout(v)
    get noSendExpiryReleasedAt()
    set noSendExpiryReleasedAt(v)
    get noSendExpiryObservedAt()
    set noSendExpiryObservedAt(v)
    get noSendExpiryReclaimTxid()
    set noSendExpiryReclaimTxid(v)
    get noSendExpiryReclaimRawTx()
    set noSendExpiryReclaimRawTx(v)
    get noSendExpiryReclaimDerivationPrefix()
    set noSendExpiryReclaimDerivationPrefix(v)
    get noSendExpiryReclaimDerivationSuffix()
    set noSendExpiryReclaimDerivationSuffix(v)
    get noSendExpiryReclaimSatoshis()
    set noSendExpiryReclaimSatoshis(v)
    override get id(): number
    override set id(v: number)
    override get entityName(): string
    override get entityTable(): string
    override equals(ei: TableTransaction, syncMap?: SyncMap | undefined): boolean
    static async mergeFind(storage: EntityStorage, userId: number, ei: TableTransaction, syncMap: SyncMap, trx?: TrxToken): Promise<{
        found: boolean;
        eo: EntityTransaction;
        eiId: number;
    }>
    override async mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>
    override async mergeExisting(storage: EntityStorage, since: Date | undefined, ei: TableTransaction, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>
    async getProvenTx(storage: EntityStorage, trx?: TrxToken): Promise<EntityProvenTx | undefined>
}
```

See also: [EntityBase](./storage.md#class-entitybase), [EntityProvenTx](./storage.md#class-entityproventx), [EntityStorage](./storage.md#type-entitystorage), [SyncMap](./storage.md#interface-syncmap), [TableOutput](./storage.md#interface-tableoutput), [TableTransaction](./storage.md#interface-tabletransaction), [TransactionStatus](./client.md#type-transactionstatus), [TrxToken](./client.md#interface-trxtoken)

###### Method getBsvTxIns

```ts
getBsvTxIns(): TransactionInput[]
```

Returns

array of

###### Method getInputs

Returns an array of "known" inputs to this transaction which belong to the same userId.
Uses both spentBy and rawTx inputs (if available) to locate inputs from among user's outputs.
Not all transaction inputs correspond to prior storage outputs.

```ts
async getInputs(storage: EntityStorage, trx?: TrxToken): Promise<TableOutput[]>
```
See also: [EntityStorage](./storage.md#type-entitystorage), [TableOutput](./storage.md#interface-tableoutput), [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: EntityTxLabel

```ts
export class EntityTxLabel extends EntityBase<TableTxLabel> {
    constructor(api?: TableTxLabel)
    override updateApi(): void
    get txLabelId()
    set txLabelId(v: number)
    get created_at()
    set created_at(v: Date)
    get updated_at()
    set updated_at(v: Date)
    get label()
    set label(v: string)
    get userId()
    set userId(v: number)
    get isDeleted()
    set isDeleted(v: boolean)
    override get id(): number
    override set id(v: number)
    override get entityName(): string
    override get entityTable(): string
    override equals(ei: TableTxLabel, syncMap?: SyncMap): boolean
    static async mergeFind(storage: EntityStorage, userId: number, ei: TableTxLabel, syncMap: SyncMap, trx?: TrxToken): Promise<{
        found: boolean;
        eo: EntityTxLabel;
        eiId: number;
    }>
    override async mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>
    override async mergeExisting(storage: EntityStorage, since: Date | undefined, ei: TableTxLabel, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>
}
```

See also: [EntityBase](./storage.md#class-entitybase), [EntityStorage](./storage.md#type-entitystorage), [SyncMap](./storage.md#interface-syncmap), [TableTxLabel](./storage.md#interface-tabletxlabel), [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: EntityTxLabelMap

```ts
export class EntityTxLabelMap extends EntityBase<TableTxLabelMap> {
    constructor(api?: TableTxLabelMap)
    override updateApi(): void
    get txLabelId()
    set txLabelId(v: number)
    get transactionId()
    set transactionId(v: number)
    get created_at()
    set created_at(v: Date)
    get updated_at()
    set updated_at(v: Date)
    get isDeleted()
    set isDeleted(v: boolean)
    override get id(): number
    override get entityName(): string
    override get entityTable(): string
    override equals(ei: TableTxLabelMap, syncMap?: SyncMap | undefined): boolean
    static async mergeFind(storage: EntityStorage, userId: number, ei: TableTxLabelMap, syncMap: SyncMap, trx?: TrxToken): Promise<{
        found: boolean;
        eo: EntityTxLabelMap;
        eiId: number;
    }>
    override async mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>
    override async mergeExisting(storage: EntityStorage, since: Date | undefined, ei: TableTxLabelMap, syncMap: SyncMap, trx?: TrxToken): Promise<boolean>
}
```

See also: [EntityBase](./storage.md#class-entitybase), [EntityStorage](./storage.md#type-entitystorage), [SyncMap](./storage.md#interface-syncmap), [TableTxLabelMap](./storage.md#interface-tabletxlabelmap), [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: EntityUser

```ts
export class EntityUser extends EntityBase<TableUser> {
    constructor(api?: TableUser)
    override updateApi(): void
    get userId()
    set userId(v: number)
    get created_at()
    set created_at(v: Date)
    get updated_at()
    set updated_at(v: Date)
    get identityKey()
    set identityKey(v: string)
    get activeStorage()
    set activeStorage(v: string)
    override get id(): number
    override set id(v: number)
    override get entityName(): string
    override get entityTable(): string
    override equals(ei: TableUser, syncMap?: SyncMap | undefined): boolean
    static async mergeFind(storage: EntityStorage, userId: number, ei: TableUser, trx?: TrxToken): Promise<{
        found: boolean;
        eo: EntityUser;
        eiId: number;
    }>
    override async mergeNew(storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<void>
    override async mergeExisting(storage: EntityStorage, since: Date | undefined, ei: TableUser, syncMap?: SyncMap, trx?: TrxToken): Promise<boolean>
}
```

See also: [EntityBase](./storage.md#class-entitybase), [EntityStorage](./storage.md#type-entitystorage), [SyncMap](./storage.md#interface-syncmap), [TableUser](./storage.md#interface-tableuser), [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: GoChaintracksServiceClient

Client for go-chaintracks compatible HTTP services, including Arcade's
`/chaintracks/v2` surface. Unlike the legacy ChaintracksServiceClient, this
can subscribe to tip/reorg SSE streams and therefore drive Monitor block
processing without a local WhatsOnChain polling ingestor.

```ts
export class GoChaintracksServiceClient implements ChaintracksClientApi {
    constructor(public chain: Chain, serviceUrl: string, options: GoChaintracksServiceClientOptions = {})
    async currentHeight(): Promise<number>
    async isValidRootForHeight(root: string, height: number): Promise<boolean>
    async getChain(): Promise<Chain>
    async getInfo(): Promise<ChaintracksInfoApi>
    async getPresentHeight(): Promise<number>
    async getHeaders(height: number, count: number): Promise<string>
    async findChainTipHeader(): Promise<BlockHeader>
    async findChainTipHash(): Promise<string>
    async findHeaderForHeight(height: number): Promise<BlockHeader | undefined>
    async findHeaderForBlockHash(hash: string): Promise<BlockHeader | undefined>
    async addHeader(_header: BaseBlockHeader): Promise<void>
    async startListening(): Promise<void>
    async listening(): Promise<void>
    async isListening(): Promise<boolean>
    async isSynchronized(): Promise<boolean>
    async subscribeHeaders(listener: HeaderListener): Promise<string>
    async subscribeReorgs(listener: ReorgListener): Promise<string>
    async unsubscribe(subscriptionId: string): Promise<boolean>
}
```

See also: [BaseBlockHeader](./client.md#interface-baseblockheader), [BlockHeader](./client.md#interface-blockheader), [Chain](./client.md#type-chain), [ChaintracksClientApi](./services.md#interface-chaintracksclientapi), [ChaintracksInfoApi](./services.md#interface-chaintracksinfoapi), [GoChaintracksServiceClientOptions](./services.md#interface-gochaintracksserviceclientoptions), [HeaderListener](./services.md#type-headerlistener), [ReorgListener](./services.md#type-reorglistener)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: HeightRange

Represents a range of block heights.

Operations support integrating contiguous batches of headers,

```ts
export class HeightRange implements HeightRangeApi {
    constructor(public minHeight: number, public maxHeight: number)
    static readonly empty = new HeightRange(0, -1);
    get isEmpty()
    static from(headers: BlockHeader[]): HeightRange
    get length()
    toString(): string
    contains(range: HeightRange | number)
    intersect(range: HeightRange)
    union(range: HeightRange)
    subtract(range: HeightRange)
    above(range: HeightRange)
    copy(): HeightRange
}
```

See also: [BlockHeader](./client.md#interface-blockheader), [HeightRangeApi](./services.md#interface-heightrangeapi)

###### Property empty

All ranges where maxHeight is less than minHeight are considered empty.
The canonical empty range is (0, -1).

```ts
static readonly empty = new HeightRange(0, -1)
```
See also: [HeightRange](./services.md#class-heightrange)

###### Method above

If `range` is not empty and this is not empty, returns a new range minHeight
replaced by to range.maxHeight + 1.

Otherwise returns a copy of this range.

This returns the portion of this range that is strictly above `range`.

```ts
above(range: HeightRange)
```
See also: [HeightRange](./services.md#class-heightrange)

###### Method contains

```ts
contains(range: HeightRange | number)
```
See also: [HeightRange](./services.md#class-heightrange)

Returns

true if `range` is entirely within this range.

Argument Details

+ **range**
  + HeightRange or single height value.

###### Method copy

Return a copy of this range.

```ts
copy(): HeightRange
```
See also: [HeightRange](./services.md#class-heightrange)

###### Method from

```ts
static from(headers: BlockHeader[]): HeightRange
```
See also: [BlockHeader](./client.md#interface-blockheader), [HeightRange](./services.md#class-heightrange)

Returns

range of height values from the given headers, or the empty range if there are no headers.

Argument Details

+ **headers**
  + an array of objects with a non-negative integer `height` property.

###### Method intersect

Return the intersection with another height range.

Intersection with an empty range is always empty.

The result is always a single, possibly empty, range.

```ts
intersect(range: HeightRange)
```
See also: [HeightRange](./services.md#class-heightrange)

###### Method subtract

Returns `range` subtracted from this range.

Throws an error if the subtraction would create two disjoint ranges.

```ts
subtract(range: HeightRange)
```
See also: [HeightRange](./services.md#class-heightrange)

###### Method toString

function toString() { [native code] }

```ts
toString(): string
```

Returns

an easy to read string representation of the height range.

###### Method union

Return the union with another height range.

Only valid if the two ranges overlap or touch, or one is empty.

Throws an error if the union would create two disjoint ranges.

```ts
union(range: HeightRange)
```
See also: [HeightRange](./services.md#class-heightrange)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: InlineBulkFileDataValidator

Portable complete-object validator. Node services should normally inject
`NodeBulkFileDataValidator`; browser and mobile consumers retain this
dependency-free fallback.

```ts
export class InlineBulkFileDataValidator implements BulkFileDataValidatorApi {
    async validate(request: BulkFileDataValidationRequest): Promise<BulkFileDataValidationResult>
}
```

See also: [BulkFileDataValidationRequest](./services.md#interface-bulkfiledatavalidationrequest), [BulkFileDataValidationResult](./services.md#interface-bulkfiledatavalidationresult), [BulkFileDataValidatorApi](./services.md#interface-bulkfiledatavalidatorapi)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: MergeEntity

```ts
export class MergeEntity<API extends EntityTimeStamp, DE extends EntityBase<API>> {
    idMap: Record<number, number>;
    constructor(public stateArray: API[] | undefined, public find: (storage: EntityStorage, userId: number, ei: API, syncMap: SyncMap, trx?: TrxToken) => Promise<{
        found: boolean;
        eo: DE;
        eiId: number;
    }>, public esm: EntitySyncMap)
    updateSyncMap(map: Record<number, number>, inId: number, outId: number)
    async merge(since: Date | undefined, storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<{
        inserts: number;
        updates: number;
    }>
}
```

See also: [EntityBase](./storage.md#class-entitybase), [EntityStorage](./storage.md#type-entitystorage), [EntitySyncMap](./storage.md#interface-entitysyncmap), [EntityTimeStamp](./client.md#interface-entitytimestamp), [SyncMap](./storage.md#interface-syncmap), [TrxToken](./client.md#interface-trxtoken)

###### Method merge

```ts
async merge(since: Date | undefined, storage: EntityStorage, userId: number, syncMap: SyncMap, trx?: TrxToken): Promise<{
    inserts: number;
    updates: number;
}>
```
See also: [EntityStorage](./storage.md#type-entitystorage), [SyncMap](./storage.md#interface-syncmap), [TrxToken](./client.md#interface-trxtoken)

Argument Details

+ **since**
  + date of current sync chunk

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: MockChainMigrations

```ts
export class MockChainMigrations implements MigrationSource<string> {
    migrations: Record<string, Migration> = {};
    constructor()
    async getMigrations(): Promise<string[]>
    getMigrationName(migration: string): string
    async getMigration(migration: string): Promise<Migration>
    setupMigrations(): Record<string, Migration>
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: MockChainStorage

```ts
export class MockChainStorage {
    constructor(public knex: Knex)
    async migrate(): Promise<void>
    async insertTransaction(txid: string, rawTx: number[]): Promise<void>
    async getTransaction(txid: string): Promise<MockChainTransactionRow | undefined>
    async getUnminedTransactions(): Promise<MockChainTransactionRow[]>
    async setTransactionBlock(txid: string, height: number, index: number): Promise<void>
    async insertUtxo(txid: string, vout: number, lockingScript: number[], satoshis: number, scriptHash: string, isCoinbase = false, blockHeight: number | null = null): Promise<void>
    async getUtxo(txid: string, vout: number): Promise<MockChainUtxoRow | undefined>
    async getUtxosByScriptHash(scriptHash: string): Promise<MockChainUtxoRow[]>
    async markUtxoSpent(txid: string, vout: number, spentByTxid: string): Promise<void>
    async insertBlockHeader(header: MockChainBlockHeaderRow): Promise<void>
    async getBlockHeaderByHeight(height: number): Promise<BlockHeader | undefined>
    async getBlockHeaderByHash(hash: string): Promise<BlockHeader | undefined>
    async getChainTip(): Promise<BlockHeader | undefined>
    async getTransactionsInBlock(height: number): Promise<MockChainTransactionRow[]>
    async deleteBlockHeader(height: number): Promise<void>
    async deleteTransaction(txid: string): Promise<void>
    async deleteUtxosByTxid(txid: string): Promise<void>
    async setUtxoBlockHeight(txid: string, blockHeight: number | null): Promise<void>
    async unspendUtxo(txid: string, vout: number): Promise<void>
}
```

See also: [BlockHeader](./client.md#interface-blockheader), [MockChainBlockHeaderRow](./client.md#interface-mockchainblockheaderrow), [MockChainTransactionRow](./client.md#interface-mockchaintransactionrow), [MockChainUtxoRow](./client.md#interface-mockchainutxorow)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: MockChainTracker

```ts
export class MockChainTracker implements ChaintracksClientApi {
    constructor(public chain: Chain, public storage: MockChainStorage)
    async currentHeight(): Promise<number>
    async isValidRootForHeight(root: string, height: number): Promise<boolean>
    async getChain(): Promise<Chain>
    async getInfo(): Promise<ChaintracksInfoApi>
    async getPresentHeight(): Promise<number>
    async getHeaders(height: number, count: number): Promise<string>
    async findChainTipHeader(): Promise<BlockHeader>
    async findChainTipHash(): Promise<string>
    async findHeaderForHeight(height: number): Promise<BlockHeader | undefined>
    async findHeaderForBlockHash(hash: string): Promise<BlockHeader | undefined>
    async addHeader(_header: BaseBlockHeader): Promise<void>
    async startListening(): Promise<void>
    async listening(): Promise<void>
    async isListening(): Promise<boolean>
    async isSynchronized(): Promise<boolean>
    async subscribeHeaders(_listener: HeaderListener): Promise<string>
    async subscribeReorgs(_listener: ReorgListener): Promise<string>
    async unsubscribe(_subscriptionId: string): Promise<boolean>
}
```

See also: [BaseBlockHeader](./client.md#interface-baseblockheader), [BlockHeader](./client.md#interface-blockheader), [Chain](./client.md#type-chain), [ChaintracksClientApi](./services.md#interface-chaintracksclientapi), [ChaintracksInfoApi](./services.md#interface-chaintracksinfoapi), [HeaderListener](./services.md#type-headerlistener), [MockChainStorage](./client.md#class-mockchainstorage), [ReorgListener](./services.md#type-reorglistener)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: MockMiner

```ts
export class MockMiner {
    async mineBlock(storage: MockChainStorage): Promise<BlockHeader>
}
```

See also: [BlockHeader](./client.md#interface-blockheader), [MockChainStorage](./client.md#class-mockchainstorage)

###### Method mineBlock

Mine a new block containing all unmined transactions.
Returns the new block header.

```ts
async mineBlock(storage: MockChainStorage): Promise<BlockHeader>
```
See also: [BlockHeader](./client.md#interface-blockheader), [MockChainStorage](./client.md#class-mockchainstorage)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: MockServices

```ts
export class MockServices implements WalletServices {
    chain: Chain = "mock";
    storage: MockChainStorage;
    tracker: MockChainTracker;
    miner: MockMiner;
    constructor(public knex: Knex)
    async initialize(): Promise<void>
    async mineBlock(): Promise<BlockHeader>
    async postBeef(beef: Beef, txids: string[]): Promise<PostBeefResult[]>
    async reorg(startingHeight: number, numBlocks: number, txidMap?: Record<string, number>): Promise<ReorgResult>
    async getRawTx(txid: string): Promise<GetRawTxResult>
    async getMerklePath(txid: string): Promise<GetMerklePathResult>
    async getUtxoStatus(output: string, outputFormat?: GetUtxoStatusOutputFormat, outpoint?: string): Promise<GetUtxoStatusResult>
    async getStatusForTxids(txids: string[]): Promise<GetStatusForTxidsResult>
    async getScriptHashHistory(hash: string): Promise<GetScriptHashHistoryResult>
    async getChainTracker(): Promise<ChainTracker>
    async getHeaderForHeight(height: number): Promise<number[]>
    async getHeight(): Promise<number>
    async hashToHeader(hash: string): Promise<BlockHeader>
    hashOutputScript(script: string): string
    async isUtxo(output: TableOutput): Promise<boolean>
    async getBsvExchangeRate(): Promise<number>
    async getFiatExchangeRate(currency: FiatCurrencyCode, base: FiatCurrencyCode = "USD"): Promise<number>
    async getFiatExchangeRates(targetCurrencies: FiatCurrencyCode[]): Promise<FiatExchangeRates>
    async nLockTimeIsFinal(tx: string | number[] | BsvTransaction | number): Promise<boolean>
    async getBeefForTxid(txid: string): Promise<Beef>
    getServicesCallHistory(): ServicesCallHistory
}
```

See also: [BlockHeader](./client.md#interface-blockheader), [Chain](./client.md#type-chain), [FiatCurrencyCode](./client.md#type-fiatcurrencycode), [FiatExchangeRates](./client.md#interface-fiatexchangerates), [GetMerklePathResult](./client.md#interface-getmerklepathresult), [GetRawTxResult](./client.md#interface-getrawtxresult), [GetScriptHashHistoryResult](./client.md#interface-getscripthashhistoryresult), [GetStatusForTxidsResult](./client.md#interface-getstatusfortxidsresult), [GetUtxoStatusOutputFormat](./client.md#type-getutxostatusoutputformat), [GetUtxoStatusResult](./client.md#interface-getutxostatusresult), [MockChainStorage](./client.md#class-mockchainstorage), [MockChainTracker](./client.md#class-mockchaintracker), [MockMiner](./client.md#class-mockminer), [PostBeefResult](./client.md#interface-postbeefresult), [ReorgResult](./client.md#interface-reorgresult), [ServicesCallHistory](./client.md#interface-servicescallhistory), [TableOutput](./storage.md#interface-tableoutput), [WalletServices](./client.md#interface-walletservices), [getBeefForTxid](./services.md#function-getbeeffortxid)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: Monitor

Background task to make sure transactions are processed, transaction proofs are received and propagated,
and potentially that reorgs update proofs that were already received.

```ts
export class Monitor {
    static createDefaultWalletMonitorOptions(chain: Chain, storage: MonitorStorage, services?: Services, chaintracks?: ChaintracksClientApi, startupTaskMode: MonitorStartupTaskMode = "none"): MonitorOptions
    options: MonitorOptions;
    services: Services | WalletServices;
    chain: Chain;
    storage: MonitorStorage;
    chaintracks: ChaintracksClientApi;
    chaintracksWithEvents?: ChaintracksClientApi;
    reorgSubscriptionPromise?: Promise<string>;
    reorgInvalidationPromise: Promise<void> = Promise.resolve();
    headersSubscriptionPromise?: Promise<string>;
    onTransactionBroadcasted?: (broadcastResult: ReviewActionResult) => Promise<void>;
    onTransactionProven?: (txStatus: ProvenTransactionStatus) => Promise<void>;
    onTransactionStatusChanged?: (txid: string, newStatus: string) => Promise<void>;
    get ready(): Promise<void>
    constructor(options: MonitorOptions)
    async destroy(): Promise<void>
    static readonly oneSecond = 1000;
    static readonly oneMinute = 60 * Monitor.oneSecond;
    static readonly oneHour = 60 * Monitor.oneMinute;
    static readonly oneDay = 24 * Monitor.oneHour;
    static readonly oneWeek = 7 * Monitor.oneDay;
    _tasks: WalletMonitorTask[] = [];
    _otherTasks: WalletMonitorTask[] = [];
    _tasksRunning = false;
    defaultPurgeParams: TaskPurgeParams = {
        purgeSpent: false,
        purgeCompleted: false,
        purgeFailed: true,
        purgeSpentAge: 2 * Monitor.oneWeek,
        purgeCompletedAge: 2 * Monitor.oneWeek,
        purgeFailedAge: 5 * Monitor.oneDay
    };
    addAllTasksToOther(): void
    addDefaultTasks(): void
    addMultiUserTasks(): void
    addTask(task: WalletMonitorTask): void
    removeTask(name: string): void
    async runTask(name: string): Promise<string>
    async runOnce(): Promise<void>
    _runAsyncSetup: boolean = true;
    _tasksRunningPromise?: PromiseLike<void>;
    resolveCompletion: ((value: void | PromiseLike<void>) => void) | undefined = undefined;
    async startTasks(): Promise<void>
    async logEvent(event: string, details?: string): Promise<void>
    stopTasks(): void
    lastNewHeader: BlockHeader | undefined;
    lastNewHeaderWhen: Date | undefined;
    processNewBlockHeader(header: BlockHeader): void
    callOnBroadcastedTransaction(broadcastResult: ReviewActionResult): void
    callOnProvenTransaction(txStatus: ProvenTransactionStatus): void
    callOnTransactionStatusChanged(txid: string, newStatus: string): void
    async fetchSSEEvents(): Promise<number>
    deactivatedHeaders: DeactivedHeader[] = [];
    processReorg(depth: number, oldTip: BlockHeader, newTip: BlockHeader, deactivatedHeaders?: BlockHeader[]): void
    enqueueDeactivatedHeader(item: DeactivedHeader): void
    shiftDeactivatedHeader(): DeactivedHeader | undefined
    processHeader(header: BlockHeader): void
}
```

See also: [BlockHeader](./client.md#interface-blockheader), [Chain](./client.md#type-chain), [ChaintracksClientApi](./services.md#interface-chaintracksclientapi), [DeactivedHeader](./monitor.md#interface-deactivedheader), [MonitorOptions](./monitor.md#interface-monitoroptions), [MonitorStartupTaskMode](./monitor.md#type-monitorstartuptaskmode), [MonitorStorage](./monitor.md#type-monitorstorage), [ProvenTransactionStatus](./client.md#interface-proventransactionstatus), [ReviewActionResult](./client.md#interface-reviewactionresult), [Services](./services.md#class-services), [TaskPurgeParams](./monitor.md#interface-taskpurgeparams), [WalletMonitorTask](./monitor.md#class-walletmonitortask), [WalletServices](./client.md#interface-walletservices)

###### Property _otherTasks

_otherTasks can be run by runTask but not by scheduler.

```ts
_otherTasks: WalletMonitorTask[] = []
```
See also: [WalletMonitorTask](./monitor.md#class-walletmonitortask)

###### Property _tasks

_tasks are typically run by the scheduler but may also be run by runTask.

```ts
_tasks: WalletMonitorTask[] = []
```
See also: [WalletMonitorTask](./monitor.md#class-walletmonitortask)

###### Method addDefaultTasks

Default tasks with settings appropriate for a single user storage

```ts
addDefaultTasks(): void
```

###### Method addMultiUserTasks

Tasks appropriate for multi-user storage

```ts
addMultiUserTasks(): void
```

###### Method callOnBroadcastedTransaction

This is a function run from a TaskSendWaiting Monitor task.

This allows the user of wallet-toolbox to 'subscribe' for transaction broadcast updates.

```ts
callOnBroadcastedTransaction(broadcastResult: ReviewActionResult): void
```
See also: [ReviewActionResult](./client.md#interface-reviewactionresult)

###### Method callOnProvenTransaction

This is a function run from a TaskCheckForProofs Monitor task.

This allows the user of wallet-toolbox to 'subscribe' for transaction updates.

```ts
callOnProvenTransaction(txStatus: ProvenTransactionStatus): void
```
See also: [ProvenTransactionStatus](./client.md#interface-proventransactionstatus)

###### Method callOnTransactionStatusChanged

Called by TaskArcadeSSE when an SSE status event is received from Arcade.

```ts
callOnTransactionStatusChanged(txid: string, newStatus: string): void
```

###### Method fetchSSEEvents

Fetch pending transaction status events from Arcade on demand.
Call this on app open, balance refresh, transaction list view, etc.

```ts
async fetchSSEEvents(): Promise<number>
```

###### Method processHeader

Handler for new header events from Chaintracks.

To minimize reorg processing, new headers are aged before processing via TaskNewHeader.
Therefore this handler is intentionally a no-op.

```ts
processHeader(header: BlockHeader): void
```
See also: [BlockHeader](./client.md#interface-blockheader)

###### Method processNewBlockHeader

Process new chain header event received from Chaintracks

Kicks processing 'unconfirmed' and 'unmined' request processing.

```ts
processNewBlockHeader(header: BlockHeader): void
```
See also: [BlockHeader](./client.md#interface-blockheader)

###### Method processReorg

Process reorg event received from Chaintracks

Reorgs can move recent transactions to new blocks at new index positions.
Affected transaction proofs become invalid and must be updated.

It is possible for a transaction to become invalid.

Coinbase transactions always become invalid.

```ts
processReorg(depth: number, oldTip: BlockHeader, newTip: BlockHeader, deactivatedHeaders?: BlockHeader[]): void
```
See also: [BlockHeader](./client.md#interface-blockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: PreparedBeefCoordinator

Bounded, best-effort COOK worker. No foreground caller awaits this queue.
Dropped or failed work is safe because canonical storage remains the source
of truth and the normal BEEF builder remains the read-path fallback.

```ts
export class PreparedBeefCoordinator {
    constructor(private readonly storage: PreparedBeefStorage)
    enqueue(preparation: PreparedBeefPreparation): boolean
    startBackfill(): void
    async waitForIdle(): Promise<void>
    async stop(): Promise<void>
}
```

See also: [PreparedBeefPreparation](./storage.md#interface-preparedbeefpreparation), [PreparedBeefStorage](./storage.md#interface-preparedbeefstorage)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: PrivilegedKeyManager

PrivilegedKeyManager

This class manages a privileged (i.e., very sensitive) private key, obtained from
an external function (`keyGetter`), which might be backed by HSMs, secure enclaves,
or other secure storage. The manager retains the key in memory only for a limited
duration (`retentionPeriod`), uses XOR-based chunk-splitting obfuscation, and
includes decoy data to raise the difficulty of discovering the real key in memory.

IMPORTANT: While these measures raise the bar for attackers, JavaScript environments
do not provide perfect in-memory secrecy.

```ts
export class PrivilegedKeyManager implements ProtoWallet {
    constructor(keyGetter: (reason: string) => Promise<PrivateKey>, retentionPeriod = 120000)
    destroyKey(): void
    async getPublicKey(args: GetPublicKeyArgs): Promise<{
        publicKey: PubKeyHex;
    }>
    async revealCounterpartyKeyLinkage(args: RevealCounterpartyKeyLinkageArgs): Promise<RevealCounterpartyKeyLinkageResult>
    async revealSpecificKeyLinkage(args: RevealSpecificKeyLinkageArgs): Promise<RevealSpecificKeyLinkageResult>
    async encrypt(args: WalletEncryptArgs): Promise<WalletEncryptResult>
    async decrypt(args: WalletDecryptArgs): Promise<WalletDecryptResult>
    async createHmac(args: CreateHmacArgs): Promise<CreateHmacResult>
    async verifyHmac(args: VerifyHmacArgs): Promise<VerifyHmacResult>
    async createSignature(args: CreateSignatureArgs): Promise<CreateSignatureResult>
    async verifySignature(args: VerifySignatureArgs): Promise<VerifySignatureResult>
}
```

###### Constructor

```ts
constructor(keyGetter: (reason: string) => Promise<PrivateKey>, retentionPeriod = 120000)
```

Argument Details

+ **keyGetter**
  + Asynchronous function that retrieves the PrivateKey from a secure environment.
+ **retentionPeriod**
  + Time in milliseconds to retain the obfuscated key in memory before zeroizing.

###### Method destroyKey

Safely destroys the in-memory obfuscated key material by zeroizing
and deleting related fields. Also destroys some (but not all) decoy
properties to further confuse an attacker.

```ts
destroyKey(): void
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: ScriptTemplateBRC29

Simple Authenticated BSV P2PKH Payment Protocol
https://brc.dev/29

```ts
export class ScriptTemplateBRC29 implements ScriptTemplate {
    p2pkh: P2PKH;
    constructor(public params: ScriptTemplateParamsBRC29)
    getKeyID(): string
    getKeyDeriver(privKey: PrivateKey | HexString): KeyDeriverApi
    lock(lockerPrivKey: string, unlockerPubKey: string): LockingScript
    unlock(unlockerPrivKey: PrivateKey | HexString, lockerPubKey: PublicKey | string, sourceSatoshis?: number, lockingScript?: Script): ScriptTemplateUnlock
    unlockWithDerivedPrivateKey(derivedPrivateKey: PrivateKey, sourceSatoshis?: number, lockingScript?: Script): ScriptTemplateUnlock
    unlockLength = 108;
}
```

See also: [ScriptTemplateParamsBRC29](./client.md#interface-scripttemplateparamsbrc29), [ScriptTemplateUnlock](./client.md#interface-scripttemplateunlock)

###### Property unlockLength

P2PKH unlock estimateLength is a constant

```ts
unlockLength = 108
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: SdkWhatsOnChain

Represents a chain tracker based on What's On Chain .

```ts
export default class SdkWhatsOnChain implements ChainTracker {
    readonly network: string;
    readonly apiKey: string;
    protected readonly URL: string;
    protected readonly httpClient: HttpClient;
    protected readonly requestTimeoutMsecs: number;
    constructor(network: "main" | "test" | "stn" | "ttn" | "tstn" | "regtest" = "main", config: LocalWhatsOnChainConfig = {})
    get isAvailable(): boolean
    protected async request<T, Data = unknown>(url: string, options: HttpClientRequestOptions<Data>): Promise<HttpClientResponse<T>>
    async isValidRootForHeight(root: string, height: number): Promise<boolean>
    async currentHeight(): Promise<number>
    protected getHttpHeaders(): Record<string, string>
}
```

###### Constructor

Constructs an instance of the WhatsOnChain ChainTracker.
`tstn` and `regtest` have no WhatsOnChain service, so every request made for them is refused.

```ts
constructor(network: "main" | "test" | "stn" | "ttn" | "tstn" | "regtest" = "main", config: LocalWhatsOnChainConfig = {})
```

Argument Details

+ **network**
  + The BSV network to use when calling the WhatsOnChain API.
+ **config**
  + Configuration options for the WhatsOnChain ChainTracker.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: ServiceCollection

```ts
export class ServiceCollection<T> {
    services: Array<{
        name: string;
        service: T;
    }>;
    _index: number;
    readonly since: Date;
    _historyByProvider: Record<string, ProviderCallHistory> = {};
    constructor(public serviceName: string, services?: Array<{
        name: string;
        service: T;
    }>)
    add(s: {
        name: string;
        service: T;
    }): this
    remove(name: string): void
    get name(): string
    get service(): T
    getServiceToCall(i: number): ServiceToCall<T>
    get serviceToCall(): ServiceToCall<T>
    get allServicesToCall(): Array<ServiceToCall<T>>
    moveServiceToLast(stc: ServiceToCall<T>): void
    get allServices(): T[]
    get count(): number
    get index(): number
    reset(): void
    next(): number
    clone(): ServiceCollection<T>
    _addServiceCall(providerName: string, call: ServiceCall): ProviderCallHistory
    getDuration(since: Date | string): number
    addServiceCallSuccess(stc: ServiceToCall<T>, result?: string): void
    addServiceCallFailure(stc: ServiceToCall<T>, result?: string): void
    addServiceCallError(stc: ServiceToCall<T>, error: WalletError): void
    getServiceCallHistory(reset?: boolean): ServiceCallHistory
}
```

See also: [ProviderCallHistory](./client.md#interface-providercallhistory), [ServiceCall](./services.md#interface-servicecall), [ServiceCallHistory](./client.md#interface-servicecallhistory), [ServiceToCall](./services.md#interface-servicetocall), [WalletError](./client.md#class-walleterror)

###### Property since

Start of currentCounts interval. Initially instance construction time.

```ts
readonly since: Date
```

###### Method getServiceCallHistory

```ts
getServiceCallHistory(reset?: boolean): ServiceCallHistory
```
See also: [ServiceCallHistory](./client.md#interface-servicecallhistory)

Returns

A copy of current service call history

###### Method moveServiceToLast

Used to de-prioritize a service call by moving it to the end of the list.

```ts
moveServiceToLast(stc: ServiceToCall<T>): void
```
See also: [ServiceToCall](./services.md#interface-servicetocall)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: Services

```ts
export class Services implements WalletServices {
    static readonly getStatusForTxidsBatchLimit = 20;
    static createDefaultOptions(chain: Chain): WalletServicesOptions
    options: WalletServicesOptions;
    whatsonchain: WhatsOnChain;
    arcTaal: ARC;
    arcGorillaPool?: ARC;
    arcade?: Arcade;
    bitails?: Bitails;
    getMerklePathServices!: ServiceCollection<GetMerklePathService>;
    getRawTxServices!: ServiceCollection<GetRawTxService>;
    postBeefServices!: ServiceCollection<PostBeefService>;
    getUtxoStatusServices!: ServiceCollection<GetUtxoStatusService>;
    getStatusForTxidsServices!: ServiceCollection<GetStatusForTxidsService>;
    getScriptHashHistoryServices!: ServiceCollection<GetScriptHashHistoryService>;
    updateFiatExchangeRateServices!: ServiceCollection<UpdateFiatExchangeRateService>;
    chain: Chain;
    readonly telemetry: Telemetry;
    constructor(optionsOrChain: Chain | WalletServicesOptions)
    getServicesCallHistory(reset?: boolean): ServicesCallHistory
    async getChainTracker(): Promise<ChainTracker>
    async getBsvExchangeRate(): Promise<number>
    async getFiatExchangeRate(currency: FiatCurrencyCode, base?: FiatCurrencyCode): Promise<number>
    async getFiatExchangeRates(targetCurrencies: FiatCurrencyCode[]): Promise<FiatExchangeRates>
    get getProofsCount(): number
    get getRawTxsCount(): number
    get postBeefServicesCount(): number
    get getUtxoStatsCount(): number
    async getStatusForTxids(txids: string[], useNext?: boolean): Promise<GetStatusForTxidsResult>
    hashOutputScript(script: string): string
    async isUtxo(output: TableOutput): Promise<boolean>
    async getUtxoStatus(output: string, outputFormat?: GetUtxoStatusOutputFormat, outpoint?: string, useNext?: boolean, logger?: WalletLoggerInterface): Promise<GetUtxoStatusResult>
    async getScriptHashHistory(hash: string, useNext?: boolean, logger?: WalletLoggerInterface): Promise<GetScriptHashHistoryResult>
    postBeefMode: "PromiseAll" | "UntilSuccess" = "UntilSuccess";
    postBeefUntilSuccessSoftTimeoutMs = 5000;
    postBeefUntilSuccessSoftTimeoutPerKbMs = 50;
    postBeefUntilSuccessSoftTimeoutMaxMs = 30000;
    async postBeef(beef: Beef, txids: string[], logger?: WalletLoggerInterface): Promise<PostBeefResult[]>
    async getRawTx(txid: string, useNext?: boolean): Promise<GetRawTxResult>
    async invokeChaintracksWithRetry<R>(method: () => Promise<R>, operation: string = "unknown"): Promise<R>
    async getHeaderForHeight(height: number): Promise<number[]>
    async getHeight(): Promise<number>
    async hashToHeader(hash: string): Promise<BlockHeader>
    async getMerklePath(txid: string, useNext?: boolean, logger?: WalletLoggerInterface): Promise<GetMerklePathResult>
    async getValidatedMerklePath(txid: string, validate: (result: GetMerklePathResult) => Promise<void>): Promise<GetMerklePathResult>
    async updateFiatExchangeRates(targetCurrencies: FiatCurrencyCode[], updateMsecs?: number): Promise<FiatExchangeRates>
    async nLockTimeIsFinal(tx: string | number[] | BsvTransaction | number): Promise<boolean>
    async getBeefForTxid(txid: string): Promise<Beef>
}
```

See also: [ARC](./services.md#class-arc), [Arcade](./services.md#class-arcade), [Bitails](./services.md#class-bitails), [BlockHeader](./client.md#interface-blockheader), [Chain](./client.md#type-chain), [FiatCurrencyCode](./client.md#type-fiatcurrencycode), [FiatExchangeRates](./client.md#interface-fiatexchangerates), [GetMerklePathResult](./client.md#interface-getmerklepathresult), [GetMerklePathService](./client.md#type-getmerklepathservice), [GetRawTxResult](./client.md#interface-getrawtxresult), [GetRawTxService](./client.md#type-getrawtxservice), [GetScriptHashHistoryResult](./client.md#interface-getscripthashhistoryresult), [GetScriptHashHistoryService](./client.md#type-getscripthashhistoryservice), [GetStatusForTxidsResult](./client.md#interface-getstatusfortxidsresult), [GetStatusForTxidsService](./client.md#type-getstatusfortxidsservice), [GetUtxoStatusOutputFormat](./client.md#type-getutxostatusoutputformat), [GetUtxoStatusResult](./client.md#interface-getutxostatusresult), [GetUtxoStatusService](./client.md#type-getutxostatusservice), [PostBeefResult](./client.md#interface-postbeefresult), [PostBeefService](./client.md#type-postbeefservice), [ServiceCollection](./services.md#class-servicecollection), [ServicesCallHistory](./client.md#interface-servicescallhistory), [TableOutput](./storage.md#interface-tableoutput), [UpdateFiatExchangeRateService](./client.md#type-updatefiatexchangerateservice), [WalletServices](./client.md#interface-walletservices), [WalletServicesOptions](./client.md#interface-walletservicesoptions), [WhatsOnChain](./services.md#class-whatsonchain), [getBeefForTxid](./services.md#function-getbeeffortxid), [logger](./client.md#variable-logger)

###### Property arcade

Primary Arcade (bsv-blockchain/arcade) broadcaster, when `options.arcadeUrl` is set.

```ts
arcade?: Arcade
```
See also: [Arcade](./services.md#class-arcade)

###### Property postBeefUntilSuccessSoftTimeoutMaxMs

Upper bound for adaptive soft-timeout in `UntilSuccess` mode.

```ts
postBeefUntilSuccessSoftTimeoutMaxMs = 30000
```

###### Property postBeefUntilSuccessSoftTimeoutMs

Soft timeout used for each provider call in `UntilSuccess` mode.
This bounds request latency when a provider hangs before failover.

```ts
postBeefUntilSuccessSoftTimeoutMs = 5000
```

###### Property postBeefUntilSuccessSoftTimeoutPerKbMs

Additional soft-timeout budget (ms) per KiB of serialized Beef payload.
Helps avoid false timeout failover on legitimately large submissions.

```ts
postBeefUntilSuccessSoftTimeoutPerKbMs = 50
```

###### Method hashOutputScript

```ts
hashOutputScript(script: string): string
```

Returns

script hash in 'hashLE' format, which is the default.

Argument Details

+ **script**
  + Output script to be hashed for `getUtxoStatus` default `outputFormat`

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: SingleWriterMultiReaderLock

A reader-writer lock to manage concurrent access.
Allows multiple readers or one writer at a time.

```ts
export class SingleWriterMultiReaderLock {
    constructor(private readonly maxQueued = 4096)
    async withReadLock<T>(fn: () => Promise<T>): Promise<T>
    async withWriteLock<T>(fn: () => Promise<T>): Promise<T>
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: StaleSyncProofError

Identifies a structurally valid proof which needs current-chain reconciliation.

```ts
export class StaleSyncProofError extends WERR_INVALID_PARAMETER {
    constructor()
}
```

See also: [WERR_INVALID_PARAMETER](./client.md#class-werr_invalid_parameter)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: StorageProvider

```ts
export abstract class StorageProvider extends StorageReaderWriter implements WalletStorageProvider {
    isDirty = false;
    _services?: WalletServices;
    feeModel: StorageFeeModel;
    commissionSatoshis: number;
    commissionPubKeyHex?: PubKeyHex;
    maxRecursionDepth?: number;
    readonly actionBatchMaxReservedOutputs: number;
    readonly managedChangePolicy: ManagedChangePolicy;
    readonly scriptVerifier?: SpendVerifierInterface;
    static defaultOptions(): {
        feeModel: StorageFeeModel;
        commissionSatoshis: number;
        commissionPubKeyHex: undefined;
        actionBatchMaxReservedOutputs: number;
        managedChangePolicy: ManagedChangePolicy;
    }
    static createStorageBaseOptions(chain: Chain): StorageProviderOptions
    constructor(options: StorageProviderOptions)
    abstract reviewStatus(args: {
        agedLimit: Date;
        trx?: TrxToken;
    }): Promise<{
        log: string;
    }>;
    abstract purgeData(params: PurgeParams, trx?: TrxToken): Promise<PurgeResults>;
    abstract allocateChangeInput(userId: number, basketId: number, targetSatoshis: number, exactSatoshis: number | undefined, excludeSending: boolean, transactionId: number): Promise<TableOutput | undefined>;
    async markChangeInputsSpent(outputIds: number[], transactionId: number, trx: TrxToken): Promise<number>
    async insertOutputs(outputs: TableOutput[], trx?: TrxToken): Promise<void>
    async findAvailableManagedChangeInputs(userId: number, basketId: number, excludeSending: boolean, trx?: TrxToken): Promise<TableOutput[]>
    async findAvailableManagedChangeInputCandidates(userId: number, basketId: number, excludeSending: boolean, trx?: TrxToken): Promise<ManagedChangeInputCandidate[]>
    async findTransactionStatusesByIds(userId: number, transactionIds: number[], trx?: TrxToken): Promise<Map<number, TransactionStatus>>
    async findFundingOutputsForUpdate(userId: number, outputIds: number[], statuses: TransactionStatus[], trx: TrxToken): Promise<Record<number, TableOutput>>
    abstract getProvenOrRawTx(txid: string, trx?: TrxToken): Promise<ProvenOrRawTx>;
    async getProvenOrRawTxs(txids: string[], trx?: TrxToken): Promise<Map<string, ProvenOrRawTx>>
    abstract getRawTxOfKnownValidTransaction(txid?: string, offset?: number, length?: number, trx?: TrxToken): Promise<number[] | undefined>;
    abstract getLabelsForTransactionId(transactionId?: number, trx?: TrxToken): Promise<TableTxLabel[]>;
    abstract getTagsForOutputId(outputId: number, trx?: TrxToken): Promise<TableOutputTag[]>;
    abstract listActions(auth: AuthId, args: Validation.ValidListActionsArgs): Promise<ListActionsResult>;
    abstract listOutputs(auth: AuthId, args: Validation.ValidListOutputsArgs): Promise<ListOutputsResult>;
    abstract countChangeInputs(userId: number, basketId: number, excludeSending: boolean): Promise<number>;
    async insertActionBatch(_batch: TableActionBatch, _trx?: TrxToken): Promise<number>
    async findActionBatch(_userId: number, _batchId: string, _trx?: TrxToken): Promise<TableActionBatch | undefined>
    async findActionBatchForUpdate(userId: number, batchId: string, trx: TrxToken): Promise<TableActionBatch | undefined>
    async findExpiredActionBatches(_now: Date, _trx?: TrxToken): Promise<TableActionBatch[]>
    async updateActionBatch(_actionBatchId: number, _update: Partial<TableActionBatch>, _trx?: TrxToken): Promise<number>
    async deleteActionBatch(_actionBatchId: number, _trx?: TrxToken): Promise<void>
    async reserveActionBatchOutputs(_reservations: TableActionBatchOutput[], _trx?: TrxToken): Promise<void>
    async findActionBatchOutputIds(_actionBatchId: number, _trx?: TrxToken): Promise<number[]>
    async findReservedActionBatchOutputIds(_outputIds: number[], _trx?: TrxToken): Promise<number[]>
    async deleteActionBatchOutputReservations(_actionBatchId: number, _trx?: TrxToken): Promise<void>
    async putActionBatchBlobRecord(_blob: TableActionBatchBlob, _trx?: TrxToken): Promise<void>
    async findActionBatchBlobRecord(_actionBatchId: number, _digest: string, _trx?: TrxToken): Promise<TableActionBatchBlob | undefined>
    async findActionBatchBlobRecords(actionBatchId: number, digests: string[], trx?: TrxToken): Promise<TableActionBatchBlob[]>
    async putActionBatchBlobRecords(blobs: TableActionBatchBlob[], trx?: TrxToken): Promise<void>
    async deleteActionBatchBlobRecords(_actionBatchId: number, _trx?: TrxToken): Promise<void>
    async getCapabilities(): Promise<StorageCapabilities>
    async findProvenTxReqsAuth(auth: AuthId, args: FindProvenTxReqsArgs): Promise<TableProvenTxReq[]>
    async prepareNoSendExpiry(auth: AuthId, args: Validation.ValidCreateActionArgs): Promise<StoragePrepareNoSendExpiryResult>
    async activateNoSendExpiry(auth: AuthId, args: StorageActivateNoSendExpiryArgs): Promise<StorageActivateNoSendExpiryResult>
    async armNoSendExpiry(auth: AuthId, args: StorageArmNoSendExpiryArgs): Promise<void>
    protected supportsNoSendExpiryPersistence(): boolean
    protected supportsActionBatchPersistence(): boolean
    protected requiresActionBatchCleanupBeforeCreateAction(): boolean
    async beginActionBatch(auth: AuthId, args: BeginActionBatchArgs): Promise<BeginActionBatchResult>
    async extendActionBatch(auth: AuthId, args: ExtendActionBatchArgs): Promise<ExtendActionBatchResult>
    async renewActionBatch(auth: AuthId, batchId: string): Promise<RenewActionBatchResult>
    async resumeActionBatch(auth: AuthId, args: ResumeActionBatchArgs): Promise<ResumeActionBatchResult>
    async prepareActionBatchCommit(auth: AuthId, manifest: ActionBatchManifest): Promise<PrepareActionBatchCommitResult>
    async putActionBatchBlob(auth: AuthId, args: PutActionBatchBlobArgs): Promise<void>
    async putActionBatchPack(auth: AuthId, args: PutActionBatchPackArgs): Promise<void>
    async commitActionBatch(auth: AuthId, manifest: ActionBatchManifest): Promise<CommitActionBatchResult>
    async commitActionBatchByDigest(auth: AuthId, args: CommitActionBatchByDigestArgs): Promise<CommitActionBatchResult>
    async abortActionBatch(auth: AuthId, batchId: string): Promise<AbortActionBatchResult>
    async findOutputsByIds(outputIds: number[], trx?: TrxToken): Promise<Record<number, TableOutput>>
    async findStaleMerkleRoots(args: FindStaleMerkleRootsArgs): Promise<string[]>
    async findOutputsByOutpoints(userId: number, outpoints: Array<{
        txid: string;
        vout: number;
    }>, trx?: TrxToken): Promise<Record<string, TableOutput>>
    async findOutputsByOutpointsForUpdate(userId: number, outpoints: Array<{
        txid: string;
        vout: number;
    }>, trx: TrxToken, _noScript = false): Promise<Record<string, TableOutput>>
    async findOrInsertOutputBasketsBulk(userId: number, names: string[], trx?: TrxToken): Promise<Record<string, TableOutputBasket>>
    async findOrInsertOutputTagsBulk(userId: number, tags: string[], trx?: TrxToken): Promise<Record<string, TableOutputTag>>
    async findOrInsertTxLabelsBulk(userId: number, labels: string[], trx?: TrxToken): Promise<Record<string, TableTxLabel>>
    async sumSpendableSatoshisInBasket(userId: number, basketId: number, excludeSending: boolean, trx?: TrxToken): Promise<number>
    abstract findCertificatesAuth(auth: AuthId, args: FindCertificatesArgs): Promise<TableCertificateX[]>;
    abstract findOutputBasketsAuth(auth: AuthId, args: FindOutputBasketsArgs): Promise<TableOutputBasket[]>;
    abstract findOutputsAuth(auth: AuthId, args: FindOutputsArgs): Promise<TableOutput[]>;
    abstract insertCertificateAuth(auth: AuthId, certificate: TableCertificateX): Promise<number>;
    abstract adminStats(adminIdentityKey: string): Promise<AdminStatsResult>;
    async recentlyActiveUsers(limit = 50, trx?: TrxToken): Promise<TableUser[]>
    override isStorageProvider(): boolean
    setServices(v: WalletServices): void
    getServices(): WalletServices
    async abortAction(auth: AuthId, args: AbortActionArgs): Promise<AbortActionResult>
    async internalizeAction(auth: AuthId, args: InternalizeActionArgs): Promise<StorageInternalizeActionResult>
    async getReqsAndBeefToShareWithWorld(txids: string[], knownTxids: string[], trx?: TrxToken): Promise<GetReqsAndBeefResult>
    async mergeReqToBeefToShareExternally(req: TableProvenTxReq, mergeToBeef: Beef, knownTxids: string[], trx?: TrxToken): Promise<void>
    async getProvenOrReq(txid: string, newReq?: TableProvenTxReq, trx?: TrxToken): Promise<StorageProvenOrReq>
    async updateTransactionsStatus(transactionIds: number[], status: TransactionStatus, trx?: TrxToken): Promise<void>
    async updateTransactionStatus(status: TransactionStatus, transactionId?: number, userId?: number, reference?: string, trx?: TrxToken): Promise<void>
    async createAction(auth: AuthId, args: Validation.ValidCreateActionArgs): Promise<StorageCreateActionResult>
    async processAction(auth: AuthId, args: StorageProcessActionArgs): Promise<StorageProcessActionResults>
    async attemptToPostReqsToNetwork(reqs: EntityProvenTxReq[], trx?: TrxToken, logger?: WalletLoggerInterface): Promise<PostReqsToNetworkResult>
    async listCertificates(auth: AuthId, args: Validation.ValidListCertificatesArgs): Promise<ListCertificatesResult>
    async verifyKnownValidTransaction(txid: string, trx?: TrxToken): Promise<boolean>
    async getValidBeefForKnownTxid(txid: string, mergeToBeef?: Beef, trustSelf?: TrustSelf, knownTxids?: string[], trx?: TrxToken, requiredLevels?: number): Promise<Beef>
    async getValidBeefForTxid(...[txid, mergeToBeef, trustSelf, knownTxids, trx, requiredLevels, chainTracker, skipInvalidProofs]: [
        txid: string,
        mergeToBeef?: Beef,
        trustSelf?: TrustSelf,
        knownTxids?: string[],
        trx?: TrxToken,
        requiredLevels?: number,
        chainTracker?: ChainTracker,
        skipInvalidProofs?: boolean
    ]): Promise<Beef | undefined>
    async getBeefForTransaction(txid: string, options: StorageGetBeefOptions): Promise<Beef>
    async getBeefForTransactions(txids: string[], options: StorageGetBeefOptions): Promise<Beef>
    async findMonitorEventById(id: number, trx?: TrxToken): Promise<TableMonitorEvent | undefined>
    async relinquishCertificate(auth: AuthId, args: RelinquishCertificateArgs): Promise<number>
    async relinquishOutput(auth: AuthId, args: RelinquishOutputArgs): Promise<number>
    async processSyncChunk(args: RequestSyncChunkArgs, chunk: SyncChunk): Promise<ProcessSyncChunkResult>
    async updateProvenTxReqWithNewProvenTx(args: UpdateProvenTxReqWithNewProvenTxArgs, validatedCandidate?: TableProvenTx): Promise<UpdateProvenTxReqWithNewProvenTxResult>
    async updateProvenTxReqWithNewProvenTxAuth(auth: AuthId, args: UpdateProvenTxReqWithNewProvenTxArgs): Promise<UpdateProvenTxReqWithNewProvenTxResult>
    async reconcileCompletedProvenTxReqs(): Promise<{
        log: string;
    }>
    async unfailTransactionsForProof(req: EntityProvenTxReq, indent = 0, requestUpdate?: Pick<TableProvenTxReqDynamics, "status" | "attempts">): Promise<string>
    async confirmSpendableOutputs(): Promise<{
        invalidSpendableOutputs: TableOutput[];
    }>
    async updateProvenTxReqDynamics(id: number, update: Partial<TableProvenTxReqDynamics>, trx?: TrxToken): Promise<number>
    async extendOutput(o: TableOutput, includeBasket = false, includeTags = false, trx?: TrxToken): Promise<TableOutputX>
    async validateOutputScript(o: TableOutput, trx?: TrxToken): Promise<void>
}
```

See also: [AbortActionBatchResult](./client.md#interface-abortactionbatchresult), [ActionBatchManifest](./client.md#interface-actionbatchmanifest), [AdminStatsResult](./storage.md#interface-adminstatsresult), [AuthId](./client.md#interface-authid), [BeginActionBatchArgs](./client.md#interface-beginactionbatchargs), [BeginActionBatchResult](./client.md#interface-beginactionbatchresult), [Chain](./client.md#type-chain), [CommitActionBatchByDigestArgs](./client.md#interface-commitactionbatchbydigestargs), [CommitActionBatchResult](./client.md#interface-commitactionbatchresult), [EntityProvenTxReq](./storage.md#class-entityproventxreq), [ExtendActionBatchArgs](./client.md#interface-extendactionbatchargs), [ExtendActionBatchResult](./client.md#interface-extendactionbatchresult), [FindCertificatesArgs](./client.md#interface-findcertificatesargs), [FindOutputBasketsArgs](./client.md#interface-findoutputbasketsargs), [FindOutputsArgs](./client.md#interface-findoutputsargs), [FindProvenTxReqsArgs](./client.md#interface-findproventxreqsargs), [FindStaleMerkleRootsArgs](./client.md#interface-findstalemerklerootsargs), [GetReqsAndBeefResult](./storage.md#interface-getreqsandbeefresult), [ManagedChangeInputCandidate](./storage.md#type-managedchangeinputcandidate), [ManagedChangePolicy](./storage.md#interface-managedchangepolicy), [PostReqsToNetworkResult](./storage.md#interface-postreqstonetworkresult), [PrepareActionBatchCommitResult](./client.md#interface-prepareactionbatchcommitresult), [ProcessSyncChunkResult](./client.md#interface-processsyncchunkresult), [ProvenOrRawTx](./client.md#interface-provenorrawtx), [PurgeParams](./client.md#interface-purgeparams), [PurgeResults](./client.md#interface-purgeresults), [PutActionBatchBlobArgs](./client.md#interface-putactionbatchblobargs), [PutActionBatchPackArgs](./client.md#interface-putactionbatchpackargs), [RenewActionBatchResult](./client.md#interface-renewactionbatchresult), [RequestSyncChunkArgs](./client.md#interface-requestsyncchunkargs), [ResumeActionBatchArgs](./client.md#interface-resumeactionbatchargs), [ResumeActionBatchResult](./client.md#interface-resumeactionbatchresult), [StorageActivateNoSendExpiryArgs](./client.md#interface-storageactivatenosendexpiryargs), [StorageActivateNoSendExpiryResult](./client.md#interface-storageactivatenosendexpiryresult), [StorageArmNoSendExpiryArgs](./client.md#interface-storagearmnosendexpiryargs), [StorageCapabilities](./client.md#interface-storagecapabilities), [StorageCreateActionResult](./client.md#interface-storagecreateactionresult), [StorageFeeModel](./client.md#interface-storagefeemodel), [StorageGetBeefOptions](./client.md#interface-storagegetbeefoptions), [StorageInternalizeActionResult](./client.md#interface-storageinternalizeactionresult), [StoragePrepareNoSendExpiryResult](./client.md#interface-storagepreparenosendexpiryresult), [StorageProcessActionArgs](./client.md#interface-storageprocessactionargs), [StorageProcessActionResults](./client.md#interface-storageprocessactionresults), [StorageProvenOrReq](./client.md#interface-storageprovenorreq), [StorageProviderOptions](./storage.md#interface-storageprovideroptions), [StorageReaderWriter](./storage.md#class-storagereaderwriter), [SyncChunk](./client.md#interface-syncchunk), [TableActionBatch](./storage.md#interface-tableactionbatch), [TableActionBatchBlob](./storage.md#interface-tableactionbatchblob), [TableActionBatchOutput](./storage.md#interface-tableactionbatchoutput), [TableCertificateX](./storage.md#interface-tablecertificatex), [TableMonitorEvent](./storage.md#interface-tablemonitorevent), [TableOutput](./storage.md#interface-tableoutput), [TableOutputBasket](./storage.md#interface-tableoutputbasket), [TableOutputTag](./storage.md#interface-tableoutputtag), [TableOutputX](./storage.md#interface-tableoutputx), [TableProvenTx](./storage.md#interface-tableproventx), [TableProvenTxReq](./storage.md#interface-tableproventxreq), [TableProvenTxReqDynamics](./storage.md#interface-tableproventxreqdynamics), [TableTxLabel](./storage.md#interface-tabletxlabel), [TableUser](./storage.md#interface-tableuser), [TransactionStatus](./client.md#type-transactionstatus), [TrxToken](./client.md#interface-trxtoken), [UpdateProvenTxReqWithNewProvenTxArgs](./client.md#interface-updateproventxreqwithnewproventxargs), [UpdateProvenTxReqWithNewProvenTxResult](./client.md#interface-updateproventxreqwithnewproventxresult), [WalletServices](./client.md#interface-walletservices), [WalletStorageProvider](./client.md#interface-walletstorageprovider), [abortActionBatch](./storage.md#function-abortactionbatch), [activateNoSendExpiry](./storage.md#function-activatenosendexpiry), [armNoSendExpiry](./storage.md#function-armnosendexpiry), [attemptToPostReqsToNetwork](./storage.md#function-attempttopostreqstonetwork), [beginActionBatch](./storage.md#function-beginactionbatch), [commitActionBatch](./storage.md#function-commitactionbatch), [commitActionBatchByDigest](./storage.md#function-commitactionbatchbydigest), [createAction](./storage.md#function-createaction), [extendActionBatch](./storage.md#function-extendactionbatch), [getBeefForTransaction](./storage.md#function-getbeeffortransaction), [getBeefForTransactions](./storage.md#function-getbeeffortransactions), [internalizeAction](./storage.md#function-internalizeaction), [listActions](./storage.md#function-listactions), [listCertificates](./storage.md#function-listcertificates), [listOutputs](./storage.md#function-listoutputs), [logger](./client.md#variable-logger), [prepareActionBatchCommit](./storage.md#function-prepareactionbatchcommit), [prepareNoSendExpiry](./storage.md#function-preparenosendexpiry), [processAction](./storage.md#function-processaction), [purgeData](./storage.md#function-purgedata), [putActionBatchBlob](./storage.md#function-putactionbatchblob), [putActionBatchPack](./storage.md#function-putactionbatchpack), [renewActionBatch](./storage.md#function-renewactionbatch), [resumeActionBatch](./storage.md#function-resumeactionbatch), [reviewStatus](./storage.md#function-reviewstatus)

###### Method confirmSpendableOutputs

For each spendable output in the 'default' basket of the authenticated user,
verify that the output script, satoshis, vout and txid match that of an output
still in the mempool of at least one service provider.

```ts
async confirmSpendableOutputs(): Promise<{
    invalidSpendableOutputs: TableOutput[];
}>
```
See also: [TableOutput](./storage.md#interface-tableoutput)

Returns

object with invalidSpendableOutputs array. A good result is an empty array.

###### Method findAvailableManagedChangeInputCandidates

Read only the fields needed by the in-memory funding planner.

```ts
async findAvailableManagedChangeInputCandidates(userId: number, basketId: number, excludeSending: boolean, trx?: TrxToken): Promise<ManagedChangeInputCandidate[]>
```
See also: [ManagedChangeInputCandidate](./storage.md#type-managedchangeinputcandidate), [TrxToken](./client.md#interface-trxtoken)

###### Method findAvailableManagedChangeInputs

Return unreserved wallet-managed outputs eligible for automatic funding.

```ts
async findAvailableManagedChangeInputs(userId: number, basketId: number, excludeSending: boolean, trx?: TrxToken): Promise<TableOutput[]>
```
See also: [TableOutput](./storage.md#interface-tableoutput), [TrxToken](./client.md#interface-trxtoken)

###### Method findFundingOutputsForUpdate

Lock and return the selected funding rows whose source transaction and
action-batch reservation state still permit allocation.

```ts
async findFundingOutputsForUpdate(userId: number, outputIds: number[], statuses: TransactionStatus[], trx: TrxToken): Promise<Record<number, TableOutput>>
```
See also: [TableOutput](./storage.md#interface-tableoutput), [TransactionStatus](./client.md#type-transactionstatus), [TrxToken](./client.md#interface-trxtoken)

###### Method findProvenTxReqsAuth

Restrict remotely requested proof work to transactions tracked by the
authenticated wallet. ProvenTxReq rows are globally deduplicated, so their
own schema has no userId column and must be authorized through transactions.

```ts
async findProvenTxReqsAuth(auth: AuthId, args: FindProvenTxReqsArgs): Promise<TableProvenTxReq[]>
```
See also: [AuthId](./client.md#interface-authid), [FindProvenTxReqsArgs](./client.md#interface-findproventxreqsargs), [TableProvenTxReq](./storage.md#interface-tableproventxreq)

###### Method findTransactionStatusesByIds

Read the current status of a set of source transactions without loading raw transaction bytes.

```ts
async findTransactionStatusesByIds(userId: number, transactionIds: number[], trx?: TrxToken): Promise<Map<number, TransactionStatus>>
```
See also: [TransactionStatus](./client.md#type-transactionstatus), [TrxToken](./client.md#interface-trxtoken)

###### Method getProvenOrRawTxs

Resolve several transaction proofs in one storage operation when the
backend supports it. The default preserves compatibility for custom
providers; SQL and IndexedDB providers override this hot path.

```ts
async getProvenOrRawTxs(txids: string[], trx?: TrxToken): Promise<Map<string, ProvenOrRawTx>>
```
See also: [ProvenOrRawTx](./client.md#interface-provenorrawtx), [TrxToken](./client.md#interface-trxtoken)

###### Method getReqsAndBeefToShareWithWorld

Given an array of transaction txids with current ProvenTxReq ready-to-share status,
lookup their ProvenTxReqApi req records.
For the txids with reqs and status still ready to send construct a single merged beef.

```ts
async getReqsAndBeefToShareWithWorld(txids: string[], knownTxids: string[], trx?: TrxToken): Promise<GetReqsAndBeefResult>
```
See also: [GetReqsAndBeefResult](./storage.md#interface-getreqsandbeefresult), [TrxToken](./client.md#interface-trxtoken)

###### Method getValidBeefForKnownTxid

Pulls data from storage to build a valid beef for a txid.

Optionally merges the data into an existing beef.
Optionally requires a minimum number of proof levels.

```ts
async getValidBeefForKnownTxid(txid: string, mergeToBeef?: Beef, trustSelf?: TrustSelf, knownTxids?: string[], trx?: TrxToken, requiredLevels?: number): Promise<Beef>
```
See also: [TrxToken](./client.md#interface-trxtoken)

###### Method insertOutputs

Insert outputs that do not need their generated ids returned to the
caller. Engines with a multi-row insert override this common-path helper;
the fallback preserves existing storage implementations unchanged.

```ts
async insertOutputs(outputs: TableOutput[], trx?: TrxToken): Promise<void>
```
See also: [TableOutput](./storage.md#interface-tableoutput), [TrxToken](./client.md#interface-trxtoken)

###### Method markChangeInputsSpent

Mark a planned set of change inputs spent within the caller's transaction.

```ts
async markChangeInputsSpent(outputIds: number[], transactionId: number, trx: TrxToken): Promise<number>
```
See also: [TrxToken](./client.md#interface-trxtoken)

###### Method reconcileCompletedProvenTxReqs

Reconcile completed proof requests whose transaction fan-out previously
failed or whose durable notification state drifted.

This is called by TaskReviewStatus so a completed request with
`notified = false` is retried and can become eligible for normal purge.

```ts
async reconcileCompletedProvenTxReqs(): Promise<{
    log: string;
}>
```

###### Method requiresActionBatchCleanupBeforeCreateAction

Custom providers may require physical expiry cleanup before reservations are queried.

```ts
protected requiresActionBatchCleanupBeforeCreateAction(): boolean
```

###### Method unfailTransactionsForProof

Restore every failed local copy of a transaction before proof completion.
Also heals the request's notification set from the authoritative txid
lookup so TaskUnFail cannot omit a local copy after notification drift.

```ts
async unfailTransactionsForProof(req: EntityProvenTxReq, indent = 0, requestUpdate?: Pick<TableProvenTxReqDynamics, "status" | "attempts">): Promise<string>
```
See also: [EntityProvenTxReq](./storage.md#class-entityproventxreq), [TableProvenTxReqDynamics](./storage.md#interface-tableproventxreqdynamics)

###### Method updateProvenTxReqWithNewProvenTx

Handles storage changes when a valid MerklePath and mined block header are found for a ProvenTxReq txid.

Performs the following storage updates (typically):
1. Lookup the exising `ProvenTxReq` record for its rawTx
2. Insert a new ProvenTx record using properties from `args` and rawTx, yielding a new provenTxId
3. Update ProvenTxReq record with status 'completed' and new provenTxId value (and history of status changed)
4. Unpack notify transactionIds from req and update each transaction's status to 'completed', provenTxId value.
5. Update ProvenTxReq history again to record that transactions have been notified.
6. Return results...

Alterations of "typically" to handle:

```ts
async updateProvenTxReqWithNewProvenTx(args: UpdateProvenTxReqWithNewProvenTxArgs, validatedCandidate?: TableProvenTx): Promise<UpdateProvenTxReqWithNewProvenTxResult>
```
See also: [TableProvenTx](./storage.md#interface-tableproventx), [UpdateProvenTxReqWithNewProvenTxArgs](./client.md#interface-updateproventxreqwithnewproventxargs), [UpdateProvenTxReqWithNewProvenTxResult](./client.md#interface-updateproventxreqwithnewproventxresult)

###### Method updateProvenTxReqWithNewProvenTxAuth

Authorize and validate remote proof completion before mutating shared proof state.

```ts
async updateProvenTxReqWithNewProvenTxAuth(auth: AuthId, args: UpdateProvenTxReqWithNewProvenTxArgs): Promise<UpdateProvenTxReqWithNewProvenTxResult>
```
See also: [AuthId](./client.md#interface-authid), [UpdateProvenTxReqWithNewProvenTxArgs](./client.md#interface-updateproventxreqwithnewproventxargs), [UpdateProvenTxReqWithNewProvenTxResult](./client.md#interface-updateproventxreqwithnewproventxresult)

###### Method updateTransactionStatus

For all `status` values besides 'failed', just updates the transaction records status property.

For 'status' of 'failed', attempts to make outputs previously allocated as inputs to this transaction usable again
and makes outputs generated by this transaction non-spendable.

```ts
async updateTransactionStatus(status: TransactionStatus, transactionId?: number, userId?: number, reference?: string, trx?: TrxToken): Promise<void>
```
See also: [TransactionStatus](./client.md#type-transactionstatus), [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: StorageReader

The `StorageReader` abstract class is the base of the concrete wallet storage provider classes.

It is the minimal interface required to read all wallet state records and is the base class for sync readers.

The next class in the heirarchy is the `StorageReaderWriter` which supports sync readers and writers.

The last class in the heirarchy is the `Storage` class which supports all active wallet operations.

The ability to construct a properly configured instance of this class implies authentication.
As such there are no user specific authenticated access checks implied in the implementation of any of these methods.

```ts
export abstract class StorageReader implements sdk.WalletStorageSyncReader {
    chain: sdk.Chain;
    readonly telemetry: Telemetry;
    _settings?: TableSettings;
    whenLastAccess?: Date;
    get dbtype(): DBType | undefined
    constructor(options: StorageReaderOptions)
    isAvailable(): boolean
    async makeAvailable(): Promise<TableSettings>
    getSettings(): TableSettings
    isStorageProvider(): boolean
    abstract destroy(): Promise<void>;
    abstract transaction<T>(scope: (trx: sdk.TrxToken) => Promise<T>, trx?: sdk.TrxToken): Promise<T>;
    abstract readSettings(trx?: sdk.TrxToken): Promise<TableSettings>;
    abstract findCertificateFields(args: sdk.FindCertificateFieldsArgs): Promise<TableCertificateField[]>;
    abstract findCertificates(args: sdk.FindCertificatesArgs): Promise<TableCertificateX[]>;
    abstract findCommissions(args: sdk.FindCommissionsArgs): Promise<TableCommission[]>;
    abstract findMonitorEvents(args: sdk.FindMonitorEventsArgs): Promise<TableMonitorEvent[]>;
    abstract findOutputBaskets(args: sdk.FindOutputBasketsArgs): Promise<TableOutputBasket[]>;
    abstract findOutputs(args: sdk.FindOutputsArgs): Promise<TableOutput[]>;
    abstract findOutputTags(args: sdk.FindOutputTagsArgs): Promise<TableOutputTag[]>;
    abstract findSyncStates(args: sdk.FindSyncStatesArgs): Promise<TableSyncState[]>;
    abstract findTransactions(args: sdk.FindTransactionsArgs): Promise<TableTransaction[]>;
    abstract findTxLabels(args: sdk.FindTxLabelsArgs): Promise<TableTxLabel[]>;
    abstract findUsers(args: sdk.FindUsersArgs): Promise<TableUser[]>;
    abstract countCertificateFields(args: sdk.FindCertificateFieldsArgs): Promise<number>;
    abstract countCertificates(args: sdk.FindCertificatesArgs): Promise<number>;
    abstract countCommissions(args: sdk.FindCommissionsArgs): Promise<number>;
    abstract countMonitorEvents(args: sdk.FindMonitorEventsArgs): Promise<number>;
    abstract countOutputBaskets(args: sdk.FindOutputBasketsArgs): Promise<number>;
    abstract countOutputs(args: sdk.FindOutputsArgs): Promise<number>;
    abstract countOutputTags(args: sdk.FindOutputTagsArgs): Promise<number>;
    abstract countSyncStates(args: sdk.FindSyncStatesArgs): Promise<number>;
    abstract countTransactions(args: sdk.FindTransactionsArgs): Promise<number>;
    abstract countTxLabels(args: sdk.FindTxLabelsArgs): Promise<number>;
    abstract countUsers(args: sdk.FindUsersArgs): Promise<number>;
    abstract getProvenTxsForUser(args: sdk.FindForUserSincePagedArgs): Promise<TableProvenTx[]>;
    abstract getProvenTxReqsForUser(args: sdk.FindForUserSincePagedArgs): Promise<TableProvenTxReq[]>;
    abstract getTxLabelMapsForUser(args: sdk.FindForUserSincePagedArgs): Promise<TableTxLabelMap[]>;
    abstract getOutputTagMapsForUser(args: sdk.FindForUserSincePagedArgs): Promise<TableOutputTagMap[]>;
    async getSyncChunkTotals(_args: sdk.RequestSyncChunkArgs, _userId: number): Promise<sdk.SyncChunkTotals | undefined>
    async findUserByIdentityKey(key: string): Promise<TableUser | undefined>
    async getSyncChunk(args: sdk.RequestSyncChunkArgs): Promise<sdk.SyncChunk>
    validateEntityDate(date: DateInput): StorageDate
    validateOptionalEntityDate(date: OptionalDateInput, useNowAsDefault?: boolean): StorageDate | undefined
    validateDate(date: DateInput): Date
    validateOptionalDate(date: OptionalDateInput): Date | undefined
    validateDateForWhere(date: DateInput): DateInput
}
```

See also: [Chain](./client.md#type-chain), [DBType](./storage.md#type-dbtype), [FindCertificateFieldsArgs](./client.md#interface-findcertificatefieldsargs), [FindCertificatesArgs](./client.md#interface-findcertificatesargs), [FindCommissionsArgs](./client.md#interface-findcommissionsargs), [FindForUserSincePagedArgs](./client.md#interface-findforusersincepagedargs), [FindMonitorEventsArgs](./client.md#interface-findmonitoreventsargs), [FindOutputBasketsArgs](./client.md#interface-findoutputbasketsargs), [FindOutputTagsArgs](./client.md#interface-findoutputtagsargs), [FindOutputsArgs](./client.md#interface-findoutputsargs), [FindSyncStatesArgs](./client.md#interface-findsyncstatesargs), [FindTransactionsArgs](./client.md#interface-findtransactionsargs), [FindTxLabelsArgs](./client.md#interface-findtxlabelsargs), [FindUsersArgs](./client.md#interface-findusersargs), [RequestSyncChunkArgs](./client.md#interface-requestsyncchunkargs), [StorageReaderOptions](./storage.md#interface-storagereaderoptions), [SyncChunk](./client.md#interface-syncchunk), [SyncChunkTotals](./client.md#interface-syncchunktotals), [TableCertificateField](./storage.md#interface-tablecertificatefield), [TableCertificateX](./storage.md#interface-tablecertificatex), [TableCommission](./storage.md#interface-tablecommission), [TableMonitorEvent](./storage.md#interface-tablemonitorevent), [TableOutput](./storage.md#interface-tableoutput), [TableOutputBasket](./storage.md#interface-tableoutputbasket), [TableOutputTag](./storage.md#interface-tableoutputtag), [TableOutputTagMap](./storage.md#interface-tableoutputtagmap), [TableProvenTx](./storage.md#interface-tableproventx), [TableProvenTxReq](./storage.md#interface-tableproventxreq), [TableSettings](./storage.md#interface-tablesettings), [TableSyncState](./storage.md#interface-tablesyncstate), [TableTransaction](./storage.md#interface-tabletransaction), [TableTxLabel](./storage.md#interface-tabletxlabel), [TableTxLabelMap](./storage.md#interface-tabletxlabelmap), [TableUser](./storage.md#interface-tableuser), [TrxToken](./client.md#interface-trxtoken), [WalletStorageSyncReader](./client.md#interface-walletstoragesyncreader), [getSyncChunk](./storage.md#function-getsyncchunk), [validateDate](./storage.md#function-validatedate)

###### Method getSyncChunkTotals

Optional efficient source-side totals for synchronization progress.
Providers without a native count implementation omit the metadata rather
than loading every matching record merely to count it.

```ts
async getSyncChunkTotals(_args: sdk.RequestSyncChunkArgs, _userId: number): Promise<sdk.SyncChunkTotals | undefined>
```
See also: [RequestSyncChunkArgs](./client.md#interface-requestsyncchunkargs), [SyncChunkTotals](./client.md#interface-syncchunktotals)

###### Method validateEntityDate

Force dates to strings on SQLite and Date objects on MySQL

```ts
validateEntityDate(date: DateInput): StorageDate
```

###### Method validateOptionalEntityDate

```ts
validateOptionalEntityDate(date: OptionalDateInput, useNowAsDefault?: boolean): StorageDate | undefined
```

Argument Details

+ **useNowAsDefault**
  + if true and date is null or undefiend, set to current time.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: StorageReaderWriter

```ts
export abstract class StorageReaderWriter extends StorageReader {
    abstract dropAllData(): Promise<void>;
    abstract migrate(storageName: string, storageIdentityKey: string): Promise<string>;
    abstract findOutputTagMaps(args: FindOutputTagMapsArgs): Promise<TableOutputTagMap[]>;
    abstract findProvenTxReqs(args: FindProvenTxReqsArgs): Promise<TableProvenTxReq[]>;
    abstract findProvenTxs(args: FindProvenTxsArgs): Promise<TableProvenTx[]>;
    abstract findTxLabelMaps(args: FindTxLabelMapsArgs): Promise<TableTxLabelMap[]>;
    abstract findStaleMerkleRoots(args: FindStaleMerkleRootsArgs): Promise<string[]>;
    abstract countOutputTagMaps(args: FindOutputTagMapsArgs): Promise<number>;
    abstract countProvenTxReqs(args: FindProvenTxReqsArgs): Promise<number>;
    abstract countProvenTxs(args: FindProvenTxsArgs): Promise<number>;
    abstract countTxLabelMaps(args: FindTxLabelMapsArgs): Promise<number>;
    abstract insertCertificate(certificate: TableCertificate, trx?: TrxToken): Promise<number>;
    abstract insertCertificateField(certificateField: TableCertificateField, trx?: TrxToken): Promise<void>;
    abstract insertCommission(commission: TableCommission, trx?: TrxToken): Promise<number>;
    abstract insertMonitorEvent(event: TableMonitorEvent, trx?: TrxToken): Promise<number>;
    abstract insertOutput(output: TableOutput, trx?: TrxToken): Promise<number>;
    abstract insertOutputBasket(basket: TableOutputBasket, trx?: TrxToken): Promise<number>;
    abstract insertOutputTag(tag: TableOutputTag, trx?: TrxToken): Promise<number>;
    abstract insertOutputTagMap(tagMap: TableOutputTagMap, trx?: TrxToken): Promise<void>;
    abstract insertProvenTx(tx: TableProvenTx, trx?: TrxToken): Promise<number>;
    abstract insertProvenTxReq(tx: TableProvenTxReq, trx?: TrxToken): Promise<number>;
    abstract insertSyncState(syncState: TableSyncState, trx?: TrxToken): Promise<number>;
    abstract insertTransaction(tx: TableTransaction, trx?: TrxToken): Promise<number>;
    abstract insertTxLabel(label: TableTxLabel, trx?: TrxToken): Promise<number>;
    abstract insertTxLabelMap(labelMap: TableTxLabelMap, trx?: TrxToken): Promise<void>;
    abstract insertUser(user: TableUser, trx?: TrxToken): Promise<number>;
    abstract updateCertificate(id: number, update: Partial<TableCertificate>, trx?: TrxToken): Promise<number>;
    abstract updateCertificateField(certificateId: number, fieldName: string, update: Partial<TableCertificateField>, trx?: TrxToken): Promise<number>;
    abstract updateCommission(id: number, update: Partial<TableCommission>, trx?: TrxToken): Promise<number>;
    abstract updateMonitorEvent(id: number, update: Partial<TableMonitorEvent>, trx?: TrxToken): Promise<number>;
    abstract updateOutput(id: number, update: Partial<TableOutput>, trx?: TrxToken): Promise<number>;
    abstract updateOutputBasket(id: number, update: Partial<TableOutputBasket>, trx?: TrxToken): Promise<number>;
    abstract updateOutputTag(id: number, update: Partial<TableOutputTag>, trx?: TrxToken): Promise<number>;
    abstract updateOutputTagMap(outputId: number, tagId: number, update: Partial<TableOutputTagMap>, trx?: TrxToken): Promise<number>;
    abstract updateProvenTx(id: number, update: Partial<TableProvenTx>, trx?: TrxToken): Promise<number>;
    abstract updateProvenTxReq(id: number | number[], update: Partial<TableProvenTxReq>, trx?: TrxToken): Promise<number>;
    abstract updateSyncState(id: number, update: Partial<TableSyncState>, trx?: TrxToken): Promise<number>;
    abstract updateTransaction(id: number | number[], update: Partial<TableTransaction>, trx?: TrxToken): Promise<number>;
    async compareAndSetNoSendExpiryState(_transactionId: number, _expected: Brc177NoSendExpiryState, _next: Brc177NoSendExpiryState, _trx?: TrxToken): Promise<boolean>
    abstract updateTxLabel(id: number, update: Partial<TableTxLabel>, trx?: TrxToken): Promise<number>;
    abstract updateTxLabelMap(transactionId: number, txLabelId: number, update: Partial<TableTxLabelMap>, trx?: TrxToken): Promise<number>;
    abstract updateUser(id: number, update: Partial<TableUser>, trx?: TrxToken): Promise<number>;
    async setActive(auth: AuthId, newActiveStorageIdentityKey: string): Promise<number>
    async findCertificateById(id: number, trx?: TrxToken): Promise<TableCertificate | undefined>
    async findCommissionById(id: number, trx?: TrxToken): Promise<TableCommission | undefined>
    async findOutputById(id: number, trx?: TrxToken, noScript?: boolean): Promise<TableOutput | undefined>
    async findOutputBasketById(id: number, trx?: TrxToken): Promise<TableOutputBasket | undefined>
    async findProvenTxById(id: number, trx?: TrxToken | undefined): Promise<TableProvenTx | undefined>
    async findProvenTxReqById(id: number, trx?: TrxToken | undefined): Promise<TableProvenTxReq | undefined>
    async findSyncStateById(id: number, trx?: TrxToken): Promise<TableSyncState | undefined>
    async findTransactionById(id: number, trx?: TrxToken, noRawTx?: boolean): Promise<TableTransaction | undefined>
    async findTxLabelById(id: number, trx?: TrxToken): Promise<TableTxLabel | undefined>
    async findOutputTagById(id: number, trx?: TrxToken): Promise<TableOutputTag | undefined>
    async findUserById(id: number, trx?: TrxToken): Promise<TableUser | undefined>
    async findOrInsertUser(identityKey: string, trx?: TrxToken): Promise<{
        user: TableUser;
        isNew: boolean;
    }>
    async findOrInsertTransaction(newTx: TableTransaction, trx?: TrxToken): Promise<{
        tx: TableTransaction;
        isNew: boolean;
    }>
    async findOrInsertOutputBasket(userId: number, name: string, trx?: TrxToken): Promise<TableOutputBasket>
    async findOrInsertTxLabel(userId: number, label: string, trx?: TrxToken): Promise<TableTxLabel>
    async findOrInsertTxLabelMap(transactionId: number, txLabelId: number, trx?: TrxToken): Promise<TableTxLabelMap>
    async findOrInsertOutputTag(userId: number, tag: string, trx?: TrxToken): Promise<TableOutputTag>
    async findOrInsertOutputTagMap(outputId: number, outputTagId: number, trx?: TrxToken): Promise<TableOutputTagMap>
    async getSyncCheckpoint(auth: AuthId, storageIdentityKey: string, storageName: string)
    async findOrInsertSyncStateAuth(auth: AuthId, storageIdentityKey: string, storageName: string): Promise<{
        syncState: TableSyncState;
        isNew: boolean;
    }>
    async findOrInsertProvenTxReq(newReq: TableProvenTxReq, trx?: TrxToken): Promise<{
        req: TableProvenTxReq;
        isNew: boolean;
    }>
    async findOrInsertProvenTx(newProven: TableProvenTx, trx?: TrxToken): Promise<{
        proven: TableProvenTx;
        isNew: boolean;
    }>
    abstract processSyncChunk(args: RequestSyncChunkArgs, chunk: SyncChunk): Promise<ProcessSyncChunkResult>;
    async tagOutput(partial: Partial<TableOutput>, tag: string, trx?: TrxToken): Promise<void>
}
```

See also: [AuthId](./client.md#interface-authid), [Brc177NoSendExpiryState](./client.md#type-brc177nosendexpirystate), [FindOutputTagMapsArgs](./client.md#interface-findoutputtagmapsargs), [FindProvenTxReqsArgs](./client.md#interface-findproventxreqsargs), [FindProvenTxsArgs](./client.md#interface-findproventxsargs), [FindStaleMerkleRootsArgs](./client.md#interface-findstalemerklerootsargs), [FindTxLabelMapsArgs](./client.md#interface-findtxlabelmapsargs), [ProcessSyncChunkResult](./client.md#interface-processsyncchunkresult), [RequestSyncChunkArgs](./client.md#interface-requestsyncchunkargs), [StorageReader](./storage.md#class-storagereader), [SyncChunk](./client.md#interface-syncchunk), [TableCertificate](./storage.md#interface-tablecertificate), [TableCertificateField](./storage.md#interface-tablecertificatefield), [TableCommission](./storage.md#interface-tablecommission), [TableMonitorEvent](./storage.md#interface-tablemonitorevent), [TableOutput](./storage.md#interface-tableoutput), [TableOutputBasket](./storage.md#interface-tableoutputbasket), [TableOutputTag](./storage.md#interface-tableoutputtag), [TableOutputTagMap](./storage.md#interface-tableoutputtagmap), [TableProvenTx](./storage.md#interface-tableproventx), [TableProvenTxReq](./storage.md#interface-tableproventxreq), [TableSyncState](./storage.md#interface-tablesyncstate), [TableTransaction](./storage.md#interface-tabletransaction), [TableTxLabel](./storage.md#interface-tabletxlabel), [TableTxLabelMap](./storage.md#interface-tabletxlabelmap), [TableUser](./storage.md#interface-tableuser), [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: SyncPageBudget

Per-copy work budget. Bytes alone cannot bound network-backed proof checks.

```ts
export class SyncPageBudget {
    apply(args: RequestSyncChunkArgs): RequestSyncChunkArgs
    committed(chunk: SyncChunk, elapsedMs: number): void
}
```

See also: [RequestSyncChunkArgs](./client.md#interface-requestsyncchunkargs), [SyncChunk](./client.md#interface-syncchunk)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskArcadeSSE

Monitor task that receives transaction status updates from Arcade via SSE
and processes them — including fetching merkle proofs directly from Arcade
when transactions are MINED.

```ts
export class TaskArcadeSSE extends WalletMonitorTask {
    static readonly taskName = "ArcadeSSE";
    sseClient: ArcSSEClient | null = null;
    constructor(monitor: Monitor)
    override async asyncSetup(): Promise<void>
    trigger(_nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
    async fetchNow(): Promise<number>
    close(): void
}
```

See also: [ArcSSEClient](./services.md#class-arcsseclient), [Monitor](./monitor.md#class-monitor), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

###### Method close

Close the live stream and reject any unacknowledged monitor event.

```ts
close(): void
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskCheckForProofs

`TaskCheckForProofs` is a WalletMonitor task that retreives merkle proofs for
transactions.

It is normally triggered by the Chaintracks new block header event.

When a new block is found, cwi-external-services are used to obtain proofs for
any transactions that are currently in the 'unmined' or 'unknown' state.

If a proof is obtained and validated, a new ProvenTx record is created and
the original ProvenTxReq status is advanced to 'notifying'.

```ts
export class TaskCheckForProofs extends WalletMonitorTask {
    static readonly taskName = "CheckForProofs";
    static get checkNow(): boolean
    static set checkNow(value: boolean)
    constructor(monitor: Monitor, public triggerMsecs = 0)
    trigger(_nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
}
```

See also: [Monitor](./monitor.md#class-monitor), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

###### Method trigger

Normally triggered by checkNow getting set by new block header found event from chaintracks

```ts
trigger(_nowMsecsSinceEpoch: number): {
    run: boolean;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskCheckNoSends

`TaskCheckNoSends` is a WalletMonitor task that retrieves merkle proofs for
'nosend' transactions that MAY have been shared externally.

Unlike intentionally processed transactions, 'nosend' transactions are fully valid
transactions which have not been processed by the wallet.

By default, this task runs once a day to check if any 'nosend' transaction has
managed to get mined by some external process.

If a proof is obtained and validated, a new ProvenTx record is created and
the original ProvenTxReq status is advanced to 'notifying'.

# Aging schedule on the checkNow path

When this task is triggered by a new block header (`checkNow = true`, wired in
`Monitor.processNewBlockHeader`), it does NOT scan every `nosend` row on every
block. The set of `nosend` rows can grow large over a wallet's lifetime
(txs sitting in escrow, un-aborted tests, abandoned batches), and a fast,
unfiltered scan on every block would do an unbounded number of external
`getMerklePath` lookups per block.

Instead, the row's age (now - `created_at`) determines how often it is
eligible for a checkNow-triggered chain check. The schedule starts at "skip
entirely" for very fresh rows (to protect in-flight batched-tx workflows
where chained `createAction({ noSend: true, sendWith: [...] })` builds
deliberately keep rows in `nosend` until a single terminator broadcasts the
whole BEEF), then progresses to "every block", "hourly", "daily", and
"weekly" as rows age:

  age < 5 min                 → skip (in-flight batch protection)
  5 min ≤ age < 1 hr          → check on every checkNow trigger
  1 hr   ≤ age < 24 hr        → check on ~hourly cadence (block-height % 6)
  24 hr  ≤ age < 7 days       → check on ~daily cadence  (block-height % 144)
  age ≥ 7 days                → check on ~weekly cadence (block-height % 1008)

Block-height modulo gives a deterministic, stateless way to schedule
checks for older rows; no per-row "last checked" persistence is required.
Each row's modulo offset is keyed by its `provenTxReqId` so that rows in
the same age tier are staggered across the modulo cycle rather than all
firing on the same block — `(blockHeight + provenTxReqId) % tierInterval`.
For a wallet with N rows in tier T and tier interval K, this gives
roughly N/K rows fired per block instead of N rows fired every K blocks.

The scheduled daily cadence (no `checkNow`) is unaffected — it still scans
every row regardless of age. That path is the once-per-day fallback that
guarantees externally-broadcast `nosend` txs are eventually recognized
even if the aging schedule on the checkNow path defers them.

```ts
export class TaskCheckNoSends extends WalletMonitorTask {
    static readonly taskName = "CheckNoSends";
    static get checkNow(): boolean
    static set checkNow(value: boolean)
    static readonly tier0FreshSkipMsecs = 5 * 60 * 1000;
    static readonly tier1EveryBlockMsecs = 60 * 60 * 1000;
    static readonly tier2HourlyMsecs = 24 * 60 * 60 * 1000;
    static readonly tier3DailyMsecs = 7 * 24 * 60 * 60 * 1000;
    static readonly tier2BlockInterval = 6;
    static readonly tier3BlockInterval = 144;
    static readonly tier4BlockInterval = 1008;
    static shouldCheckOnCheckNow(createdAt: Date, nowMs: number, currentBlockHeight: number, provenTxReqId: number): boolean
    constructor(monitor: Monitor, public triggerMsecs = Monitor.oneDay * 1)
    trigger(nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
}
```

See also: [Monitor](./monitor.md#class-monitor), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

###### Property tier0FreshSkipMsecs

Aging-schedule constants for the `checkNow` path. Rows below `tier0FreshSkipMsecs`
are never checked via checkNow (batched-tx protection). Rows from tier 0 up
to `tier1EveryBlockMsecs` are checked on every checkNow trigger. Beyond that,
checks happen on `block-height % tierNBlockInterval === 0` cadences with
growing intervals. The scheduled daily cadence (no checkNow) is unaffected.

```ts
static readonly tier0FreshSkipMsecs = 5 * 60 * 1000
```

###### Method shouldCheckOnCheckNow

Decide whether a single `nosend` row should be chain-checked on the
current `checkNow` trigger, based on its age, the current block
height, and its `provenTxReqId` (used to stagger same-tier rows
across the modulo cycle). See class docstring for the full schedule
and staggering rationale.

```ts
static shouldCheckOnCheckNow(createdAt: Date, nowMs: number, currentBlockHeight: number, provenTxReqId: number): boolean
```

###### Method trigger

Normally triggered by checkNow getting set by new block header found event from chaintracks

```ts
trigger(nowMsecsSinceEpoch: number): {
    run: boolean;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskCleanupActionBatches

Releases expired action-batch reservations and incomplete staged blobs.

```ts
export class TaskCleanupActionBatches extends WalletMonitorTask {
    static readonly taskName = "CleanupActionBatches";
    constructor(monitor: Monitor, public triggerMsecs = Monitor.oneMinute)
    trigger(nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
}
```

See also: [Monitor](./monitor.md#class-monitor), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskClock

```ts
export class TaskClock extends WalletMonitorTask {
    static readonly taskName = "Clock";
    nextMinute: number;
    constructor(monitor: Monitor, public triggerMsecs = 1 * Monitor.oneSecond)
    trigger(_nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
    getNextMinute(): number
}
```

See also: [Monitor](./monitor.md#class-monitor), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskFailAbandoned

Handles transactions which do not have terminal status and have not been
updated for an extended time period.

Calls `updateTransactionStatus` to set `status` to `failed`.
This returns inputs to spendable status and verifies that any
outputs are not spendable.

```ts
export class TaskFailAbandoned extends WalletMonitorTask {
    static readonly taskName = "FailAbandoned";
    constructor(monitor: Monitor, public triggerMsecs = 1000 * 60 * 5)
    trigger(nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
}
```

See also: [Monitor](./monitor.md#class-monitor), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskMineBlock

```ts
export class TaskMineBlock extends WalletMonitorTask {
    static readonly taskName = "MineBlock";
    static get mineNow(): boolean
    static set mineNow(value: boolean)
    constructor(monitor: Monitor, public triggerMsecs = 10 * Monitor.oneMinute)
    trigger(nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
}
```

See also: [Monitor](./monitor.md#class-monitor), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskMonitorCallHistory

```ts
export class TaskMonitorCallHistory extends WalletMonitorTask {
    static readonly taskName = "MonitorCallHistory";
    constructor(monitor: Monitor, public triggerMsecs = Monitor.oneMinute * 12)
    trigger(nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
}
```

See also: [Monitor](./monitor.md#class-monitor), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskNewHeader

This task polls for new block headers performing two essential functions:
1. The arrival of a new block is the right time to check for proofs for recently broadcast transactions.
2. The height of the block is used to limit which proofs are accepted with the aim of avoiding re-orged proofs.

The most common new block orphan is one which is almost immediately orphaned.
Waiting a minute before pursuing proof requests avoids almost all the re-org work that could be done.
Thus this task queues new headers for one cycle.
If a new header arrives during that cycle, it replaces the queued header and delays again.
Only when there is an elapsed cycle without a new header does proof solicitation get triggered,
with that header height as the limit for which proofs are accepted.

```ts
export class TaskNewHeader extends WalletMonitorTask {
    static readonly taskName = "NewHeader";
    header?: BlockHeader;
    queuedHeader?: BlockHeader;
    queuedHeaderWhen?: Date;
    constructor(monitor: Monitor, public triggerMsecs = 1 * Monitor.oneMinute)
    async getHeader(): Promise<BlockHeader>
    override async asyncSetup(): Promise<void>
    trigger(_nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
}
```

See also: [BlockHeader](./client.md#interface-blockheader), [Monitor](./monitor.md#class-monitor), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

###### Property header

This is always the most recent chain tip header returned from the chaintracker.

```ts
header?: BlockHeader
```
See also: [BlockHeader](./client.md#interface-blockheader)

###### Property queuedHeader

Tracks the value of `header` except that it is set to undefined
when a cycle without a new header occurs and `processNewBlockHeader` is called.

```ts
queuedHeader?: BlockHeader
```
See also: [BlockHeader](./client.md#interface-blockheader)

###### Method asyncSetup

This task intentionally polls for new headers. Reorganization notification
is outside this task's current contract and requires a chaintracker event
source before it can be added without changing monitor behavior.

New header events drive retrieving merklePaths for newly mined transactions.
This implementation performs this function.

Reorg events are needed to know when previously retrieved mekrlePaths need to be
updated in the proven_txs table (and ideally notifications delivered to users).
Note that in-general, a reorg only shifts where in the block a transaction is mined,
and sometimes which block. In the case of coinbase transactions, a transaction may
also fail after a reorg.

```ts
override async asyncSetup(): Promise<void>
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskNoSendExpiry

Enforces BRC-177 noSend expiries from the active authoritative storage.
Reclaim transactions are signed before release, so this task never needs
access to wallet keys and is safe to run in a remote storage monitor.

```ts
export class TaskNoSendExpiry extends WalletMonitorTask {
    static readonly taskName = "NoSendExpiry";
    static requestCheck(): void
    constructor(monitor: Monitor, public triggerMsecs = 5 * Monitor.oneSecond)
    trigger(nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
}
```

See also: [Monitor](./monitor.md#class-monitor), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskPurge

```ts
export class TaskPurge extends WalletMonitorTask {
    static readonly taskName = "Purge";
    static get checkNow(): boolean
    static set checkNow(value: boolean)
    constructor(monitor: Monitor, public params: TaskPurgeParams, public triggerMsecs = 0)
    trigger(nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
}
```

See also: [Monitor](./monitor.md#class-monitor), [TaskPurgeParams](./monitor.md#interface-taskpurgeparams), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskReconcilePendingTransactions

Poll durable transaction lifecycle state for aged, non-terminal requests.
This closes the gap where an Arcade rejection event was missed before the
monitor subscribed or while it was offline. Unknown/provider-error results
never mutate storage; only a provider's explicit terminal verdict does.

```ts
export class TaskReconcilePendingTransactions extends WalletMonitorTask {
    static readonly taskName = "ReconcilePendingTransactions";
    triggerNextMsecs: number;
    constructor(monitor: Monitor, public triggerMsecs = Monitor.oneMinute * 12, public reviewLimit = 100, public minAgeMinutes = 60, public triggerQuickMsecs = Monitor.oneMinute)
    trigger(nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
}
```

See also: [Monitor](./monitor.md#class-monitor), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskReorg

Check the `monitor.deactivatedHeaders` for any headers that have been deactivated.

When headers are found, review matching ProvenTx records and update proof data as appropriate.

New deactivated headers are pushed onto the `deactivatedHeaders` array.
They must be shifted out as they are processed.

The current implementation ages deactivation notifications by 10 minutes with each retry.
If a successful proof update confirms original proof data after 3 retries, the original is retained.

In normal operation there should rarely be any work for this task to perform.
The most common result is that there are no matching proven_txs records because
generating new proven_txs records intentionally lags new block generation to
minimize this disruption.

It is very disruptive to update a proven_txs record because:
- Sync'ed storage is impacted.
- Generated beefs are impacted.
- Updated proof data may be unavailable at the time a reorg is first reported.

Proper reorg handling also requires repairing invalid beefs for new transactions when
createAction fails to verify a generated beef against the chaintracker.

```ts
export class TaskReorg extends WalletMonitorTask {
    static readonly taskName = "Reorg";
    process: DeactivedHeader[] = [];
    constructor(monitor: Monitor, public agedMsecs = Monitor.oneMinute * 10, public maxRetries = 3)
    trigger(nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
}
```

See also: [DeactivedHeader](./monitor.md#interface-deactivedheader), [Monitor](./monitor.md#class-monitor), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

###### Method trigger

Shift aged deactivated headers onto `process` array.

```ts
trigger(nowMsecsSinceEpoch: number): {
    run: boolean;
}
```

Returns

`run` true iff there are aged deactivated headers to process.

Argument Details

+ **nowMsecsSinceEpoch**
  + current time in milliseconds since epoch.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskReviewDoubleSpends

Review recent reqs in terminal 'doubleSpend' state and move any false positives
back to 'unfail' so existing recovery handling can re-process them.

```ts
export class TaskReviewDoubleSpends extends WalletMonitorTask {
    static readonly taskName = "ReviewDoubleSpends";
    static get checkNow(): boolean
    static set checkNow(value: boolean)
    triggerNextMsecs: number;
    constructor(monitor: Monitor, public triggerMsecs = Monitor.oneMinute * 12, public reviewLimit = 100, public minAgeMinutes = 60, public triggerQuickMsecs = Monitor.oneMinute * 1)
    trigger(nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async getLastReviewedCheckpoint(): Promise<{
        resumeOffset: number;
        expectedProvenTxReqId?: number;
    } | undefined>
    async runTask(): Promise<string>
}
```

See also: [Monitor](./monitor.md#class-monitor), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskReviewProvenTxs

Backup verification task for recent proven_txs records.

Reorg handling should normally be driven by TaskReorg via deactivated-header events.
This task runs a lagged audit over recent heights and only reproves transactions when
the currently canonical merkleRoot at a height no longer matches stored proven_txs roots.

```ts
export class TaskReviewProvenTxs extends WalletMonitorTask {
    static readonly taskName = "ReviewProvenTxs";
    static get checkNow(): boolean
    static set checkNow(value: boolean)
    triggerNextMsecs: number;
    constructor(monitor: Monitor, public triggerMsecs = Monitor.oneMinute * 10, public maxHeightsPerRun = 100, public minBlockAge = 100, public triggerQuickMsecs = Monitor.oneMinute * 1)
    trigger(nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
    async reviewHeightRange(range: HeightRange): Promise<ReviewHeightRangeResult>
    async getLastReviewedHeight(): Promise<number | undefined>
}
```

See also: [HeightRange](./services.md#class-heightrange), [Monitor](./monitor.md#class-monitor), [ReviewHeightRangeResult](./monitor.md#interface-reviewheightrangeresult), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskReviewStatus

Notify Transaction records of changes in ProvenTxReq records they may have missed.

The `notified` property flags reqs that do not need to be checked.

Looks for aged Transactions with provenTxId with status != 'completed', sets status to 'completed'.

Looks for reqs with 'invalid' status that have corresonding transactions with status other than 'failed'.

```ts
export class TaskReviewStatus extends WalletMonitorTask {
    static readonly taskName = "ReviewStatus";
    static get checkNow(): boolean
    static set checkNow(value: boolean)
    constructor(monitor: Monitor, public triggerMsecs = 1000 * 60 * 15, public agedMsecs = 1000 * 60 * 5)
    trigger(nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
}
```

See also: [Monitor](./monitor.md#class-monitor), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskReviewUtxos

Use the reviewByIdentityKey method to scan the UTXOs of a specific user by
identity key. The scan is read-only unless the caller explicitly requests
release, and release remains blocked if any provider result is inconclusive.
Operator UIs should use reviewPageByIdentityKey: it bounds each provider
round-trip and may explicitly release only the conclusive spent subset while
reporting unknowns.

The task itself is disabled and will not run on a schedule; review must be triggered manually by calling reviewByIdentityKey.

```ts
export class TaskReviewUtxos extends WalletMonitorTask {
    static readonly taskName = "ReviewUtxos";
    static get checkNow(): boolean
    static set checkNow(value: boolean)
    public triggerMsecs: number;
    public userLimit: number;
    public userOffset: number;
    public tags: string[];
    constructor(monitor: Monitor, triggerMsecs = 0, userLimit = 10, userOffset = 0, tags: string[] = ["all"])
    trigger(_nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
    async reviewByIdentityKey(identityKey: string, mode: "all" | "change" = "all", release = false): Promise<string>
    async reviewPageByIdentityKey(identityKey: string, mode: "all" | "change" = "all", release = false, pageLimit = REVIEW_PAGE_DEFAULT_LIMIT, offset = 0): Promise<TaskReviewUtxosPageResult>
    async reviewManagedChangeByIdentityKey(identityKey: string): Promise<string>
}
```

See also: [Monitor](./monitor.md#class-monitor), [TaskReviewUtxosPageResult](./monitor.md#interface-taskreviewutxospageresult), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

###### Method reviewManagedChangeByIdentityKey

Report managed-change liquidity without changing it. Monitor deliberately
has no signing authority; progressive migration occurs only during a
caller-authorized createAction.

```ts
async reviewManagedChangeByIdentityKey(identityKey: string): Promise<string>
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskSendWaiting

```ts
export class TaskSendWaiting extends WalletMonitorTask {
    static readonly taskName = "SendWaiting";
    lastSendingRunMsecsSinceEpoch: number | undefined;
    includeSending: boolean = true;
    triggerNextMsecs: number;
    constructor(monitor: Monitor, public triggerMsecs = Monitor.oneSecond * 8, public agedMsecs = Monitor.oneSecond * 7, public sendingMsecs = Monitor.oneMinute * 5, public triggerQuickMsecs = Monitor.oneSecond * 1, public chunkLimit = 100)
    trigger(nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
    async processUnsent(reqApis: TableProvenTxReq[], indent = 0): Promise<string>
}
```

See also: [Monitor](./monitor.md#class-monitor), [TableProvenTxReq](./storage.md#interface-tableproventxreq), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

###### Constructor

```ts
constructor(monitor: Monitor, public triggerMsecs = Monitor.oneSecond * 8, public agedMsecs = Monitor.oneSecond * 7, public sendingMsecs = Monitor.oneMinute * 5, public triggerQuickMsecs = Monitor.oneSecond * 1, public chunkLimit = 100)
```
See also: [Monitor](./monitor.md#class-monitor)

Argument Details

+ **monitor**
  + Wallet monitor owning this task.
+ **triggerMsecs**
  + Normal interval between SendWaiting runs when no backlog remains.
+ **agedMsecs**
  + Minimum age a request must reach before this task will attempt to send it.
+ **sendingMsecs**
  + Minimum interval before stale `sending` requests are included again.
+ **triggerQuickMsecs**
  + Follow-up interval used when a full chunk was consumed and more work may remain.
+ **chunkLimit**
  + Maximum number of waiting requests to fetch and inspect in a single run.

###### Method processUnsent

Process an array of 'unsent' status table.ProvenTxReq

Send rawTx to transaction processor(s), requesting proof callbacks when possible.

Set status 'invalid' if req is invalid.

Set status to 'callback' on successful network submission with callback service.

Set status to 'unmined' on successful network submission without callback service.

Add mapi responses to database table if received.

Increments attempts if sending was attempted.

```ts
async processUnsent(reqApis: TableProvenTxReq[], indent = 0): Promise<string>
```
See also: [TableProvenTxReq](./storage.md#interface-tableproventxreq)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: TaskUnFail

Setting provenTxReq status to 'unfail' when 'invalid' will attempt to find a merklePath, and if successful:

1. set the req status to 'unmined'
2. set the referenced txs to 'unproven'
3. determine if any inputs match user's existing outputs and if so update spentBy and spendable of those outputs.
4. set the txs outputs to spendable

If it fails (to find a merklePath), returns the req status to 'invalid'.

```ts
export class TaskUnFail extends WalletMonitorTask {
    static readonly taskName = "UnFail";
    static get checkNow(): boolean
    static set checkNow(value: boolean)
    constructor(monitor: Monitor, public triggerMsecs = Monitor.oneMinute * 10)
    trigger(nowMsecsSinceEpoch: number): {
        run: boolean;
    }
    async runTask(): Promise<string>
    async unfail(reqs: TableProvenTxReq[], indent = 0): Promise<{
        log: string;
    }>
    async unfailReq(req: EntityProvenTxReq, indent: number): Promise<string>
}
```

See also: [EntityProvenTxReq](./storage.md#class-entityproventxreq), [Monitor](./monitor.md#class-monitor), [TableProvenTxReq](./storage.md#interface-tableproventxreq), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

###### Method unfailReq

2. set the referenced txs to 'unproven'
3. determine if any inputs match user's existing outputs and if so update spentBy and spendable of those outputs.
4. set the txs outputs to spendable

```ts
async unfailReq(req: EntityProvenTxReq, indent: number): Promise<string>
```
See also: [EntityProvenTxReq](./storage.md#class-entityproventxreq)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WERR_BAD_REQUEST

The request is invalid.

```ts
export class WERR_BAD_REQUEST extends WalletError {
    constructor(message?: string)
}
```

See also: [WalletError](./client.md#class-walleterror)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WERR_BROADCAST_UNAVAILABLE

Unable to broadcast transaction at this time.

```ts
export class WERR_BROADCAST_UNAVAILABLE extends WalletError {
    constructor(_message?: string)
}
```

See also: [WalletError](./client.md#class-walleterror)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WERR_INSUFFICIENT_FUNDS

Insufficient funds in the available inputs to cover the cost of the required outputs
and the transaction fee (${moreSatoshisNeeded} more satoshis are needed,
for a total of ${totalSatoshisNeeded}), plus whatever would be required in order
to pay the fee to unlock and spend the outputs used to provide the additional satoshis.

```ts
export class WERR_INSUFFICIENT_FUNDS extends WalletError {
    constructor(public totalSatoshisNeeded: number, public moreSatoshisNeeded: number)
    override toJson(): string
}
```

See also: [WalletError](./client.md#class-walleterror)

###### Constructor

```ts
constructor(public totalSatoshisNeeded: number, public moreSatoshisNeeded: number)
```

Argument Details

+ **totalSatoshisNeeded**
  + Total satoshis required to fund transactions after net of required inputs and outputs.
+ **moreSatoshisNeeded**
  + Shortfall on total satoshis required to fund transactions after net of required inputs and outputs.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WERR_INTERNAL

An internal error has occurred.

This is an example of an error with an optional custom `message`.

```ts
export class WERR_INTERNAL extends WalletError {
    constructor(message?: string)
}
```

See also: [WalletError](./client.md#class-walleterror)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WERR_INVALID_MERKLE_ROOT

Invalid merkleRoot ${merkleRoot} for block ${blockHash} at height ${blockHeight}${txid ? ` for txid ${txid}` : ''}.

Typically thrown when a chain tracker fails to validate a merkle root.

```ts
export class WERR_INVALID_MERKLE_ROOT extends WalletError {
    constructor(public blockHash: string, public blockHeight: number, public merkleRoot: string, public txid?: string)
    override toJson(): string
}
```

See also: [WalletError](./client.md#class-walleterror), [blockHash](./services.md#function-blockhash)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WERR_INVALID_OPERATION

The ${parameter} parameter is invalid.

This is an example of an error object with a custom property `parameter` and templated `message`.

```ts
export class WERR_INVALID_OPERATION extends WalletError {
    constructor(message?: string)
}
```

See also: [WalletError](./client.md#class-walleterror)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WERR_INVALID_PARAMETER

The ${parameter} parameter is invalid.

This is an example of an error object with a custom property `parameter` and templated `message`.

```ts
export class WERR_INVALID_PARAMETER extends WalletError {
    constructor(public parameter: string, mustBe?: string)
    override toJson(): string
}
```

See also: [WalletError](./client.md#class-walleterror)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WERR_INVALID_PUBLIC_KEY

```ts
export class WERR_INVALID_PUBLIC_KEY extends WalletError {
    constructor(public key: string, network: WalletNetwork = "mainnet")
    protected override toJson(): string
}
```

See also: [WalletError](./client.md#class-walleterror)

###### Constructor

```ts
constructor(public key: string, network: WalletNetwork = "mainnet")
```

Argument Details

+ **key**
  + The invalid public key that caused the error.
+ **environment**
  + Optional environment flag to control whether the key is included in the message.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WERR_MISSING_PARAMETER

The required ${parameter} parameter is missing.

This is an example of an error object with a custom property `parameter`

```ts
export class WERR_MISSING_PARAMETER extends WalletError {
    constructor(public parameter: string)
    override toJson(): string
}
```

See also: [WalletError](./client.md#class-walleterror)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WERR_NETWORK_CHAIN

Configured network chain is invalid or does not match across services.

Live `WalletStorageManager.syncToWriter` and `syncFromReader` throw this
before any sync chunk moves when the reader and writer `TableSettings.chain`
values differ.

```ts
export class WERR_NETWORK_CHAIN extends WalletError {
    constructor(message?: string)
}
```

See also: [WalletError](./client.md#class-walleterror)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WERR_NOT_ACTIVE

WalletStorageManager is not accessing user's active storage or there are conflicting active stores configured.

```ts
export class WERR_NOT_ACTIVE extends WalletError {
    constructor(message?: string)
}
```

See also: [WalletError](./client.md#class-walleterror)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WERR_NOT_IMPLEMENTED

Not implemented.

```ts
export class WERR_NOT_IMPLEMENTED extends WalletError {
    constructor(message?: string)
}
```

See also: [WalletError](./client.md#class-walleterror)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WERR_REVIEW_ACTIONS

When a `createAction` or `signAction` is completed in undelayed mode (`acceptDelayedBroadcast`: false),
any unsuccessful result will return the results by way of this exception to ensure attention is
paid to processing errors.

```ts
export class WERR_REVIEW_ACTIONS extends WalletError {
    constructor(public reviewActionResults: ReviewActionResult[], public sendWithResults: SendWithResult[], public txid?: TXIDHexString, public tx?: AtomicBEEF, public noSendChange?: OutpointString[])
    override toJson(): string
}
```

See also: [ReviewActionResult](./client.md#interface-reviewactionresult), [WalletError](./client.md#class-walleterror)

###### Constructor

All parameters correspond to their comparable `createAction` or `signAction` results
with the exception of `reviewActionResults`;
which contains more details, particularly for double spend results.

```ts
constructor(public reviewActionResults: ReviewActionResult[], public sendWithResults: SendWithResult[], public txid?: TXIDHexString, public tx?: AtomicBEEF, public noSendChange?: OutpointString[])
```
See also: [ReviewActionResult](./client.md#interface-reviewactionresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WERR_UNAUTHORIZED

Access is denied due to an authorization error.

```ts
export class WERR_UNAUTHORIZED extends WalletError {
    constructor(message?: string)
}
```

See also: [WalletError](./client.md#class-walleterror)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WERR_UTXO_REVIEW_INCONCLUSIVE

A destructive UTXO review could not obtain a conclusive verdict for every
candidate. Consumers can match this name and retry later without parsing the
human-readable message.

```ts
export class WERR_UTXO_REVIEW_INCONCLUSIVE extends WalletError {
    constructor(public checked: number, public confirmedSpent: number, public unknown: number)
    override toJson(): string
}
```

See also: [WalletError](./client.md#class-walleterror)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: Wallet

```ts
export class Wallet implements WalletInterface, ProtoWallet {
    chain: Chain;
    keyDeriver: KeyDeriverApi;
    storage: WalletStorageManager;
    settingsManager: WalletSettingsManager;
    lookupResolver: LookupResolver;
    services?: WalletServices;
    monitor?: Monitor;
    contactSource?: ContactSource;
    identityKey: string;
    beef: BeefParty;
    includeAllSourceTransactions: boolean = true;
    autoKnownTxids: boolean = false;
    returnTxidOnly: boolean = false;
    trustSelf?: TrustSelf;
    userParty: string;
    proto: ProtoWallet;
    privilegedKeyManager?: PrivilegedKeyManager;
    makeLogger?: MakeWalletLogger;
    pendingSignActions: Record<string, PendingSignAction>;
    readonly actionBatch: ActionBatchController;
    readonly scriptVerifier?: SpendVerifierInterface;
    readonly telemetry: Telemetry;
    randomVals?: number[] = undefined;
    constructor(argsOrSigner: WalletArgs | WalletSigner, services?: WalletServices, monitor?: Monitor, privilegedKeyManager?: PrivilegedKeyManager, makeLogger?: MakeWalletLogger)
    async destroy(): Promise<void>
    getClientChangeKeyPair(): KeyPair
    async getIdentityKey(): Promise<PubKeyHex>
    async getPublicKey(args: GetPublicKeyArgs, _originator?: OriginatorDomainNameStringUnder250Bytes): Promise<GetPublicKeyResult>
    async revealCounterpartyKeyLinkage(args: RevealCounterpartyKeyLinkageArgs, _originator?: OriginatorDomainNameStringUnder250Bytes): Promise<RevealCounterpartyKeyLinkageResult>
    async revealSpecificKeyLinkage(args: RevealSpecificKeyLinkageArgs, _originator?: OriginatorDomainNameStringUnder250Bytes): Promise<RevealSpecificKeyLinkageResult>
    async encrypt(args: WalletEncryptArgs, _originator?: OriginatorDomainNameStringUnder250Bytes): Promise<WalletEncryptResult>
    async decrypt(args: WalletDecryptArgs, _originator?: OriginatorDomainNameStringUnder250Bytes): Promise<WalletDecryptResult>
    async createHmac(args: CreateHmacArgs, _originator?: OriginatorDomainNameStringUnder250Bytes): Promise<CreateHmacResult>
    async verifyHmac(args: VerifyHmacArgs, _originator?: OriginatorDomainNameStringUnder250Bytes): Promise<VerifyHmacResult>
    async createSignature(args: CreateSignatureArgs, _originator?: OriginatorDomainNameStringUnder250Bytes): Promise<CreateSignatureResult>
    async verifySignature(args: VerifySignatureArgs, _originator?: OriginatorDomainNameStringUnder250Bytes): Promise<VerifySignatureResult>
    getServices(): WalletServices
    getKnownTxids(newKnownTxids?: string[]): string[]
    getStorageIdentity(): StorageIdentity
    async listActions(args: ListActionsArgs, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<ListActionsResult>
    get storageParty(): string
    async listOutputs(args: ListOutputsArgs, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<ListOutputsResult>
    async listCertificates(args: ListCertificatesArgs, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<ListCertificatesResult>
    async acquireCertificate(args: AcquireCertificateArgs, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<AcquireCertificateResult>
    async relinquishCertificate(args: RelinquishCertificateArgs, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<RelinquishCertificateResult>
    async proveCertificate(args: ProveCertificateArgs, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<ProveCertificateResult>
    async discoverByIdentityKey(args: DiscoverByIdentityKeyArgs & {
        forceRefresh?: boolean;
    }, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<DiscoverCertificatesResult>
    async discoverByAttributes(args: DiscoverByAttributesArgs & {
        forceRefresh?: boolean;
    }, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<DiscoverCertificatesResult>
    verifyReturnedTxidOnly(beef: Beef, knownTxids?: string[]): Beef
    verifyReturnedTxidOnlyAtomicBEEF(beef: AtomicBEEF, knownTxids?: string[], parsedBeef?: Beef): AtomicBEEF
    verifyReturnedTxidOnlyBEEF(beef: BEEF): BEEF
    logMakeLogger(method: string, args: any): WalletLoggerInterface | undefined
    logMethodStart(method: string, logger?: WalletLoggerInterface): void
    logResult(r: any, logger?: WalletLoggerInterface): void
    logWalletError(eu: unknown, logger?: WalletLoggerInterface): void
    async createAction(args: CreateActionArgs, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<CreateActionResult>
    async signAction(args: SignActionArgs, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<SignActionResult>
    async internalizeAction(args: InternalizeActionArgs, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<InternalizeActionResult>
    async abortAction(args: AbortActionArgs, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<AbortActionResult>
    async relinquishOutput(args: RelinquishOutputArgs, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<RelinquishOutputResult>
    async isAuthenticated(args: {}, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<AuthenticatedResult>
    async waitForAuthentication(args: {}, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<AuthenticatedResult>
    async getHeight(args: {}, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<GetHeightResult>
    async getHeaderForHeight(args: GetHeaderArgs, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<GetHeaderResult>
    async getNetwork(args: {}, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<GetNetworkResult>
    async getVersion(args: {}, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<GetVersionResult>
    async sweepTo(toWallet: Wallet): Promise<void>
    async balanceAndUtxos(basket: string = "default"): Promise<WalletBalance>
    async balance(args?: ListOutputsArgs): Promise<number>
    async reviewSpendableOutputs(all = false, release = false, optionalArgs?: Partial<ListOutputsArgs>): Promise<ListOutputsResult>
    async setWalletChangeParams(count: number, satoshis: number): Promise<void>
    async listNoSendActions(args: ListActionsArgs, abort = false): Promise<ListActionsResult>
    async listFailedActions(args: ListActionsArgs, unfail = false): Promise<ListActionsResult>
}
```

See also: [ActionBatchController](./client.md#class-actionbatchcontroller), [Chain](./client.md#type-chain), [ContactSource](./client.md#interface-contactsource), [KeyPair](./client.md#interface-keypair), [Monitor](./monitor.md#class-monitor), [PendingSignAction](./client.md#interface-pendingsignaction), [PrivilegedKeyManager](./client.md#class-privilegedkeymanager), [StorageIdentity](./client.md#interface-storageidentity), [WalletArgs](./client.md#interface-walletargs), [WalletBalance](./client.md#interface-walletbalance), [WalletServices](./client.md#interface-walletservices), [WalletSettingsManager](./client.md#class-walletsettingsmanager), [WalletSigner](./client.md#class-walletsigner), [WalletStorageManager](./storage.md#class-walletstoragemanager), [createAction](./storage.md#function-createaction), [getIdentityKey](./client.md#function-getidentitykey), [internalizeAction](./storage.md#function-internalizeaction), [listActions](./storage.md#function-listactions), [listCertificates](./storage.md#function-listcertificates), [listOutputs](./storage.md#function-listoutputs), [logWalletError](./client.md#function-logwalleterror), [logger](./client.md#variable-logger), [proveCertificate](./client.md#function-provecertificate), [signAction](./client.md#function-signaction)

###### Property autoKnownTxids

If true, txids that are known to the wallet's party beef do not need to be returned from storage.

```ts
autoKnownTxids: boolean = false
```

###### Property beef

The wallet creates a `BeefParty` when it is created.
All the Beefs that pass through the wallet are merged into this beef.
Thus what it contains at any time is the union of all transactions and proof data processed.
The class `BeefParty` derives from `Beef`, adding the ability to track the source of merged data.

This allows it to generate beefs to send to a particular “party” (storage or the user)
that includes “txid only proofs” for transactions they already know about.
Over time, this allows an active wallet to drastically reduce the amount of data transmitted.

```ts
beef: BeefParty
```

###### Property includeAllSourceTransactions

If true, signableTransactions will include sourceTransaction for each input,
including those that do not require signature and those that were also contained
in the inputBEEF.

```ts
includeAllSourceTransactions: boolean = true
```

###### Property randomVals

For repeatability testing, set to an array of random numbers from [0..1).

```ts
randomVals?: number[] = undefined
```

###### Property returnTxidOnly

If true, beefs returned to the user may contain txidOnly transactions.

```ts
returnTxidOnly: boolean = false
```

###### Method balance

Uses `listOutputs` special operation to compute the total value (of satoshis) for
all spendable outputs in the 'default' basket.

```ts
async balance(args?: ListOutputsArgs): Promise<number>
```

Returns

sum of output satoshis

###### Method balanceAndUtxos

Uses `listOutputs` to iterate over chunks of up to 1000 outputs to
compute the sum of output satoshis.

For `default`, only wallet-managed BRC-29 change is included. Raw
administrative `listOutputs({ basket: 'default' })` remains available to
discover legacy incompatible rows for recovery.

```ts
async balanceAndUtxos(basket: string = "default"): Promise<WalletBalance>
```
See also: [WalletBalance](./client.md#interface-walletbalance)

Returns

total sum of output satoshis and utxo details (satoshis and outpoints)

Argument Details

+ **basket**
  + Optional. Defaults to 'default', the wallet change basket.

###### Method discoverByAttributes

Resolves matching identities from a caller-installed local contact source first, then the
certificate overlay. Local hits are authoritative personal assertions with empty third-party
certificate proof fields; use `forceRefresh` to bypass them and query the overlay.

```ts
async discoverByAttributes(args: DiscoverByAttributesArgs & {
    forceRefresh?: boolean;
}, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<DiscoverCertificatesResult>
```

###### Method discoverByIdentityKey

Resolves an identity from a caller-installed local contact source first, then the certificate
overlay. A local hit expresses the user's own authoritative trust decision and carries empty
third-party certificate proof fields; use `forceRefresh` to bypass it and query the overlay.

```ts
async discoverByIdentityKey(args: DiscoverByIdentityKeyArgs & {
    forceRefresh?: boolean;
}, originator?: OriginatorDomainNameStringUnder250Bytes): Promise<DiscoverCertificatesResult>
```

###### Method getKnownTxids

```ts
getKnownTxids(newKnownTxids?: string[]): string[]
```

Returns

the full list of txids whose validity this wallet claims to know.

Argument Details

+ **newKnownTxids**
  + Optional. Additional new txids known to be valid by the caller to be merged.

###### Method listFailedActions

Uses `listActions` special operation to return only actions with status 'failed'.

```ts
async listFailedActions(args: ListActionsArgs, unfail = false): Promise<ListActionsResult>
```

Returns

start `listActions` result restricted to 'failed' status actions.

Argument Details

+ **unfail**
  + Defaults to false. If true, queues the action for attempted recovery.

###### Method listNoSendActions

Uses `listActions` special operation to return only actions with status 'nosend'.

```ts
async listNoSendActions(args: ListActionsArgs, abort = false): Promise<ListActionsResult>
```

Returns

start `listActions` result restricted to 'nosend' (or 'failed' if aborted) actions.

Argument Details

+ **abort**
  + Defaults to false. If true, runs `abortAction` on each 'nosend' action.

###### Method reviewSpendableOutputs

Uses `listOutputs` special operation to review the spendability via `Services` of
outputs currently considered spendable. Returns only outputs conclusively
confirmed spent. Rejects the review if any provider result is inconclusive.

Ignores the `limit` and `offset` properties.

```ts
async reviewSpendableOutputs(all = false, release = false, optionalArgs?: Partial<ListOutputsArgs>): Promise<ListOutputsResult>
```

Returns

outputs previously considered spendable but conclusively confirmed spent.

Argument Details

+ **all**
  + Defaults to false. If false, only change outputs ('default' basket) are reviewed. If true, all spendable outputs are reviewed.
+ **release**
  + Defaults to false. If true, atomically sets conclusively spent outputs to un-spendable (spendable: false). No outputs change if any candidate is inconclusive.
+ **optionalArgs**
  + Optional. Additional tags will constrain the outputs processed.

###### Method setWalletChangeParams

Uses `listOutputs` special operation to update the 'default' basket's automatic
change generation parameters.

```ts
async setWalletChangeParams(count: number, satoshis: number): Promise<void>
```

Argument Details

+ **count**
  + target number of change UTXOs to maintain.
+ **satoshis**
  + target value for new change outputs.

###### Method sweepTo

Transfer all possible satoshis held by this wallet to `toWallet`.

```ts
async sweepTo(toWallet: Wallet): Promise<void>
```
See also: [Wallet](./client.md#class-wallet)

Argument Details

+ **toWallet**
  + wallet which will receive this wallet's satoshis.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WalletError

Derived class constructors should use the derived class name as the value for `name`,
and an internationalizable constant string for `message`.

If a derived class intends to wrap another WalletError, the public property should
be named `walletError` and will be recovered by `fromUnknown`.

Optionaly, the derived class `message` can include template parameters passed in
to the constructor. See WERR_MISSING_PARAMETER for an example.

To avoid derived class name colisions, packages should include a package specific
identifier after the 'WERR_' prefix. e.g. 'WERR_FOO_' as the prefix for Foo package error
classes.

```ts
export class WalletError extends Error implements WalletErrorObject {
    isError = true as const;
    constructor(name: string, message: string, stack?: string, public details?: Record<string, string>)
    get code(): ErrorCodeString10To40Bytes
    set code(v: ErrorCodeString10To40Bytes)
    get description(): ErrorDescriptionString20To200Bytes
    set description(v: ErrorDescriptionString20To200Bytes)
    static fromUnknown(err: unknown): WalletError
    asStatus(): {
        status: string;
        code: string;
        description: string;
    }
    protected toJson(): string
    static unknownToJson(error: unknown): string
}
```

###### Method asStatus

```ts
asStatus(): {
    status: string;
    code: string;
    description: string;
}
```

Returns

standard HTTP error status object with status property set to 'error'.

###### Method toJson

Base class default JSON serialization.
Captures just the name and message properties.

Override this method to safely (avoid deep, large, circular issues) serialize
derived class properties.

```ts
protected toJson(): string
```

Returns

stringified JSON representation of the WalletError.

###### Method unknownToJson

Safely serializes a WalletError derived, WERR_REVIEW_ACTIONS (special case), Error or unknown error to JSON.

Safely means avoiding deep, large, circular issues.

```ts
static unknownToJson(error: unknown): string
```

Returns

stringified JSON representation of the error such that it can be desirialized to a WalletError.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WalletMonitorTask

A monitor task performs some periodic or state triggered maintenance function
on the data managed by a wallet (Bitcoin UTXO manager, aka wallet)

The monitor maintains a collection of tasks.

It runs each task's non-asynchronous trigger to determine if the runTask method needs to run.

Tasks that need to be run are run consecutively by awaiting their async runTask override method.

The monitor then waits a fixed interval before repeating...

Tasks may use the monitor_events table to persist their execution history.
This is done by accessing the wathman.storage object.

```ts
export abstract class WalletMonitorTask {
    lastRunMsecsSinceEpoch = 0;
    storage: MonitorStorage;
    constructor(public monitor: Monitor, public name: string)
    async asyncSetup(): Promise<void>
    abstract trigger(nowMsecsSinceEpoch: number): {
        run: boolean;
    };
    abstract runTask(): Promise<string>;
}
```

See also: [Monitor](./monitor.md#class-monitor), [MonitorStorage](./monitor.md#type-monitorstorage)

###### Property lastRunMsecsSinceEpoch

Set by monitor each time runTask completes

```ts
lastRunMsecsSinceEpoch = 0
```

###### Method asyncSetup

Override to handle async task setup configuration.

Called before first call to `trigger`

```ts
async asyncSetup(): Promise<void>
```

###### Method trigger

Return true if `runTask` needs to be called now.

```ts
abstract trigger(nowMsecsSinceEpoch: number): {
    run: boolean;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WalletSettingsManager

Manages wallet settings

```ts
export class WalletSettingsManager {
    kv: LocalKVStore;
    constructor(wallet: WalletInterface, config: WalletSettingsManagerConfig = {
        defaultSettings: DEFAULT_SETTINGS
    })
    async get(): Promise<WalletSettings>
    async set(settings: WalletSettings): Promise<void>
    async delete(): Promise<void>
}
```

See also: [DEFAULT_SETTINGS](./client.md#variable-default_settings), [WalletSettings](./client.md#interface-walletsettings), [WalletSettingsManagerConfig](./client.md#interface-walletsettingsmanagerconfig)

###### Method delete

Deletes the user's settings token.

```ts
async delete(): Promise<void>
```

###### Method get

Returns a user's wallet settings

```ts
async get(): Promise<WalletSettings>
```
See also: [WalletSettings](./client.md#interface-walletsettings)

Returns

- Wallet settings object

###### Method set

Creates (or updates) the user's settings token.

```ts
async set(settings: WalletSettings): Promise<void>
```
See also: [WalletSettings](./client.md#interface-walletsettings)

Argument Details

+ **settings**
  + The wallet settings to be stored.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WalletSigner

```ts
export class WalletSigner {
    isWalletSigner = true as const;
    chain: Chain;
    keyDeriver: KeyDeriverApi;
    storage: WalletStorageManager;
    constructor(chain: Chain, keyDeriver: KeyDeriverApi, storage: WalletStorageManager)
}
```

See also: [Chain](./client.md#type-chain), [WalletStorageManager](./storage.md#class-walletstoragemanager)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WalletStorageManager

The `WalletStorageManager` class delivers authentication checking storage access to the wallet.

If manages multiple `StorageBase` derived storage services: one actice, the rest as backups.

Of the storage services, one is 'active' at any one time.
On startup, and whenever triggered by the wallet, `WalletStorageManager` runs a syncrhonization sequence:

1. While synchronizing, all other access to storage is blocked waiting.
2. The active service is confirmed, potentially triggering a resolution process if there is disagreement.
3. Changes are pushed from the active storage service to each inactive, backup service.

Some storage services do not support multiple writers. `WalletStorageManager` manages wait-blocking write requests
for these services.

```ts
export class WalletStorageManager implements sdk.WalletStorage {
    _stores: ManagedStorage[] = [];
    _isAvailable: boolean = false;
    _active?: ManagedStorage;
    _backups?: ManagedStorage[];
    _conflictingActives?: ManagedStorage[];
    _authId: sdk.AuthId;
    _services?: sdk.WalletServices;
    constructor(identityKey: string, active?: sdk.WalletStorageProvider, backups?: sdk.WalletStorageProvider[])
    isStorageProvider(): boolean
    isAvailable(): boolean
    get isActiveEnabled(): boolean
    canMakeAvailable(): boolean
    async makeAvailable(): Promise<TableSettings>
    async getAuth(mustBeActive?: boolean): Promise<sdk.AuthId>
    async getUserId(): Promise<number>
    getActive(): sdk.WalletStorageProvider
    getActiveSettings(): TableSettings
    getActiveUser(): TableUser
    getActiveStore(): string
    getActiveStoreName(): string
    getBackupStores(): string[]
    getConflictingStores(): string[]
    getAllStores(): string[]
    async runAsWriter<R>(writer: (active: sdk.WalletStorageWriter) => Promise<R>): Promise<R>
    async runAsReader<R>(reader: (active: sdk.WalletStorageReader) => Promise<R>): Promise<R>
    async runAsSync<R>(sync: (active: sdk.WalletStorageSync) => Promise<R>, activeSync?: sdk.WalletStorageSync): Promise<R>
    async runAsStorageProvider<R>(sync: (active: StorageProvider) => Promise<R>): Promise<R>
    invalidatePreparedBeefsForReorg(): Promise<void>
    isActiveStorageProvider(): boolean
    async addWalletStorageProvider(provider: sdk.WalletStorageProvider): Promise<void>
    setServices(v: sdk.WalletServices): void
    getServices(): sdk.WalletServices
    getSettings(): TableSettings
    async migrate(storageName: string, storageIdentityKey: string): Promise<string>
    async destroy(): Promise<void>
    async findOrInsertUser(identityKey: string): Promise<{
        user: TableUser;
        isNew: boolean;
    }>
    async abortAction(args: AbortActionArgs): Promise<AbortActionResult>
    async createAction(vargs: Validation.ValidCreateActionArgs): Promise<sdk.StorageCreateActionResult>
    async internalizeAction(args: InternalizeActionArgs): Promise<sdk.StorageInternalizeActionResult>
    async relinquishCertificate(args: RelinquishCertificateArgs): Promise<number>
    async relinquishOutput(args: RelinquishOutputArgs): Promise<number>
    async processAction(args: sdk.StorageProcessActionArgs): Promise<sdk.StorageProcessActionResults>
    async prepareNoSendExpiry(args: Validation.ValidCreateActionArgs): Promise<sdk.StoragePrepareNoSendExpiryResult>
    async activateNoSendExpiry(args: sdk.StorageActivateNoSendExpiryArgs): Promise<sdk.StorageActivateNoSendExpiryResult>
    async armNoSendExpiry(args: sdk.StorageArmNoSendExpiryArgs): Promise<void>
    async getCapabilities(): Promise<sdk.StorageCapabilities>
    async beginActionBatch(args: sdk.BeginActionBatchArgs): Promise<sdk.BeginActionBatchResult>
    async extendActionBatch(args: sdk.ExtendActionBatchArgs): Promise<sdk.ExtendActionBatchResult>
    async renewActionBatch(batchId: string): Promise<sdk.RenewActionBatchResult>
    async resumeActionBatch(args: sdk.ResumeActionBatchArgs): Promise<sdk.ResumeActionBatchResult>
    async prepareActionBatchCommit(manifest: sdk.ActionBatchManifest): Promise<sdk.PrepareActionBatchCommitResult>
    async putActionBatchBlob(args: sdk.PutActionBatchBlobArgs): Promise<void>
    async putActionBatchPack(args: sdk.PutActionBatchPackArgs): Promise<void>
    async commitActionBatch(manifest: sdk.ActionBatchManifest): Promise<sdk.CommitActionBatchResult>
    async commitActionBatchByDigest(args: sdk.CommitActionBatchByDigestArgs): Promise<sdk.CommitActionBatchResult>
    async abortActionBatch(batchId: string): Promise<sdk.AbortActionBatchResult>
    async insertCertificate(certificate: TableCertificate): Promise<number>
    async listActions(vargs: Validation.ValidListActionsArgs): Promise<ListActionsResult>
    async listCertificates(args: Validation.ValidListCertificatesArgs): Promise<ListCertificatesResult>
    async listOutputs(vargs: Validation.ValidListOutputsArgs): Promise<ListOutputsResult>
    async findCertificates(args: sdk.FindCertificatesArgs): Promise<TableCertificateX[]>
    async findOutputBaskets(args: sdk.FindOutputBasketsArgs): Promise<TableOutputBasket[]>
    async findOutputs(args: sdk.FindOutputsArgs): Promise<TableOutput[]>
    async findProvenTxReqs(args: sdk.FindProvenTxReqsArgs): Promise<TableProvenTxReq[]>
    async reproveHeader(deactivatedHash: string): Promise<sdk.ReproveHeaderResult>
    async reproveHeightMerkleRoot(height: number, staleMerkleRoot: string): Promise<sdk.ReproveHeaderResult>
    async reproveProven(ptx: TableProvenTx, noUpdate?: boolean): Promise<sdk.ReproveProvenResult>
    async syncFromReader(identityKey: string, reader: sdk.WalletStorageSyncReader, activeSync?: sdk.WalletStorageSync, log: string = ""): Promise<{
        inserts: number;
        updates: number;
        log: string;
    }>
    async syncToWriter(auth: sdk.AuthId, writer: sdk.WalletStorageProvider, activeSync?: sdk.WalletStorageSync, log: string = "", progLog?: (s: string) => string): Promise<{
        inserts: number;
        updates: number;
        log: string;
    }>
    async updateBackups(activeSync?: sdk.WalletStorageSync, progLog?: (s: string) => string): Promise<string>
    async setActive(storageIdentityKey: string, progLog?: (s: string) => string): Promise<string>
    getStoreEndpointURL(store: ManagedStorage): string | undefined
    getStores(): sdk.WalletStorageInfo[]
}
```

See also: [AbortActionBatchResult](./client.md#interface-abortactionbatchresult), [ActionBatchManifest](./client.md#interface-actionbatchmanifest), [AuthId](./client.md#interface-authid), [BeginActionBatchArgs](./client.md#interface-beginactionbatchargs), [BeginActionBatchResult](./client.md#interface-beginactionbatchresult), [CommitActionBatchByDigestArgs](./client.md#interface-commitactionbatchbydigestargs), [CommitActionBatchResult](./client.md#interface-commitactionbatchresult), [ExtendActionBatchArgs](./client.md#interface-extendactionbatchargs), [ExtendActionBatchResult](./client.md#interface-extendactionbatchresult), [FindCertificatesArgs](./client.md#interface-findcertificatesargs), [FindOutputBasketsArgs](./client.md#interface-findoutputbasketsargs), [FindOutputsArgs](./client.md#interface-findoutputsargs), [FindProvenTxReqsArgs](./client.md#interface-findproventxreqsargs), [PrepareActionBatchCommitResult](./client.md#interface-prepareactionbatchcommitresult), [PutActionBatchBlobArgs](./client.md#interface-putactionbatchblobargs), [PutActionBatchPackArgs](./client.md#interface-putactionbatchpackargs), [RenewActionBatchResult](./client.md#interface-renewactionbatchresult), [ReproveHeaderResult](./client.md#interface-reproveheaderresult), [ReproveProvenResult](./client.md#interface-reproveprovenresult), [ResumeActionBatchArgs](./client.md#interface-resumeactionbatchargs), [ResumeActionBatchResult](./client.md#interface-resumeactionbatchresult), [StorageActivateNoSendExpiryArgs](./client.md#interface-storageactivatenosendexpiryargs), [StorageActivateNoSendExpiryResult](./client.md#interface-storageactivatenosendexpiryresult), [StorageArmNoSendExpiryArgs](./client.md#interface-storagearmnosendexpiryargs), [StorageCapabilities](./client.md#interface-storagecapabilities), [StorageCreateActionResult](./client.md#interface-storagecreateactionresult), [StorageInternalizeActionResult](./client.md#interface-storageinternalizeactionresult), [StoragePrepareNoSendExpiryResult](./client.md#interface-storagepreparenosendexpiryresult), [StorageProcessActionArgs](./client.md#interface-storageprocessactionargs), [StorageProcessActionResults](./client.md#interface-storageprocessactionresults), [StorageProvider](./storage.md#class-storageprovider), [TableCertificate](./storage.md#interface-tablecertificate), [TableCertificateX](./storage.md#interface-tablecertificatex), [TableOutput](./storage.md#interface-tableoutput), [TableOutputBasket](./storage.md#interface-tableoutputbasket), [TableProvenTx](./storage.md#interface-tableproventx), [TableProvenTxReq](./storage.md#interface-tableproventxreq), [TableSettings](./storage.md#interface-tablesettings), [TableUser](./storage.md#interface-tableuser), [WalletServices](./client.md#interface-walletservices), [WalletStorage](./client.md#interface-walletstorage), [WalletStorageInfo](./client.md#interface-walletstorageinfo), [WalletStorageProvider](./client.md#interface-walletstorageprovider), [WalletStorageReader](./client.md#interface-walletstoragereader), [WalletStorageSync](./client.md#interface-walletstoragesync), [WalletStorageSyncReader](./client.md#interface-walletstoragesyncreader), [WalletStorageWriter](./client.md#interface-walletstoragewriter), [abortActionBatch](./storage.md#function-abortactionbatch), [activateNoSendExpiry](./storage.md#function-activatenosendexpiry), [armNoSendExpiry](./storage.md#function-armnosendexpiry), [beginActionBatch](./storage.md#function-beginactionbatch), [commitActionBatch](./storage.md#function-commitactionbatch), [commitActionBatchByDigest](./storage.md#function-commitactionbatchbydigest), [createAction](./storage.md#function-createaction), [extendActionBatch](./storage.md#function-extendactionbatch), [internalizeAction](./storage.md#function-internalizeaction), [listActions](./storage.md#function-listactions), [listCertificates](./storage.md#function-listcertificates), [listOutputs](./storage.md#function-listoutputs), [prepareActionBatchCommit](./storage.md#function-prepareactionbatchcommit), [prepareNoSendExpiry](./storage.md#function-preparenosendexpiry), [processAction](./storage.md#function-processaction), [putActionBatchBlob](./storage.md#function-putactionbatchblob), [putActionBatchPack](./storage.md#function-putactionbatchpack), [renewActionBatch](./storage.md#function-renewactionbatch), [resumeActionBatch](./storage.md#function-resumeactionbatch)

###### Constructor

Creates a new WalletStorageManager with the given identityKey and optional active and backup storage providers.

```ts
constructor(identityKey: string, active?: sdk.WalletStorageProvider, backups?: sdk.WalletStorageProvider[])
```
See also: [WalletStorageProvider](./client.md#interface-walletstorageprovider)

Argument Details

+ **identityKey**
  + The identity key of the user for whom this wallet is being managed.
+ **active**
  + An optional active storage provider. If not provided, no active storage will be set.
+ **backups**
  + An optional array of backup storage providers. If not provided, no backups will be set.

###### Property _active

The current active store which is only enabled if the store's user record activeStorage property matches its settings record storageIdentityKey property

```ts
_active?: ManagedStorage
```

###### Property _authId

identityKey is always valid, userId and isActive are valid only if _isAvailable

```ts
_authId: sdk.AuthId
```
See also: [AuthId](./client.md#interface-authid)

###### Property _backups

Stores to which state is pushed by updateBackups.

```ts
_backups?: ManagedStorage[]
```

###### Property _conflictingActives

Stores whose user record activeStorage property disagrees with the active store's user record activeStorage property.

```ts
_conflictingActives?: ManagedStorage[]
```

###### Property _isAvailable

True if makeAvailable has been run and access to managed stores (active) is allowed

```ts
_isAvailable: boolean = false
```

###### Property _services

Configured services if any. If valid, shared with stores (which may ignore it).

```ts
_services?: sdk.WalletServices
```
See also: [WalletServices](./client.md#interface-walletservices)

###### Property _stores

All configured stores including current active, backups, and conflicting actives.

```ts
_stores: ManagedStorage[] = []
```

###### Method canMakeAvailable

```ts
canMakeAvailable(): boolean
```

Returns

true if at least one WalletStorageProvider has been added.

###### Method getStoreEndpointURL

Return the remote HTTP(S) endpoint for a managed store, if any.

Duck-types `endpointUrl` on the provider (as set by `StorageClientBase`).
Do **not** key this off `constructor.name === 'StorageClient'`: production
minifiers (Vite/esbuild/webpack) rename classes, so that check fails and
every remote store reports `endpointURL: undefined` even though the URL is
present. Consumers that match backups by URL (e.g. making a remote store
primary) then fail while sync still works, because sync walks `_backups`
without needing `endpointURL`.

```ts
getStoreEndpointURL(store: ManagedStorage): string | undefined
```

###### Method invalidatePreparedBeefsForReorg

Reorg notifications call this before aging or replacement-proof I/O. The
active Knex store closes its in-process prepared-read gate synchronously,
then advances the shared database epoch and stales artifacts. A failed
invalidation deliberately leaves reads suspended so canonical BEEF remains
the safe path until a later invalidation succeeds or the process restarts.

```ts
invalidatePreparedBeefsForReorg(): Promise<void>
```

###### Method isActiveStorageProvider

```ts
isActiveStorageProvider(): boolean
```

Returns

true if the active `WalletStorageProvider` also implements `StorageProvider`

###### Method reproveHeader

For each proven_txs record currently sourcing its transaction merkle proof from the given deactivated header,
attempt to reprove the transaction against the current chain,
updating the proven_txs record if a new valid proof is found.

```ts
async reproveHeader(deactivatedHash: string): Promise<sdk.ReproveHeaderResult>
```
See also: [ReproveHeaderResult](./client.md#interface-reproveheaderresult)

Argument Details

+ **deactivatedHash**
  + An orphaned header than may have served as a proof source for proven_txs records.

###### Method reproveHeightMerkleRoot

For all proven_txs records at the given height currently tied to the given stale merkleRoot,
attempt to reprove them against the current chain and update proof data if new valid proofs are found.

This is intended for backup auditing of recent heights after the primary reorg event path has run.

```ts
async reproveHeightMerkleRoot(height: number, staleMerkleRoot: string): Promise<sdk.ReproveHeaderResult>
```
See also: [ReproveHeaderResult](./client.md#interface-reproveheaderresult)

###### Method runAsSync

```ts
async runAsSync<R>(sync: (active: sdk.WalletStorageSync) => Promise<R>, activeSync?: sdk.WalletStorageSync): Promise<R>
```
See also: [WalletStorageSync](./client.md#interface-walletstoragesync)

Argument Details

+ **sync**
  + the function to run with sync access lock
+ **activeSync**
  + from chained sync functions, active storage already held under sync access lock.

###### Method setActive

Updates backups and switches to new active storage provider from among current backup providers.

Also resolves conflicting actives.

```ts
async setActive(storageIdentityKey: string, progLog?: (s: string) => string): Promise<string>
```

Argument Details

+ **storageIdentityKey**
  + of current backup storage provider that is to become the new active provider.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WhatsOnChain

```ts
export class WhatsOnChain extends WhatsOnChainNoServices {
    services: Services;
    constructor(chain: Chain = "main", config: WalletToolboxWhatsOnChainConfig = {}, services?: Services)
    async getMerklePath(txid: string, services: WalletServices): Promise<GetMerklePathResult>
}
```

See also: [Chain](./client.md#type-chain), [GetMerklePathResult](./client.md#interface-getmerklepathresult), [Services](./services.md#class-services), [WalletServices](./client.md#interface-walletservices), [WalletToolboxWhatsOnChainConfig](./services.md#interface-wallettoolboxwhatsonchainconfig), [WhatsOnChainNoServices](./services.md#class-whatsonchainnoservices)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Class: WhatsOnChainNoServices

```ts
export class WhatsOnChainNoServices extends SdkWhatsOnChain {
    constructor(chain: Chain = "main", config: WalletToolboxWhatsOnChainConfig = {})
    async getStatusForTxids(txids: string[]): Promise<GetStatusForTxidsResult>
    async getTxPropagation(txid: string): Promise<number>
    async getRawTx(txid: string): Promise<string | undefined>
    async getRawTxResult(txid: string): Promise<GetRawTxResult>
    async postBeef(beef: Beef, txids: string[]): Promise<PostBeefResult>
    async postRawTx(rawTx: HexString): Promise<PostTxResultForTxid>
    async updateBsvExchangeRate(rate?: BsvExchangeRate, updateMsecs?: number): Promise<BsvExchangeRate>
    async getUtxoStatus(output: string, outputFormat?: GetUtxoStatusOutputFormat, outpoint?: string): Promise<GetUtxoStatusResult>
    async getScriptHashConfirmedHistory(hash: string): Promise<GetScriptHashHistoryResult>
    async getScriptHashUnconfirmedHistory(hash: string): Promise<GetScriptHashHistoryResult>
    async getScriptHashHistory(hash: string): Promise<GetScriptHashHistoryResult>
    async getBlockHeaderByHash(hash: string): Promise<BlockHeader | undefined>
    async getChainInfo(): Promise<WocChainInfo>
}
```

See also: [BlockHeader](./client.md#interface-blockheader), [BsvExchangeRate](./client.md#interface-bsvexchangerate), [Chain](./client.md#type-chain), [GetRawTxResult](./client.md#interface-getrawtxresult), [GetScriptHashHistoryResult](./client.md#interface-getscripthashhistoryresult), [GetStatusForTxidsResult](./client.md#interface-getstatusfortxidsresult), [GetUtxoStatusOutputFormat](./client.md#type-getutxostatusoutputformat), [GetUtxoStatusResult](./client.md#interface-getutxostatusresult), [PostBeefResult](./client.md#interface-postbeefresult), [PostTxResultForTxid](./client.md#interface-posttxresultfortxid), [SdkWhatsOnChain](./services.md#class-sdkwhatsonchain), [WalletToolboxWhatsOnChainConfig](./services.md#interface-wallettoolboxwhatsonchainconfig), [WocChainInfo](./services.md#interface-wocchaininfo)

###### Method getBlockHeaderByHash

{
  "hash": "000000000000000004a288072ebb35e37233f419918f9783d499979cb6ac33eb",
  "confirmations": 328433,
  "size": 14421,
  "height": 575045,
  "version": 536928256,
  "versionHex": "2000e000",
  "merkleroot": "4ebcba09addd720991d03473f39dce4b9a72cc164e505cd446687a54df9b1585",
  "time": 1553416668,
  "mediantime": 1553414858,
  "nonce": 87914848,
  "bits": "180997ee",
  "difficulty": 114608607557.4425,
  "chainwork": "000000000000000000000000000000000000000000ddf5d385546872bab7dc01",
  "previousblockhash": "00000000000000000988156c7075dc9147a5b62922f1310862e8b9000d46dd9b",
  "nextblockhash": "00000000000000000112b36a37c10235fa0c991f680bc5482ba9692e0ae697db",
  "nTx": 0,
  "num_tx": 5
}

```ts
async getBlockHeaderByHash(hash: string): Promise<BlockHeader | undefined>
```
See also: [BlockHeader](./client.md#interface-blockheader)

###### Method getRawTx

May return undefined for unmined transactions that are in the mempool.

```ts
async getRawTx(txid: string): Promise<string | undefined>
```

Returns

raw transaction as hex string or undefined if txid not found in mined block.

###### Method getStatusForTxids

POST
https://api.whatsonchain.com/v1/bsv/main/txs/status
Content-Type: application/json
data: "{\"txids\":[\"6815f8014db74eab8b7f75925c68929597f1d97efa970109d990824c25e5e62b\"]}"

result for a mined txid:
    [{
       "txid":"294cd1ebd5689fdee03509f92c32184c0f52f037d4046af250229b97e0c8f1aa",
       "blockhash":"000000000000000004b5ce6670f2ff27354a1e87d0a01bf61f3307f4ccd358b5",
       "blockheight":612251,
       "blocktime":1575841517,
       "confirmations":278272
     }]

result for a valid recent txid:
    [{"txid":"6815f8014db74eab8b7f75925c68929597f1d97efa970109d990824c25e5e62b"}]

result for an unknown txid:
    [{"txid":"6815f8014db74eab8b7f75925c68929597f1d97efa970109d990824c25e5e62c","error":"unknown"}]

```ts
async getStatusForTxids(txids: string[]): Promise<GetStatusForTxidsResult>
```
See also: [GetStatusForTxidsResult](./client.md#interface-getstatusfortxidsresult)

###### Method getTxPropagation

2025-02-16 throwing internal server error 500.

```ts
async getTxPropagation(txid: string): Promise<number>
```

###### Method postBeef

WhatsOnChain does not natively support a postBeef end-point aware of multiple txids of interest in the Beef.

Send rawTx in `txids` order from beef.

```ts
async postBeef(beef: Beef, txids: string[]): Promise<PostBeefResult>
```
See also: [PostBeefResult](./client.md#interface-postbeefresult)

###### Method postRawTx

```ts
async postRawTx(rawTx: HexString): Promise<PostTxResultForTxid>
```
See also: [PostTxResultForTxid](./client.md#interface-posttxresultfortxid)

Returns

txid returned by transaction processor of transaction broadcast

Argument Details

+ **rawTx**
  + raw transaction to broadcast as hex string

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
#### Functions

| | | |
| --- | --- | --- |
| [WalletErrorFromJson](#function-walleterrorfromjson) | [handleScriptHashHistoryCatch](#function-handlescripthashhistorycatch) | [resumeActionBatch](#function-resumeactionbatch) |
| [abortActionBatch](#function-abortactionbatch) | [handleScriptHashHistoryResponse](#function-handlescripthashhistoryresponse) | [reviewUtxoOutputs](#function-reviewutxooutputs) |
| [acquireDirectCertificate](#function-acquiredirectcertificate) | [handleUtxoConnReset](#function-handleutxoconnreset) | [safeDiagnostic](#function-safediagnostic) |
| [actionBatchBlobDigest](#function-actionbatchblobdigest) | [hasBrc177NoSendExpiryLabel](#function-hasbrc177nosendexpirylabel) | [sameSyncProof](#function-samesyncproof) |
| [actionBatchBootstrap](#function-actionbatchbootstrap) | [inputSourceTxid](#function-inputsourcetxid) | [selectBulkHeaderFiles](#function-selectbulkheaderfiles) |
| [actionBatchManifestDigest](#function-actionbatchmanifestdigest) | [internalizeAction](#function-internalizeaction) | [selectCanonicalChange](#function-selectcanonicalchange) |
| [actionBatchPackLength](#function-actionbatchpacklength) | [isArcAcceptedTxStatus](#function-isarcacceptedtxstatus) | [selectNoSendExpiryFundingAnchor](#function-selectnosendexpiryfundinganchor) |
| [activateNoSendExpiry](#function-activatenosendexpiry) | [isArcDoubleSpendTxStatus](#function-isarcdoublespendtxstatus) | [serializeBaseBlockHeader](#function-serializebaseblockheader) |
| [addPlannerOutputs](#function-addplanneroutputs) | [isArcInvalidTxStatus](#function-isarcinvalidtxstatus) | [serializeBaseBlockHeaders](#function-serializebaseblockheaders) |
| [addWork](#function-addwork) | [isArcServiceErrorStatus](#function-isarcserviceerrorstatus) | [setDisableDoubleSpendCheckForTest](#function-setdisabledoublespendcheckfortest) |
| [additionalFundingTarget](#function-additionalfundingtarget) | [isAutoSpendableChangeOutput](#function-isautospendablechangeoutput) | [setResultBeef](#function-setresultbeef) |
| [arcDefaultUrl](#function-arcdefaulturl) | [isBaseBlockHeader](#function-isbaseblockheader) | [sha256Hash](#function-sha256hash) |
| [arcGorillaPoolUrl](#function-arcgorillapoolurl) | [isBlockHeader](#function-isblockheader) | [sha256HashOfBinaryFile](#function-sha256hashofbinaryfile) |
| [arcadeDefaultUrl](#function-arcadedefaulturl) | [isCreateActionSpecOp](#function-iscreateactionspecop) | [shareReqsWithWorld](#function-sharereqswithworld) |
| [armNoSendExpiry](#function-armnosendexpiry) | [isKnownValidBulkHeaderFile](#function-isknownvalidbulkheaderfile) | [signAction](#function-signaction) |
| [arraysEqual](#function-arraysequal) | [isLegacyManagedChangeBasketDefault](#function-islegacymanagedchangebasketdefault) | [snapshotMerklePathResult](#function-snapshotmerklepathresult) |
| [asArray](#function-asarray) | [isListActionsSpecOp](#function-islistactionsspecop) | [snapshotPostBeefRequest](#function-snapshotpostbeefrequest) |
| [asBsvSdkPrivateKey](#function-asbsvsdkprivatekey) | [isListOutputsSpecOp](#function-islistoutputsspecop) | [stageTransactionOutputs](#function-stagetransactionoutputs) |
| [asBsvSdkPublickKey](#function-asbsvsdkpublickkey) | [isLive](#function-islive) | [stampLog](#function-stamplog) |
| [asBsvSdkScript](#function-asbsvsdkscript) | [isLiveBlockHeader](#function-isliveblockheader) | [stampLogFormat](#function-stamplogformat) |
| [asBsvSdkTx](#function-asbsvsdktx) | [isManagedChangeOutput](#function-ismanagedchangeoutput) | [stnArcadeUrl](#function-stnarcadeurl) |
| [asString](#function-asstring) | [isMoreWork](#function-ismorework) | [stnChaintracksUrl](#function-stnchaintracksurl) |
| [asUint8Array](#function-asuint8array) | [isValidFiatRate](#function-isvalidfiatrate) | [subWork](#function-subwork) |
| [assertAbortResult](#function-assertabortresult) | [keyOffsetToHashedSecret](#function-keyoffsettohashedsecret) | [supportedActionBatchPackEncodings](#function-supportedactionbatchpackencodings) |
| [assertInternalizeAccepted](#function-assertinternalizeaccepted) | [listCertificates](#function-listcertificates) | [swapByteOrder](#function-swapbyteorder) |
| [assertStorageMutationSucceeded](#function-assertstoragemutationsucceeded) | [lockScriptWithKeyOffsetFromPubKey](#function-lockscriptwithkeyoffsetfrompubkey) | [syncProofUpdatedAt](#function-syncproofupdatedat) |
| [assertSyncProofReplacementAuthorized](#function-assertsyncproofreplacementauthorized) | [lookupPreparedBeefs](#function-lookuppreparedbeefs) | [targetForStorage](#function-targetforstorage) |
| [attemptToPostReqsToNetwork](#function-attempttopostreqstonetwork) | [makeAtomicBeef](#function-makeatomicbeef) | [throwDummyReviewActions](#function-throwdummyreviewactions) |
| [authenticateMerklePathResult](#function-authenticatemerklepathresult) | [makeChangeLock](#function-makechangelock) | [toBinaryBaseBlockHeader](#function-tobinarybaseblockheader) |
| [availableManagedChange](#function-availablemanagedchange) | [makeMerklePathNote](#function-makemerklepathnote) | [toLookupNetworkPreset](#function-tolookupnetworkpreset) |
| [beefForTxids](#function-beeffortxids) | [makeNoSendExpiryFundingArgs](#function-makenosendexpiryfundingargs) | [toWalletNetwork](#function-towalletnetwork) |
| [beginActionBatch](#function-beginactionbatch) | [makePostBeefServiceError](#function-makepostbeefserviceerror) | [transactionInputSize](#function-transactioninputsize) |
| [blockHash](#function-blockhash) | [manifestPhysicalDigests](#function-manifestphysicaldigests) | [transactionOutputSize](#function-transactionoutputsize) |
| [brc177NoSendExpiryStateRank](#function-brc177nosendexpirystaterank) | [mapWithConcurrency](#function-mapwithconcurrency) | [transactionSize](#function-transactionsize) |
| [buildSignableTransaction](#function-buildsignabletransaction) | [markConfirmedStaleReqInputs](#function-markconfirmedstalereqinputs) | [tstnArcadeUrl](#function-tstnarcadeurl) |
| [canonicalizeAtomicBeef](#function-canonicalizeatomicbeef) | [markStaleInputsAsSpent](#function-markstaleinputsasspent) | [tstnChaintracksUrl](#function-tstnchaintracksurl) |
| [canonicalizeSyncProofIdentifiers](#function-canonicalizesyncproofidentifiers) | [markSyncProofInsertOnly](#function-marksyncproofinsertonly) | [updateChaintracksFiatExchangeRates](#function-updatechaintracksfiatexchangerates) |
| [classifyArcadeRejection](#function-classifyarcaderejection) | [markSyncProofReconciled](#function-marksyncproofreconciled) | [updateExchangeratesapi](#function-updateexchangeratesapi) |
| [classifyBroadcastInputSpendEvidence](#function-classifybroadcastinputspendevidence) | [markUserInputsSpent](#function-markuserinputsspent) | [updateReqsFromAggregateResults](#function-updatereqsfromaggregateresults) |
| [classifyMerklePathResponse](#function-classifymerklepathresponse) | [maxDate](#function-maxdate) | [upgradeLegacyManagedChangeBasketDefault](#function-upgradelegacymanagedchangebasketdefault) |
| [classifyOutputUtxo](#function-classifyoutpututxo) | [mergeInputBeefs](#function-mergeinputbeefs) | [validBulkHeaderFilesByFileHash](#function-validbulkheaderfilesbyfilehash) |
| [classifyReqStatus](#function-classifyreqstatus) | [mergeInputsIntoBeef](#function-mergeinputsintobeef) | [validateActionBatchInlinePayload](#function-validateactionbatchinlinepayload) |
| [cleanupExpiredActionBatches](#function-cleanupexpiredactionbatches) | [mergePlannerBeef](#function-mergeplannerbeef) | [validateActionBatchSendWith](#function-validateactionbatchsendwith) |
| [commitActionBatch](#function-commitactionbatch) | [normalizeArcProviderConfig](#function-normalizearcproviderconfig) | [validateAgainstDirtyHashes](#function-validateagainstdirtyhashes) |
| [commitActionBatchByDigest](#function-commitactionbatchbydigest) | [normalizeBulkFileDataValidationRequest](#function-normalizebulkfiledatavalidationrequest) | [validateArcadeTxData](#function-validatearcadetxdata) |
| [completeSignedTransaction](#function-completesignedtransaction) | [normalizeBulkHeaderFileInfo](#function-normalizebulkheaderfileinfo) | [validateBaseBlockHeaderFormat](#function-validatebaseblockheaderformat) |
| [compressActionBatchPack](#function-compressactionbatchpack) | [normalizeBulkHeaderFileSequence](#function-normalizebulkheaderfilesequence) | [validateBufferOfHeaders](#function-validatebufferofheaders) |
| [compressActionBatchPackItems](#function-compressactionbatchpackitems) | [normalizeBulkHeaderFilesInfo](#function-normalizebulkheaderfilesinfo) | [validateBulkFileData](#function-validatebulkfiledata) |
| [computeMerklePath](#function-computemerklepath) | [normalizeFiatCurrencies](#function-normalizefiatcurrencies) | [validateCompactManifest](#function-validatecompactmanifest) |
| [computeMerkleRoot](#function-computemerkleroot) | [normalizeFiatCurrency](#function-normalizefiatcurrency) | [validateGenerateChangeSdkParams](#function-validategeneratechangesdkparams) |
| [containsControlCharacter](#function-containscontrolcharacter) | [normalizeFiatExchangeRates](#function-normalizefiatexchangerates) | [validateGenerateChangeSdkResult](#function-validategeneratechangesdkresult) |
| [convertBitsToTarget](#function-convertbitstotarget) | [normalizeFiatRate](#function-normalizefiatrate) | [validateGenesisHeader](#function-validategenesisheader) |
| [convertBitsToWork](#function-convertbitstowork) | [normalizeFiatRateTimestamps](#function-normalizefiatratetimestamps) | [validateHeaderDifficulty](#function-validateheaderdifficulty) |
| [convertBufferToUint32](#function-convertbuffertouint32) | [normalizeFiatTimestamp](#function-normalizefiattimestamp) | [validateHeaderFormat](#function-validateheaderformat) |
| [convertProofToMerklePath](#function-convertprooftomerklepath) | [normalizeMonitorIdentityKey](#function-normalizemonitoridentitykey) | [validateHeaderProofOfWork](#function-validateheaderproofofwork) |
| [convertUint32ToBuffer](#function-convertuint32tobuffer) | [normalizePostRawHex](#function-normalizepostrawhex) | [validateManagedChangePolicy](#function-validatemanagedchangepolicy) |
| [convertWocToBlockHeaderHex](#function-convertwoctoblockheaderhex) | [normalizePostTxids](#function-normalizeposttxids) | [validateManifestActions](#function-validatemanifestactions) |
| [copyMonitorTags](#function-copymonitortags) | [normalizeTxid](#function-normalizetxid) | [validateMerklePathResult](#function-validatemerklepathresult) |
| [copyRawTransactionBytes](#function-copyrawtransactionbytes) | [normalizeWalletOutpoint](#function-normalizewalletoutpoint) | [validateMonitorOptions](#function-validatemonitoroptions) |
| [copyValidatedBlockHeader](#function-copyvalidatedblockheader) | [notifyTransactionsOfProof](#function-notifytransactionsofproof) | [validateNoSendExpiryRequest](#function-validatenosendexpiryrequest) |
| [copyValidatedMonitorHeader](#function-copyvalidatedmonitorheader) | [offsetPrivKey](#function-offsetprivkey) | [validatePostBeefResult](#function-validatepostbeefresult) |
| [createAction](#function-createaction) | [offsetPubKey](#function-offsetpubkey) | [validatePostBeefResultOrServiceError](#function-validatepostbeefresultorserviceerror) |
| [createCoinbaseTransaction](#function-createcoinbasetransaction) | [optionalArraysEqual](#function-optionalarraysequal) | [validatePostTxResult](#function-validateposttxresult) |
| [createDefaultChaintracksClient](#function-createdefaultchaintracksclient) | [optionalMonitorInteger](#function-optionalmonitorinteger) | [validatePostTxResultOrServiceError](#function-validateposttxresultorserviceerror) |
| [createDefaultWalletServicesOptions](#function-createdefaultwalletservicesoptions) | [parseBrc177NoSendExpiryLabels](#function-parsebrc177nosendexpirylabels) | [validatePreparedBeefPolicy](#function-validatepreparedbeefpolicy) |
| [createNoSendExpiryAction](#function-createnosendexpiryaction) | [parseResults$](#function-parseresults$) | [validateRawTxResult](#function-validaterawtxresult) |
| [createStorageServiceChargeScript](#function-createstorageservicechargescript) | [parseTxScriptOffsets](#function-parsetxscriptoffsets) | [validateRequiredInputs](#function-validaterequiredinputs) |
| [createSyncMap](#function-createsyncmap) | [planAction](#function-planaction) | [validateRequiredOutputs](#function-validaterequiredoutputs) |
| [decodeActionBatchPack](#function-decodeactionbatchpack) | [plannerInputLockingScript](#function-plannerinputlockingscript) | [validateScriptHash](#function-validatescripthash) |
| [decompressActionBatchPack](#function-decompressactionbatchpack) | [plannerOutputLockingScript](#function-planneroutputlockingscript) | [validateScriptHashHistoryResult](#function-validatescripthashhistoryresult) |
| [defaultManagedChangePolicy](#function-defaultmanagedchangepolicy) | [populateUtxoDetails](#function-populateutxodetails) | [validateSecondsSinceEpoch](#function-validatesecondssinceepoch) |
| [defaultPreparedBeefPolicy](#function-defaultpreparedbeefpolicy) | [prepareActionBatchCommit](#function-prepareactionbatchcommit) | [validateStatusForTxidsResult](#function-validatestatusfortxidsresult) |
| [deserializeBaseBlockHeader](#function-deserializebaseblockheader) | [prepareNoSendExpiry](#function-preparenosendexpiry) | [validateStorageFeeModel](#function-validatestoragefeemodel) |
| [deserializeBaseBlockHeaders](#function-deserializebaseblockheaders) | [processAction](#function-processaction) | [validateSyncCheckpoint](#function-validatesynccheckpoint) |
| [deserializeBlockHeader](#function-deserializeblockheader) | [processNoSendExpiryLifecycle](#function-processnosendexpirylifecycle) | [validateSyncProof](#function-validatesyncproof) |
| [deserializeBlockHeaders](#function-deserializeblockheaders) | [proofOfWorkLimitBits](#function-proofofworklimitbits) | [validateTrustSettings](#function-validatetrustsettings) |
| [doubleSha256BE](#function-doublesha256be) | [proveCertificate](#function-provecertificate) | [validateUtxoStatusResult](#function-validateutxostatusresult) |
| [doubleSha256LE](#function-doublesha256le) | [pruneBeefForTxids](#function-prunebeeffortxids) | [validateWalletSettings](#function-validatewalletsettings) |
| [encodeActionBatchPack](#function-encodeactionbatchpack) | [publicArcadeUrl](#function-publicarcadeurl) | [validateWocChainInfo](#function-validatewocchaininfo) |
| [extendActionBatch](#function-extendactionbatch) | [putActionBatchBlob](#function-putactionbatchblob) | [varUintSize](#function-varuintsize) |
| [filterCertificatesByAttributes](#function-filtercertificatesbyattributes) | [putActionBatchPack](#function-putactionbatchpack) | [verifyActionBatchManifestDigest](#function-verifyactionbatchmanifestdigest) |
| [filterCertificatesByIdentityKey](#function-filtercertificatesbyidentitykey) | [quarantineReqInputs](#function-quarantinereqinputs) | [verifyHexString](#function-verifyhexstring) |
| [fundingRunwayExtension](#function-fundingrunwayextension) | [quarantineReqInputsFromFailedParents](#function-quarantinereqinputsfromfailedparents) | [verifyId](#function-verifyid) |
| [generateChangeSdk](#function-generatechangesdk) | [randomBytes](#function-randombytes) | [verifyInteger](#function-verifyinteger) |
| [generateChangeSdkMakeStorage](#function-generatechangesdkmakestorage) | [randomBytesBase64](#function-randombytesbase64) | [verifyNumber](#function-verifynumber) |
| [genesisBuffer](#function-genesisbuffer) | [randomBytesHex](#function-randombyteshex) | [verifyOne](#function-verifyone) |
| [genesisHeader](#function-genesisheader) | [randomizeOutputVouts](#function-randomizeoutputvouts) | [verifyOneOrNone](#function-verifyoneornone) |
| [getActionBatchCapabilities](#function-getactionbatchcapabilities) | [rawTransactionBytes](#function-rawtransactionbytes) | [verifyOptionalHexString](#function-verifyoptionalhexstring) |
| [getBeefForTransaction](#function-getbeeffortransaction) | [readUInt32BE](#function-readuint32be) | [verifyRequestedOutputsUnchanged](#function-verifyrequestedoutputsunchanged) |
| [getBeefForTransactions](#function-getbeeffortransactions) | [readUInt32LE](#function-readuint32le) | [verifyTruthy](#function-verifytruthy) |
| [getBeefForTxid](#function-getbeeffortxid) | [redeemServiceCharges](#function-redeemservicecharges) | [verifyUnlockScripts](#function-verifyunlockscripts) |
| [getExchangeRatesIo](#function-getexchangeratesio) | [regtestArcadeUrl](#function-regtestarcadeurl) | [verifyUnlockScriptsBatch](#function-verifyunlockscriptsbatch) |
| [getIdentityKey](#function-getidentitykey) | [regtestChaintracksUrl](#function-regtestchaintracksurl) | [verifyUnrequestedOutputsAreChangeOrCommission](#function-verifyunrequestedoutputsarechangeorcommission) |
| [getProofs](#function-getproofs) | [renewActionBatch](#function-renewactionbatch) | [wait](#function-wait) |
| [getResultBeef](#function-getresultbeef) | [repeatableRandom](#function-repeatablerandom) | [workBNtoBuffer](#function-workbntobuffer) |
| [getSyncChunk](#function-getsyncchunk) | [requireConclusiveUtxo](#function-requireconclusiveutxo) | [writeUInt32BE](#function-writeuint32be) |
| [getWhatsOnChainBlockHeaderByHash](#function-getwhatsonchainblockheaderbyhash) | [requireMonitorInteger](#function-requiremonitorinteger) | [writeUInt32LE](#function-writeuint32le) |
| [handlePostRawTxErrorResponse](#function-handlepostrawtxerrorresponse) | [restoreInputsToSpendable](#function-restoreinputstospendable) |  |

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---

##### Function: WalletErrorFromJson

Reconstruct the correct derived WalletError from a JSON object created by `WalletError.unknownToJson`.

This function is implemented as a separate function instead of a WalletError class static
to avoid circular dependencies.

```ts
export function WalletErrorFromJson(json: object): WalletError
```

See also: [WalletError](./client.md#class-walleterror)

Returns

a WalletError derived error object, typically for re-throw.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: abortActionBatch

```ts
export async function abortActionBatch(storage: StorageProvider, auth: AuthId, batchId: string): Promise<AbortActionBatchResult>
```

See also: [AbortActionBatchResult](./client.md#interface-abortactionbatchresult), [AuthId](./client.md#interface-authid), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: acquireDirectCertificate

```ts
export async function acquireDirectCertificate(wallet: Wallet, auth: AuthId, vargs: Validation.ValidAcquireDirectCertificateArgs): Promise<AcquireCertificateResult>
```

See also: [AuthId](./client.md#interface-authid), [Wallet](./client.md#class-wallet)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: actionBatchBlobDigest

```ts
export function actionBatchBlobDigest(bytes: number[] | Uint8Array): string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: actionBatchBootstrap

Removes large values that are uploaded through the content-addressed commit
path later. Older version-1 providers receive the original request unless
they explicitly advertise compact bootstrap support.

```ts
export function actionBatchBootstrap(args: Validation.ValidCreateActionArgs, capabilities: NonNullable<StorageCapabilities["actionBatch"]>): ActionBatchBootstrap
```

See also: [StorageCapabilities](./client.md#interface-storagecapabilities)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: actionBatchManifestDigest

Digest only the semantic manifest. Inline bytes are represented by their
content digest so inline and uploaded forms have the same idempotency key.

```ts
export function actionBatchManifestDigest(manifest: Omit<ActionBatchManifest, "digest">): string
```

See also: [ActionBatchManifest](./client.md#interface-actionbatchmanifest)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: actionBatchPackLength

```ts
export function actionBatchPackLength(items: ActionBatchPackItem[]): number
```

See also: [ActionBatchPackItem](./client.md#interface-actionbatchpackitem)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: activateNoSendExpiry

```ts
export async function activateNoSendExpiry(storage: StorageProvider, auth: AuthId, args: StorageActivateNoSendExpiryArgs): Promise<StorageActivateNoSendExpiryResult>
```

See also: [AuthId](./client.md#interface-authid), [StorageActivateNoSendExpiryArgs](./client.md#interface-storageactivatenosendexpiryargs), [StorageActivateNoSendExpiryResult](./client.md#interface-storageactivatenosendexpiryresult), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: addPlannerOutputs

```ts
export function addPlannerOutputs(target: Map<string, PlannerOutput>, outputs: ActionBatchFundingOutput[], basketName?: string): void
```

See also: [ActionBatchFundingOutput](./client.md#interface-actionbatchfundingoutput), [PlannerOutput](./client.md#interface-planneroutput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: addWork

Add two Buffer encoded chainwork values

```ts
export function addWork(work1: string, work2: string): string
```

Returns

Sum of work1 + work2 as Buffer encoded chainWork value

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: additionalFundingTarget

```ts
export function additionalFundingTarget(error: WERR_INSUFFICIENT_FUNDS): number
```

See also: [WERR_INSUFFICIENT_FUNDS](./client.md#class-werr_insufficient_funds)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: arcDefaultUrl

```ts
export function arcDefaultUrl(chain: Chain): string
```

See also: [Chain](./client.md#type-chain)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: arcGorillaPoolUrl

```ts
export function arcGorillaPoolUrl(chain: Chain): string | undefined
```

See also: [Chain](./client.md#type-chain)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: arcadeDefaultUrl

Default Arcade (bsv-blockchain/arcade) endpoint per chain.
Returns undefined when no public default is known for the chain.

```ts
export function arcadeDefaultUrl(chain: Chain): string | undefined
```

See also: [Chain](./client.md#type-chain)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: armNoSendExpiry

```ts
export async function armNoSendExpiry(storage: StorageProvider, auth: AuthId, args: StorageArmNoSendExpiryArgs): Promise<void>
```

See also: [AuthId](./client.md#interface-authid), [StorageArmNoSendExpiryArgs](./client.md#interface-storagearmnosendexpiryargs), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: arraysEqual

Compares lengths and direct equality of values.

```ts
export function arraysEqual(arr1: number[], arr2: number[]): boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: asArray

Convert a value to number[] if currently an encoded string or number[] or Uint8Array.

```ts
export function asArray(val: ByteInput, enc?: ByteEncoding): number[] {
    if (Array.isArray(val))
        return val;
    if (typeof val !== "string")
        return Array.from(val);
    enc ||= "hex";
    const a: number[] = Utils.toArray(val, enc);
    return a;
}
```

See also: [ByteEncoding](./client.md#type-byteencoding), [ByteInput](./client.md#type-byteinput)

Returns

number[] array of byte values representation of val.

Argument Details

+ **val**
  + string or number[] or Uint8Array. If string, encoding must be hex. If number[], each value must be 0..255.
+ **enc**
  + optional encoding type if val is string, defaults to 'hex'. Can be 'hex', 'utf8', or 'base64'.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: asBsvSdkPrivateKey

```ts
export function asBsvSdkPrivateKey(privKey: string): PrivateKey
```

Argument Details

+ **privKey**
  + bitcoin private key in 32 byte hex string form

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: asBsvSdkPublickKey

```ts
export function asBsvSdkPublickKey(pubKey: string): PublicKey
```

Argument Details

+ **pubKey**
  + bitcoin public key in standard compressed key hex string form

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: asBsvSdkScript

Coerce a bsv script encoded as a hex string, serialized array, or Script to Script
If script is already a Script, just return it.

```ts
export function asBsvSdkScript(script: HexString | number[] | Script): Script {
    if (Array.isArray(script)) {
        script = Script.fromBinary(script);
    }
    else if (typeof script === "string") {
        script = Script.fromHex(script);
    }
    return script;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: asBsvSdkTx

Coerce a bsv transaction encoded as a hex string, serialized array, or Transaction to Transaction
If tx is already a Transaction, just return it.

```ts
export function asBsvSdkTx(tx: HexString | number[] | Transaction): Transaction {
    if (Array.isArray(tx)) {
        tx = Transaction.fromBinary(tx);
    }
    else if (typeof tx === "string") {
        tx = Transaction.fromHex(tx);
    }
    return tx;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: asString

Convert a value to an encoded string if currently an encoded string or number[] or Uint8Array.

```ts
export function asString(val: ByteInput, enc?: ByteEncoding, returnEnc?: ByteEncoding): string {
    enc ||= "hex";
    returnEnc ||= enc;
    if (typeof val === "string") {
        if (enc === returnEnc)
            return val;
        val = asUint8Array(val, enc);
    }
    const v = Array.isArray(val) ? val : Array.from(val);
    switch (returnEnc) {
        case "utf8":
            return Utils.toUTF8(v);
        case "base64":
            return Utils.toBase64(v);
    }
    return Utils.toHex(v);
}
```

See also: [ByteEncoding](./client.md#type-byteencoding), [ByteInput](./client.md#type-byteinput), [asUint8Array](./client.md#function-asuint8array)

Returns

hex encoded string representation of val.

Argument Details

+ **val**
  + string or number[] or Uint8Array. If string, encoding must be hex. If number[], each value must be 0..255.
+ **enc**
  + optional encoding type if val is string, defaults to 'hex'. Can be 'hex', 'utf8', or 'base64'.
+ **returnEnc**
  + optional encoding type for returned string if different from `enc`, defaults to 'hex'. Can be 'hex', 'utf8', or 'base64'.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: asUint8Array

Convert a value to Uint8Array if currently an encoded string or number[] or Uint8Array.

```ts
export function asUint8Array(val: ByteInput, enc?: ByteEncoding): Uint8Array {
    if (Array.isArray(val))
        return Uint8Array.from(val);
    if (typeof val !== "string")
        return val;
    enc ||= "hex";
    return Utils.toUint8Array(val, enc);
}
```

See also: [ByteEncoding](./client.md#type-byteencoding), [ByteInput](./client.md#type-byteinput)

Returns

Uint8Array representation of val.

Argument Details

+ **val**
  + string or number[] or Uint8Array. If string, encoding must be hex. If number[], each value must be 0..255.
+ **enc**
  + optional encoding type if val is string, defaults to 'hex'. Can be 'hex', 'utf8', or 'base64'.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: assertAbortResult

Preserve a legitimate abort refusal while rejecting malformed remote storage results.

```ts
export function assertAbortResult(result: {
    aborted?: unknown;
}): asserts result is {
    aborted: boolean;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: assertInternalizeAccepted

Reject runtime-negative or malformed results from local or remote wallet storage.

```ts
export function assertInternalizeAccepted(result: {
    accepted?: unknown;
    isMerge?: unknown;
}): void
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: assertStorageMutationSucceeded

Require a unique storage row to have been changed before reporting public success.

```ts
export function assertStorageMutationSucceeded(result: unknown, operation: string): void
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: assertSyncProofReplacementAuthorized

Enforce the pre-transaction proof decision again at the entity merge point.
This closes the race where another process inserts the txid after preflight.

```ts
export function assertSyncProofReplacementAuthorized(candidate: TableProvenTx): void
```

See also: [TableProvenTx](./storage.md#interface-tableproventx)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: attemptToPostReqsToNetwork

Attempt to post one or more `ProvenTxReq` with status 'unsent'
to the bitcoin network.

```ts
export async function attemptToPostReqsToNetwork(storage: StorageProvider, reqs: EntityProvenTxReq[], trx?: sdk.TrxToken, logger?: WalletLoggerInterface): Promise<PostReqsToNetworkResult>
```

See also: [EntityProvenTxReq](./storage.md#class-entityproventxreq), [PostReqsToNetworkResult](./storage.md#interface-postreqstonetworkresult), [StorageProvider](./storage.md#class-storageprovider), [TrxToken](./client.md#interface-trxtoken), [logger](./client.md#variable-logger)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: authenticateMerklePathResult

```ts
export async function authenticateMerklePathResult(requestedTxid: unknown, result: GetMerklePathResult, validator: MerkleRootValidator, requireProofOfWork = false, requireHeaderFormat = true, chain?: Chain): Promise<ValidatedMerklePathResult>
```

See also: [Chain](./client.md#type-chain), [GetMerklePathResult](./client.md#interface-getmerklepathresult), [MerkleRootValidator](./services.md#interface-merklerootvalidator), [ValidatedMerklePathResult](./services.md#interface-validatedmerklepathresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: availableManagedChange

Return the exact set of wallet-managed outputs currently eligible for
automatic funding. Keeping this predicate shared prevents the planner,
allocator, action-batch reservations, and availability count from drifting.

```ts
export async function availableManagedChange(storage: StorageProvider, userId: number, basketId: number, excludeSending: boolean, trx?: TrxToken): Promise<TableOutput[]>
```

See also: [StorageProvider](./storage.md#class-storageprovider), [TableOutput](./storage.md#interface-tableoutput), [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: beefForTxids

Return an independent minimal BEEF needed to prove the requested transactions.

Transactions remain in source order and are sorted by Beef when serialized.
The source is indexed and walked once, using an explicit stack so a hostile
dependency depth cannot exhaust the JavaScript call stack.

```ts
export function beefForTxids(source: Beef, txids: string[]): Beef
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: beginActionBatch

```ts
export async function beginActionBatch(storage: StorageProvider, auth: AuthId, args: BeginActionBatchArgs): Promise<BeginActionBatchResult>
```

See also: [AuthId](./client.md#interface-authid), [BeginActionBatchArgs](./client.md#interface-beginactionbatchargs), [BeginActionBatchResult](./client.md#interface-beginactionbatchresult), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: blockHash

Computes double sha256 hash of bitcoin block header
bytes are reversed to bigendian order

If header is a Buffer, it is required to 80 bytes long
and in standard block header serialized encoding.

```ts
export function blockHash(header: BaseBlockHeader | number[] | Uint8Array): string {
    const a = !Array.isArray(header) && !(header instanceof Uint8Array) ? serializeBaseBlockHeader(header) : header;
    if (a.length !== 80)
        throw new Error("Block header must be 80 bytes long.");
    return asString(doubleSha256BE(a));
}
```

See also: [BaseBlockHeader](./client.md#interface-baseblockheader), [asString](./client.md#function-asstring), [doubleSha256BE](./client.md#function-doublesha256be), [serializeBaseBlockHeader](./services.md#function-serializebaseblockheader)

Returns

doule sha256 hash of header bytes reversed

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: brc177NoSendExpiryStateRank

Orders durable lifecycle states by safety progress for cross-storage merge.
A newer wall-clock timestamp must never revive a state from which a signed
target could escape expiry enforcement.

```ts
export function brc177NoSendExpiryStateRank(state: Brc177NoSendExpiryState | undefined): number
```

See also: [Brc177NoSendExpiryState](./client.md#type-brc177nosendexpirystate)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: buildSignableTransaction

```ts
export function buildSignableTransaction(dctr: StorageCreateActionResult, args: Validation.ValidCreateActionArgs, wallet: Wallet): {
    tx: Transaction;
    amount: number;
    pdi: PendingStorageInput[];
    log: string;
}
```

See also: [PendingStorageInput](./client.md#interface-pendingstorageinput), [StorageCreateActionResult](./client.md#interface-storagecreateactionresult), [Wallet](./client.md#class-wallet)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: canonicalizeAtomicBeef

Restricts an AtomicBEEF envelope to the transaction named by its BRC-95
prefix and that transaction's recursive dependency closure.

Older senders could serialize unrelated, otherwise valid BEEF branches into
an AtomicBEEF envelope. Those branches are not part of the payment proof and
must not influence internalization. Proof and transaction validation still
run against the returned closure at each wallet trust boundary.

```ts
export function canonicalizeAtomicBeef(bytes: number[] | Uint8Array): Beef
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: canonicalizeSyncProofIdentifiers

Normalize text-key identifiers before lookup or persistence.

```ts
export function canonicalizeSyncProofIdentifiers(candidate: TableProvenTx): void
```

See also: [TableProvenTx](./storage.md#interface-tableproventx)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: classifyArcadeRejection

Canonical classification shared by Arcade polling and SSE. Keeping this in
one place prevents a provider from calling a rejection "unknown" while the
monitor's event path calls the same status terminal.

```ts
export function classifyArcadeRejection(event: ArcadeLifecycleStatus): ArcadeRejectionClassification
```

See also: [ArcadeLifecycleStatus](./services.md#interface-arcadelifecyclestatus), [ArcadeRejectionClassification](./services.md#interface-arcaderejectionclassification)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: classifyBroadcastInputSpendEvidence

```ts
export async function classifyBroadcastInputSpendEvidence(tx: Transaction, beef: Beef, services: Pick<sdk.WalletServices, "hashOutputScript" | "getUtxoStatus">): Promise<{
    spent: number;
    unspent: number;
    unknown: number;
}>
```

See also: [WalletServices](./client.md#interface-walletservices)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: classifyMerklePathResponse

Classify a non-OK status response for getMerklePath.

Returns `'retry'` when the request was rate-limited and the caller should retry,
`'notFound'` for 404, `'badStatus'` for other non-200 codes.

```ts
export function classifyMerklePathResponse(status: number, statusText: string, retry: number): "retry" | "notFound" | "badStatus" | "ok"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: classifyOutputUtxo

Classify an output without ever converting provider absence or failure into
positive spent evidence. This helper deliberately catches provider throws so
batch callers can finish classifying every candidate before deciding whether
a destructive operation is safe.

```ts
export async function classifyOutputUtxo(services: UtxoServices, output: TableOutput): Promise<OutputUtxoClassification>
```

See also: [OutputUtxoClassification](./services.md#interface-outpututxoclassification), [TableOutput](./storage.md#interface-tableoutput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: classifyReqStatus

Classify a ProvenTxReq status into beef-sharing lifecycle status.
Mutates `d` in place.

```ts
export function classifyReqStatus(d: GetReqsAndBeefDetail, req: TableProvenTxReq): void
```

See also: [GetReqsAndBeefDetail](./storage.md#interface-getreqsandbeefdetail), [TableProvenTxReq](./storage.md#interface-tableproventxreq)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: cleanupExpiredActionBatches

```ts
export async function cleanupExpiredActionBatches(storage: StorageProvider): Promise<number>
```

See also: [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: commitActionBatch

```ts
export async function commitActionBatch(storage: StorageProvider, auth: AuthId, manifest: ActionBatchManifest): Promise<CommitActionBatchResult>
```

See also: [ActionBatchManifest](./client.md#interface-actionbatchmanifest), [AuthId](./client.md#interface-authid), [CommitActionBatchResult](./client.md#interface-commitactionbatchresult), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: commitActionBatchByDigest

```ts
export async function commitActionBatchByDigest(storage: StorageProvider, auth: AuthId, args: CommitActionBatchByDigestArgs): Promise<CommitActionBatchResult>
```

See also: [AuthId](./client.md#interface-authid), [CommitActionBatchByDigestArgs](./client.md#interface-commitactionbatchbydigestargs), [CommitActionBatchResult](./client.md#interface-commitactionbatchresult), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: completeSignedTransaction

```ts
export async function completeSignedTransaction(prior: PendingSignAction, spends: Record<number, SignActionSpend>, wallet: Wallet): Promise<Transaction>
```

See also: [PendingSignAction](./client.md#interface-pendingsignaction), [Wallet](./client.md#class-wallet)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: compressActionBatchPack

```ts
export async function compressActionBatchPack(bytes: Uint8Array, encoding: ActionBatchPackEncoding): Promise<Uint8Array>
```

See also: [ActionBatchPackEncoding](./client.md#type-actionbatchpackencoding)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: compressActionBatchPackItems

Compress a pack directly from its item views. Successful compression avoids
allocating and copying an additional uncompressed aggregate frame.

```ts
export async function compressActionBatchPackItems(items: ActionBatchPackItem[], encoding: ActionBatchPackEncoding, maxBytes: number, maxItems: number): Promise<Uint8Array>
```

See also: [ActionBatchPackEncoding](./client.md#type-actionbatchpackencoding), [ActionBatchPackItem](./client.md#interface-actionbatchpackitem)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: computeMerklePath

Compute the MerklePath for a target transaction at `targetIndex` within a block at `blockHeight`.
`txids` is the ordered list of all txids in the block (big-endian hex).

```ts
export function computeMerklePath(txids: string[], targetIndex: number, blockHeight: number): MerklePath
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: computeMerkleRoot

Compute the merkle root from an array of txids (big-endian hex strings).
Returns the root as a big-endian hex string (reversed byte order from the
natural double-SHA256 result, matching the standard block header format).

```ts
export function computeMerkleRoot(txids: string[]): string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: containsControlCharacter

```ts
export function containsControlCharacter(value: string): boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: convertBitsToTarget

Computes "target" value for 4 byte Bitcoin block header "bits" value.

```ts
export function convertBitsToTarget(bits: number | number[]): BigNumber
```

Returns

32 byte Buffer with "target" value

Argument Details

+ **bits**
  + number or converted from Buffer using `readUint32LE`

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: convertBitsToWork

Computes "chainWork" value for 4 byte Bitcoin block header "bits" value.

```ts
export function convertBitsToWork(bits: number | number[], chain?: Chain): string
```

See also: [Chain](./client.md#type-chain)

Returns

32 byte Buffer with "chainWork" value

Argument Details

+ **bits**
  + number or converted from Buffer using `readUint32LE`
+ **chain**
  + Optional chain the header belongs to. Selects its proof-of-work limit
(see `proofOfWorkLimitBits`); omitted means the mainnet limit.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: convertBufferToUint32

```ts
export function convertBufferToUint32(buffer: number[] | Uint8Array, littleEndian = true): number {
    validateByteWindow(buffer, 0, 4);
    if (buffer.length !== 4)
        throw new WERR_INVALID_PARAMETER("buffer", "exactly four bytes");
    if (typeof littleEndian !== "boolean")
        throw new WERR_INVALID_PARAMETER("littleEndian", "a boolean");
    const a = littleEndian ? buffer : buffer.slice().reverse();
    const n = (a[0] | (a[1] << 8) | (a[2] << 16) | (a[3] << 24)) >>> 0;
    return n;
}
```

See also: [WERR_INVALID_PARAMETER](./client.md#class-werr_invalid_parameter)

Returns

a number value in the Uint32 value range

Argument Details

+ **buffer**
  + four byte buffer with Uint32 number encoded
+ **littleEndian**
  + true for little-endian byte order in Buffer

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: convertProofToMerklePath

```ts
export function convertProofToMerklePath(txid: string, proof: TscMerkleProofApi): MerklePath
```

See also: [TscMerkleProofApi](./client.md#interface-tscmerkleproofapi)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: convertUint32ToBuffer

```ts
export function convertUint32ToBuffer(n: number, littleEndian = true): number[] {
    validateUnsignedHeaderInteger(n, "uint32", UINT32_MAX);
    if (typeof littleEndian !== "boolean")
        throw new WERR_INVALID_PARAMETER("littleEndian", "a boolean");
    const a = [
        n & 255,
        (n >> 8) & 255,
        (n >> 16) & 255,
        (n >> 24) & 255
    ];
    return littleEndian ? a : a.reverse();
}
```

See also: [WERR_INVALID_PARAMETER](./client.md#class-werr_invalid_parameter)

Returns

four byte buffer with Uint32 number encoded

Argument Details

+ **num**
  + a number value in the Uint32 value range
+ **littleEndian**
  + true for little-endian byte order in Buffer

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: convertWocToBlockHeaderHex

```ts
export function convertWocToBlockHeaderHex(woc: WocHeader): BlockHeader
```

See also: [BlockHeader](./client.md#interface-blockheader), [WocHeader](./services.md#interface-wocheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: copyMonitorTags

```ts
export function copyMonitorTags(value: unknown, name = "tags"): string[]
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: copyRawTransactionBytes

```ts
export function copyRawTransactionBytes(value: unknown, name = "rawTx"): number[]
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: copyValidatedBlockHeader

```ts
export function copyValidatedBlockHeader(value: unknown, requireProofOfWork = false, requireHeaderFormat = true, chain?: Chain): BlockHeader
```

See also: [BlockHeader](./client.md#interface-blockheader), [Chain](./client.md#type-chain)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: copyValidatedMonitorHeader

```ts
export function copyValidatedMonitorHeader(value: unknown, name = "header", requireProofOfWork = true, chain?: Chain): BlockHeader
```

See also: [BlockHeader](./client.md#interface-blockheader), [Chain](./client.md#type-chain)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: createAction

```ts
export async function createAction(storage: StorageProvider, auth: AuthId, vargs: Validation.ValidCreateActionArgs, _originator?: OriginatorDomainNameStringUnder250Bytes): Promise<StorageCreateActionResult>
```

See also: [AuthId](./client.md#interface-authid), [StorageCreateActionResult](./client.md#interface-storagecreateactionresult), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: createAction

```ts
export async function createAction(wallet: Wallet, auth: AuthId, vargs: Validation.ValidCreateActionArgs): Promise<CreateActionResultX>
```

See also: [AuthId](./client.md#interface-authid), [CreateActionResultX](./client.md#interface-createactionresultx), [Wallet](./client.md#class-wallet)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: createCoinbaseTransaction

Creates a coinbase transaction for the given block height.
Uses OP_TRUE (0x51) as the output script so anyone can spend it.

```ts
export function createCoinbaseTransaction(height: number): Transaction
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: createDefaultChaintracksClient

Returns the credential-free default ChainTracks client for a supported
public network, or an operator-configured client for stn/tstn.

BROWSER RUNTIMES get the legacy CORS-enabled Chaintracks service for
main/test. The Go Chaintracks deployments (`arcade-v2-*.bsvblockchain.tech`)
currently serve no `Access-Control-Allow-Origin` header and answer OPTIONS
preflights with 404 (verified live 2026-08-11), so every fetch from a
browser-hosted wallet is CORS-blocked (WebKit surfaces it as
`TypeError: Load failed`) and the wallet loses `getHeight`, headers and
merkle-root validation wholesale. The repository service contract
(AGENTS.md: "browser, mobile, and unknown-domain clients must not be
silently blocked by CORS") requires a default that browsers can actually
reach. Once the Go deployments serve CORS (and a browser-run conformance
check proves it), this branch can be removed and browsers can share the v2
default. Node runtimes are unchanged.

```ts
export function createDefaultChaintracksClient(chain: Exclude<Chain, "mock">): ChaintracksClientApi
```

See also: [Chain](./client.md#type-chain), [ChaintracksClientApi](./services.md#interface-chaintracksclientapi)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: createDefaultWalletServicesOptions

```ts
export function createDefaultWalletServicesOptions(...[chain, arcCallbackUrl, arcCallbackToken, taalArcApiKey, gorillaPoolArcApiKey, bitailsApiKey, deploymentId, chaintracks, arcadeUrl, arcadeApiKey, arcadeCallbackToken]: [
    chain: Chain,
    arcCallbackUrl?: string,
    arcCallbackToken?: string,
    taalArcApiKey?: string,
    gorillaPoolArcApiKey?: string,
    bitailsApiKey?: string,
    deploymentId?: string,
    chaintracks?: ChaintracksClientApi,
    arcadeUrl?: string,
    arcadeApiKey?: string,
    arcadeCallbackToken?: string
]): WalletServicesOptions
```

See also: [Chain](./client.md#type-chain), [ChaintracksClientApi](./services.md#interface-chaintracksclientapi), [WalletServicesOptions](./client.md#interface-walletservicesoptions)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: createNoSendExpiryAction

```ts
export async function createNoSendExpiryAction(wallet: Wallet, auth: AuthId, vargs: Validation.ValidCreateActionArgs): Promise<CreateActionResultX>
```

See also: [AuthId](./client.md#interface-authid), [CreateActionResultX](./client.md#interface-createactionresultx), [Wallet](./client.md#class-wallet)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: createStorageServiceChargeScript

```ts
export function createStorageServiceChargeScript(pubKeyHex: PubKeyHex): {
    script: string;
    keyOffset: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: createSyncMap

```ts
export function createSyncMap(): SyncMap
```

See also: [SyncMap](./storage.md#interface-syncmap)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: decodeActionBatchPack

Decode a transport frame without copying its individual blob payloads.

```ts
export function decodeActionBatchPack(bytes: Uint8Array, maxBytes: number, maxItems: number): ActionBatchPackItem[]
```

See also: [ActionBatchPackItem](./client.md#interface-actionbatchpackitem)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: decompressActionBatchPack

```ts
export async function decompressActionBatchPack(bytes: Uint8Array, encoding: ActionBatchPackEncoding, maxBytes: number): Promise<Uint8Array>
```

See also: [ActionBatchPackEncoding](./client.md#type-actionbatchpackencoding)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: defaultManagedChangePolicy

```ts
export function defaultManagedChangePolicy(): ManagedChangePolicy
```

See also: [ManagedChangePolicy](./storage.md#interface-managedchangepolicy)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: defaultPreparedBeefPolicy

```ts
export function defaultPreparedBeefPolicy(): PreparedBeefPolicy
```

See also: [PreparedBeefPolicy](./storage.md#interface-preparedbeefpolicy)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: deserializeBaseBlockHeader

Deserialize a BaseBlockHeader from an 80 byte buffer

```ts
export function deserializeBaseBlockHeader(buffer: number[] | Uint8Array, offset = 0): BaseBlockHeader {
    validateByteWindow(buffer, offset, 80);
    const reader = Utils.ReaderUint8Array.makeReader(buffer, offset);
    const header: BaseBlockHeader = {
        version: reader.readUInt32LE(),
        previousHash: asString(reader.read(32).reverse()),
        merkleRoot: asString(reader.read(32).reverse()),
        time: reader.readUInt32LE(),
        bits: reader.readUInt32LE(),
        nonce: reader.readUInt32LE()
    };
    return header;
}
```

See also: [BaseBlockHeader](./client.md#interface-baseblockheader), [asString](./client.md#function-asstring), [readUInt32LE](./services.md#function-readuint32le)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: deserializeBaseBlockHeaders

```ts
export function deserializeBaseBlockHeaders(buffer: number[] | Uint8Array, offset = 0, count?: number | undefined): BaseBlockHeader[]
```

See also: [BaseBlockHeader](./client.md#interface-baseblockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: deserializeBlockHeader

```ts
export function deserializeBlockHeader(buffer: number[] | Uint8Array, height: number, offset = 0): BlockHeader
```

See also: [BlockHeader](./client.md#interface-blockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: deserializeBlockHeaders

```ts
export function deserializeBlockHeaders(firstHeight: number, buffer: number[] | Uint8Array, offset = 0, count?: number | undefined): BlockHeader[]
```

See also: [BlockHeader](./client.md#interface-blockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: doubleSha256BE

Calculate the SHA256 hash of the SHA256 hash of an array of bytes.

```ts
export function doubleSha256BE(data: number[] | Uint8Array): number[] {
    return doubleSha256LE(data).reverse();
}
```

See also: [doubleSha256LE](./client.md#function-doublesha256le)

Returns

reversed (big-endian) double sha256 hash of data, byte 31 of hash first.

Argument Details

+ **data**
  + is an array of bytes.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: doubleSha256LE

Calculate the SHA256 hash of the SHA256 hash of an array of bytes.

```ts
export function doubleSha256LE(data: number[] | Uint8Array): number[] {
    if (!Array.isArray(data)) {
        data = asArray(data);
    }
    const first = new Hash.SHA256().update(data).digest();
    const second = new Hash.SHA256().update(first).digest();
    return second;
}
```

See also: [asArray](./client.md#function-asarray)

Returns

double sha256 hash of data, byte 0 of hash first.

Argument Details

+ **data**
  + an array of bytes

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: encodeActionBatchPack

Encode independently content-addressed blobs into one transport frame.

```ts
export function encodeActionBatchPack(items: ActionBatchPackItem[], maxBytes: number, maxItems: number): Uint8Array
```

See also: [ActionBatchPackItem](./client.md#interface-actionbatchpackitem)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: extendActionBatch

```ts
export async function extendActionBatch(storage: StorageProvider, auth: AuthId, args: ExtendActionBatchArgs): Promise<ExtendActionBatchResult>
```

See also: [AuthId](./client.md#interface-authid), [ExtendActionBatchArgs](./client.md#interface-extendactionbatchargs), [ExtendActionBatchResult](./client.md#interface-extendactionbatchresult), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: filterCertificatesByAttributes

```ts
export function filterCertificatesByAttributes(certificates: VerifiableCertificate[], attributes: Record<string, string>): VerifiableCertificate[]
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: filterCertificatesByIdentityKey

Re-bind authenticated overlay certificates to the lookup they answered.
Certificate and token signatures establish who made a claim; they do not
establish that an untrusted lookup host returned the claim requested by the
caller.

```ts
export function filterCertificatesByIdentityKey(certificates: VerifiableCertificate[], identityKey: string): VerifiableCertificate[]
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: fundingRunwayExtension

```ts
export function fundingRunwayExtension(runwayTarget: number, ewmaConfirmedInputs: number, ewmaConfirmedSatoshis: number, availableConfirmed: Array<{
    satoshis: number;
}>): {
    nextRunwayTarget: number;
    requestedOutputs: number;
    targetSatoshis: number;
} | undefined
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: generateChangeSdk

Simplifications:
 - only support one change type with fixed length scripts.
 - only support satsPerKb fee model.

Confirms for each availbleChange output that it remains available as they are allocated and selects alternate if not.

```ts
export async function generateChangeSdk(params: GenerateChangeSdkParams, allocateChangeInput: (targetSatoshis: number, exactSatoshis?: number) => Promise<GenerateChangeSdkChangeInput | undefined>, releaseChangeInput: (outputId: number) => Promise<void>, logger?: WalletLoggerInterface, telemetry?: Telemetry): Promise<GenerateChangeSdkResult>
```

See also: [GenerateChangeSdkChangeInput](./storage.md#interface-generatechangesdkchangeinput), [GenerateChangeSdkParams](./storage.md#interface-generatechangesdkparams), [GenerateChangeSdkResult](./storage.md#interface-generatechangesdkresult), [logger](./client.md#variable-logger)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: generateChangeSdkMakeStorage

```ts
export function generateChangeSdkMakeStorage(availableChange: GenerateChangeSdkChangeInput[]): {
    allocateChangeInput: (targetSatoshis: number, exactSatoshis?: number) => Promise<GenerateChangeSdkChangeInput | undefined>;
    releaseChangeInput: (outputId: number) => Promise<void>;
    getLog: () => string;
}
```

See also: [GenerateChangeSdkChangeInput](./storage.md#interface-generatechangesdkchangeinput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: genesisBuffer

Returns the genesis block for the specified chain.

```ts
export function genesisBuffer(chain: Chain): number[] {
    return serializeBaseBlockHeader(genesisHeader(chain));
}
```

See also: [Chain](./client.md#type-chain), [genesisHeader](./services.md#function-genesisheader), [serializeBaseBlockHeader](./services.md#function-serializebaseblockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: genesisHeader

Returns the genesis block for the specified chain.

```ts
export function genesisHeader(chain: Chain): BlockHeader {
    switch (chain) {
        case "main":
            return {
                version: 1,
                previousHash: "0000000000000000000000000000000000000000000000000000000000000000",
                merkleRoot: "4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b",
                time: 1231006505,
                bits: 486604799,
                nonce: 2083236893,
                height: 0,
                hash: "000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f"
            };
        case "test":
            return {
                version: 1,
                previousHash: "0000000000000000000000000000000000000000000000000000000000000000",
                merkleRoot: "4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b",
                time: 1296688602,
                bits: 486604799,
                nonce: 414098458,
                height: 0,
                hash: "000000000933ea01ad0ee984209779baaec3ced90fa3f408719526f8d77f4943"
            };
        case "stn":
            return {
                version: 1,
                previousHash: "0000000000000000000000000000000000000000000000000000000000000000",
                merkleRoot: "4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b",
                time: 1296688602,
                bits: 486604799,
                nonce: 173779992,
                height: 0,
                hash: "6b38bdbcd73a19f7889d23e1fa6166a9de71affceca60ca3bb1b28af8135c594"
            };
        case "ttn":
            return {
                version: 1,
                previousHash: "0000000000000000000000000000000000000000000000000000000000000000",
                merkleRoot: "4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b",
                time: 1755606836,
                bits: 486604799,
                nonce: 1092578460,
                height: 0,
                hash: "000000000499eabba0a88f5b3747231c74b9191c1a4a04b2c2ea817976b7776d"
            };
        case "tstn":
            return {
                version: 1,
                previousHash: "0000000000000000000000000000000000000000000000000000000000000000",
                merkleRoot: "64452e5b25c65e492ad6a4f5ce9f427ca986626c28315d88de920d66e28cc98f",
                time: 1782864000,
                bits: 486604799,
                nonce: 1780488216,
                height: 0,
                hash: "000000005d221c0e023cb56b5682cf094f32cd959958b40bc931e5797cae706c"
            };
        case "regtest":
            return {
                version: 1,
                previousHash: "0000000000000000000000000000000000000000000000000000000000000000",
                merkleRoot: "4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b",
                time: 1296688602,
                bits: 545259519,
                nonce: 2,
                height: 0,
                hash: "0f9188f13cb7b2c71f2a335e3a4fc328bf5beb436012afca590b1a11466e2206"
            };
        case "mock":
            throw new Error("genesisHeader does not support 'mock' chain. Mock chain generates its own genesis block.");
    }
}
```

See also: [BlockHeader](./client.md#interface-blockheader), [Chain](./client.md#type-chain)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: getActionBatchCapabilities

```ts
export function getActionBatchCapabilities(maxReservedOutputs = ACTION_BATCH_MAX_RESERVED_OUTPUTS, supportsResume = false): StorageCapabilities
```

See also: [ACTION_BATCH_MAX_RESERVED_OUTPUTS](./storage.md#variable-action_batch_max_reserved_outputs), [StorageCapabilities](./client.md#interface-storagecapabilities)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: getBeefForTransaction

Creates a `Beef` to support the validity of a transaction identified by its `txid`.

`storage` is used to retrieve proven transactions and their merkle paths,
or proven_tx_req record with beef of external inputs (internal inputs meged by recursion).
Otherwise external services are used.

`options.maxRecursionDepth` can be set to prevent overly deep chained dependencies. Will throw ERR_EXTSVS_ENVELOPE_DEPTH if exceeded.

If `trustSelf` is true, a partial `Beef` will be returned where transactions known by `storage` to
be valid by verified proof are represented solely by 'txid'.

If `knownTxids` is defined, any 'txid' required by the `Beef` that appears in the array is represented solely as a 'known' txid.

```ts
export async function getBeefForTransaction(storage: StorageProvider, txid: string, options: StorageGetBeefOptions): Promise<Beef>
```

See also: [StorageGetBeefOptions](./client.md#interface-storagegetbeefoptions), [StorageProvider](./storage.md#class-storageprovider)

Argument Details

+ **storage**
  + the chain on which txid exists.
+ **txid**
  + the transaction hash for which an envelope is requested.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: getBeefForTransactions

Build one aggregate BEEF for several roots while resolving each storage
frontier as a set. This avoids one proof query per funding input on the
createAction success path. Complex proof-level and chain-tracker policies
retain the established single-root implementation.

```ts
export async function getBeefForTransactions(storage: StorageProvider, txids: string[], options: StorageGetBeefOptions): Promise<Beef>
```

See also: [StorageGetBeefOptions](./client.md#interface-storagegetbeefoptions), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: getBeefForTxid

```ts
export async function getBeefForTxid(services: Services, txid: string): Promise<Beef>
```

See also: [Services](./services.md#class-services)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: getExchangeRatesIo

```ts
export async function getExchangeRatesIo(key: string, symbols?: string[], fetchClient?: typeof fetch): Promise<ExchangeRatesIoApi>
```

See also: [ExchangeRatesIoApi](./services.md#interface-exchangeratesioapi)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: getIdentityKey

```ts
export async function getIdentityKey(wallet: CertOpsWallet): Promise<PubKeyHex>
```

See also: [CertOpsWallet](./client.md#interface-certopswallet)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: getProofs

Process an array of table.ProvenTxReq (typically with status 'unmined' or 'unknown')

If req is invalid, set status 'invalid'

Verify the requests are valid, lookup proofs or updated transaction status using the array of getProofServices,

When proofs are found, create new ProvenTxApi records and transition the requests' status to 'unconfirmed' or 'notifying',
depending on chaintracks succeeding on proof verification.

Increments attempts if proofs where requested.

```ts
export async function getProofs(task: WalletMonitorTask, reqs: TableProvenTxReq[], maxAcceptableHeight: number, indent = 0, countsAsAttempt = false, ignoreStatus = false): Promise<{
    proven: TableProvenTxReq[];
    invalid: TableProvenTxReq[];
    processed: Array<{
        provenTxReqId: number;
        status: ProvenTxReqStatus;
    }>;
    log: string;
}>
```

See also: [ProvenTxReqStatus](./client.md#type-proventxreqstatus), [TableProvenTxReq](./storage.md#interface-tableproventxreq), [WalletMonitorTask](./monitor.md#class-walletmonitortask)

Returns

reqs partitioned by status

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: getResultBeef

```ts
export function getResultBeef(result: object): Beef | undefined
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: getSyncChunk

Gets the next sync chunk of updated data from un-remoted storage (could be using a remote DB connection).

```ts
export async function getSyncChunk(storage: StorageReader, args: RequestSyncChunkArgs): Promise<SyncChunk>
```

See also: [RequestSyncChunkArgs](./client.md#interface-requestsyncchunkargs), [StorageReader](./storage.md#class-storagereader), [SyncChunk](./client.md#interface-syncchunk)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: getWhatsOnChainBlockHeaderByHash

```ts
export async function getWhatsOnChainBlockHeaderByHash(hash: string, chain: Chain = "main", apiKey?: string): Promise<BlockHeader | undefined>
```

See also: [BlockHeader](./client.md#interface-blockheader), [Chain](./client.md#type-chain)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: handlePostRawTxErrorResponse

Classify an error-status WoC response and mutate `r` accordingly.

```ts
export function handlePostRawTxErrorResponse(r: PostTxResultForTxid, nne: () => Record<string, unknown>, response: {
    data?: unknown;
    statusText?: unknown;
    status?: unknown;
    ok?: boolean;
}): void
```

See also: [PostTxResultForTxid](./client.md#interface-posttxresultfortxid)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: handleScriptHashHistoryCatch

Decide whether a caught error is retryable for script-hash history calls.
If not retryable, sets `r.error` and returns false.

```ts
export function handleScriptHashHistoryCatch(r: GetScriptHashHistoryResult, error_: unknown, _url: string, methodName: string, retry: number, maxRetry: number): boolean
```

See also: [GetScriptHashHistoryResult](./client.md#interface-getscripthashhistoryresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: handleScriptHashHistoryResponse

Inspect a WoC script-hash history response and update `r` in-place.

Returns:
 - `'continue'`  — rate-limited, caller should retry
 - `'return'`    — done, caller should return `r`
 - `'ok'`        — response was successful, continue parsing

```ts
export function handleScriptHashHistoryResponse(r: GetScriptHashHistoryResult, response: ScriptHashHistoryResponse, methodName: string, retry: number): "continue" | "return" | "ok"
```

See also: [GetScriptHashHistoryResult](./client.md#interface-getscripthashhistoryresult), [ScriptHashHistoryResponse](./services.md#interface-scripthashhistoryresponse)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: handleUtxoConnReset

Decide whether the ECONNRESET error is retryable and, if not, set `r.error`.
Returns true when the caller should retry, false when it should return.

```ts
export function handleUtxoConnReset(r: GetUtxoStatusResult, error_: unknown, _url: string, retry: number, maxRetry: number): boolean
```

See also: [GetUtxoStatusResult](./client.md#interface-getutxostatusresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: hasBrc177NoSendExpiryLabel

```ts
export function hasBrc177NoSendExpiryLabel(labels: string[] | undefined): boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: inputSourceTxid

```ts
export function inputSourceTxid(input: BsvTransaction["inputs"][number]): string | undefined
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: internalizeAction

Internalize Action allows a wallet to take ownership of outputs in a pre-existing transaction.
The transaction may, or may not already be known to both the storage and user.

Two types of outputs are handled: "wallet payments" and "basket insertions".

A "basket insertion" output is considered a custom output and has no effect on the wallet's "balance".

A "wallet payment" adds an outputs value to the wallet's change "balance". These outputs are assigned to the "default" basket.

Processing starts with simple validation and then checks for a pre-existing transaction.
If the transaction is already known to the user, then the outputs are reviewed against the existing outputs treatment,
and merge rules are added to the arguments passed to the storage layer.

The existing transaction's `status` determines what the merge path does next:
 - `'unproven'`, `'completed'`, or `'sending'`: outputs are merged into the existing record. The transaction status is left as-is.
   The `'sending'` case covers a transaction this wallet already signed and handed to broadcast processing, but
   whose proven_tx_req has not yet been advanced by the normal monitor/posting flow.
 - `'nosend'`: an ambiguous case. The transaction was created with `noSend: true` and may have been externally
   broadcast, may be sitting in a sendWith chain, or may be stuck mid-flight. The merge path treats the
   `internalizeAction` call as explicit authorization to advance the lifecycle. Specifically: `transactions.status`
   is promoted to `'completed'` (when a BUMP is included in the BEEF) or `'unproven'` (otherwise), and the
   `proven_tx_req` is moved out of `'nosend'` so Monitor's standard proof-fetching flow can finalize it.
   This makes the `internalizeAction` semantics consistent regardless of whether the originator shares the
   same storage as the internalizer or not.
 - Any other status: an error.

When the transaction already exists, the description is updated. The isOutgoing sense is not changed.

"basket insertion" Merge Rules:
1. The "default" basket may not be specified as the insertion basket.
2. Managed change may not be reclassified as a basket insertion.
3. Basket insertions do not affect wallet balance and are typed "custom".

"wallet payment" Merge Rules:
1. Targeting an existing managed output is idempotent.
2. Targeting an existing custom output converts it to managed BRC-29
   change and increases wallet balance. This includes verified recovery of
   a legacy custom row that was incorrectly placed in the default basket.

```ts
export async function internalizeAction(storage: StorageProvider, auth: AuthId, args: InternalizeActionArgs): Promise<StorageInternalizeActionResult>
```

See also: [AuthId](./client.md#interface-authid), [StorageInternalizeActionResult](./client.md#interface-storageinternalizeactionresult), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: internalizeAction

Internalize Action allows a wallet to take ownership of outputs in a pre-existing transaction.
The transaction may, or may not already be known to both the storage and user.

Two types of outputs are handled: "wallet payments" and "basket insertions".

A "basket insertion" output is considered a custom output and has no effect on the wallet's "balance".

A "wallet payment" adds an outputs value to the wallet's change "balance". These outputs are assigned to the "default" basket.

Processing starts with simple validation and then checks for a pre-existing transaction.
If the transaction is already known to the user, then the outputs are reviewed against the existing outputs treatment,
and merge rules are added to the arguments passed to the storage layer.

The existing transaction's `status` determines what the merge path does next:
 - `'unproven'`, `'completed'`, or `'sending'`: outputs are merged; status is left as-is.
   The `'sending'` case covers a transaction this wallet already signed and handed to broadcast processing, but
   whose proven_tx_req has not yet been advanced by the normal monitor/posting flow.
 - `'nosend'`: the `internalizeAction` call is treated as explicit authorization to advance the lifecycle.
   `transactions.status` is promoted to `'completed'` (BUMP-bearing BEEF) or `'unproven'` (otherwise), and the
   `proven_tx_req` is moved out of `'nosend'` so Monitor's proof-fetching flow can finalize it. See storage-layer
   `internalizeAction` docs for the full rationale.
 - Any other status: an error.

When the transaction already exists, the description is updated. The isOutgoing sense is not changed.

"basket insertion" Merge Rules:
1. The "default" basket may not be specified as the insertion basket.
2. Managed change may not be reclassified as a basket insertion.
3. Basket insertions do not affect wallet balance and are typed "custom".

"wallet payment" Merge Rules:
1. Targeting an existing managed output is idempotent.
2. Targeting a custom output converts it to managed BRC-29 change after
   the locking script is verified. This is the only supported in-place
   recovery path for a misclassified BRC-29 payment.

```ts
export async function internalizeAction(wallet: Wallet, auth: AuthId, args: InternalizeActionArgs): Promise<StorageInternalizeActionResult>
```

See also: [AuthId](./client.md#interface-authid), [StorageInternalizeActionResult](./client.md#interface-storageinternalizeactionresult), [Wallet](./client.md#class-wallet)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isArcAcceptedTxStatus

```ts
export function isArcAcceptedTxStatus(txStatus: string | undefined): boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isArcDoubleSpendTxStatus

```ts
export function isArcDoubleSpendTxStatus(txStatus: string | undefined): boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isArcInvalidTxStatus

```ts
export function isArcInvalidTxStatus(txStatus: string | undefined): boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isArcServiceErrorStatus

```ts
export function isArcServiceErrorStatus(status: number | undefined, detail?: string): boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isAutoSpendableChangeOutput

True when managed change is currently eligible for automatic allocation.

```ts
export function isAutoSpendableChangeOutput(output: TableOutput | undefined): output is TableOutput
```

See also: [TableOutput](./storage.md#interface-tableoutput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isBaseBlockHeader

Type guard function.

```ts
export function isBaseBlockHeader(header: AnyBlockHeader): header is BaseBlockHeader {
    const properties = dataProperties(header);
    return properties != null && hasBaseHeaderShape(properties);
}
```

See also: [AnyBlockHeader](./services.md#type-anyblockheader), [BaseBlockHeader](./client.md#interface-baseblockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isBlockHeader

Type guard function.

```ts
export function isBlockHeader(header: AnyBlockHeader): header is BlockHeader {
    const properties = dataProperties(header);
    return (properties != null &&
        hasBaseHeaderShape(properties) &&
        isHeight(valueOf(properties, "height")) &&
        isHash(valueOf(properties, "hash")));
}
```

See also: [AnyBlockHeader](./services.md#type-anyblockheader), [BlockHeader](./client.md#interface-blockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isCreateActionSpecOp

```ts
export function isCreateActionSpecOp(label: string): boolean
```

Returns

true iff the `label` name is a reserved `createAction` special operation identifier.

Argument Details

+ **label**
  + Action / Transaction label name value.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isKnownValidBulkHeaderFile

Compares meta data received for a bulk header file `vbf` to known
valid bulk header files based on their `fileHash`.

Short circuits both the retreival and validation of individual headers,
only a single SHA256 hash of the aggregate data needs to be compared.

The standard file size for historic block headers is 100,000 per file
which results in a many orders of magnitude initialization speedup.

The following properties must match:
- `firstHeight`
- `count`
- `prevChainWork`
- `prevHash`
- `lastChainWork`
- `lastHash`
- `chain`

```ts
export function isKnownValidBulkHeaderFile(vbf: BulkHeaderFileInfo): boolean {
    if (!vbf?.fileHash)
        return false;
    const bf = validBulkHeaderFilesByFileHash()[vbf.fileHash];
    if (bf?.firstHeight !== vbf.firstHeight ||
        bf?.count !== vbf.count ||
        bf?.prevChainWork !== vbf.prevChainWork ||
        bf?.prevHash !== vbf.prevHash ||
        bf?.lastChainWork !== vbf.lastChainWork ||
        bf?.lastHash !== vbf.lastHash ||
        bf?.chain !== vbf.chain) {
        return false;
    }
    return true;
}
```

See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo), [validBulkHeaderFilesByFileHash](./services.md#function-validbulkheaderfilesbyfilehash)

Returns

true iff bulk file meta data (excluding its source) matches a known file.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isLegacyManagedChangeBasketDefault

True only for the exact historical default that is safe to auto-upgrade.

```ts
export function isLegacyManagedChangeBasketDefault(basket: ManagedChangeBasketDefaults): boolean
```

See also: [ManagedChangeBasketDefaults](./storage.md#interface-managedchangebasketdefaults)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isListActionsSpecOp

```ts
export function isListActionsSpecOp(label: string): boolean
```

Returns

true iff the `label` name is a reserved `listActions` special operation identifier.

Argument Details

+ **label**
  + Action / Transaction label name value.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isListOutputsSpecOp

```ts
export function isListOutputsSpecOp(basket: string): boolean
```

Returns

true iff the `basket` name is a reserved `listOutputs` special operation identifier.

Argument Details

+ **basket**
  + Output basket name value.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isLive

Type guard function.

```ts
export function isLive(header: BlockHeader | LiveBlockHeader): header is LiveBlockHeader {
    return isLiveBlockHeader(header);
}
```

See also: [BlockHeader](./client.md#interface-blockheader), [LiveBlockHeader](./services.md#interface-liveblockheader), [isLiveBlockHeader](./services.md#function-isliveblockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isLiveBlockHeader

Type guard function.

```ts
export function isLiveBlockHeader(header: AnyBlockHeader): header is LiveBlockHeader {
    const properties = dataProperties(header);
    const headerId = properties == null ? undefined : valueOf(properties, "headerId");
    const previousHeaderId = properties == null ? undefined : valueOf(properties, "previousHeaderId");
    return (properties != null &&
        hasBaseHeaderShape(properties) &&
        isHeight(valueOf(properties, "height")) &&
        isHash(valueOf(properties, "hash")) &&
        isHash(valueOf(properties, "chainWork")) &&
        Number.isSafeInteger(headerId) &&
        (headerId as number) >= 1 &&
        (previousHeaderId === null || (Number.isSafeInteger(previousHeaderId) && (previousHeaderId as number) >= 1)) &&
        typeof valueOf(properties, "isActive") === "boolean" &&
        typeof valueOf(properties, "isChainTip") === "boolean");
}
```

See also: [AnyBlockHeader](./services.md#type-anyblockheader), [LiveBlockHeader](./services.md#interface-liveblockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isManagedChangeOutput

True when an output has all metadata required to use the wallet-managed
BRC-29 signing path. `senderIdentityKey` is optional: wallet-created change
uses the client's change public key when it is absent, while received
BRC-29 payments record the sender's identity key.

```ts
export function isManagedChangeOutput(output: TableOutput | undefined): output is TableOutput
```

See also: [TableOutput](./storage.md#interface-tableoutput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isMoreWork

Returns true if work1 is more work (greater than) work2

```ts
export function isMoreWork(work1: string, work2: string): boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: isValidFiatRate

```ts
export function isValidFiatRate(value: unknown): value is number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: keyOffsetToHashedSecret

```ts
export function keyOffsetToHashedSecret(pub: PublicKey, keyOffset?: string): {
    hashedSecret: BigNumber;
    keyOffset: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: listCertificates

```ts
export async function listCertificates(storage: StorageProvider, auth: AuthId, vargs: Validation.ValidListCertificatesArgs, _originator?: OriginatorDomainNameStringUnder250Bytes): Promise<ListCertificatesResult>
```

See also: [AuthId](./client.md#interface-authid), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: lockScriptWithKeyOffsetFromPubKey

```ts
export function lockScriptWithKeyOffsetFromPubKey(pubKey: string, keyOffset?: string): {
    script: string;
    keyOffset: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: lookupPreparedBeefs

Read and validate prepared artifacts without performing chain or service
work. A malformed, stale, oversized, or unsupported row is a cache miss.

```ts
export async function lookupPreparedBeefs(storage: PreparedBeefStorage, userId: number, rootTxids: string[], parent?: TelemetrySpan): Promise<PreparedBeefLookupResult>
```

See also: [PreparedBeefLookupResult](./storage.md#interface-preparedbeeflookupresult), [PreparedBeefStorage](./storage.md#interface-preparedbeefstorage)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: makeAtomicBeef

```ts
export function makeAtomicBeef(tx: Transaction, beef: number[] | Beef): number[]
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: makeChangeLock

Derive a change output locking script

```ts
export function makeChangeLock(out: StorageCreateTransactionSdkOutput, dctr: StorageCreateActionResult, args: Validation.ValidCreateActionArgs, changeKeys: KeyPair, wallet: Wallet): Script
```

See also: [KeyPair](./client.md#interface-keypair), [StorageCreateActionResult](./client.md#interface-storagecreateactionresult), [StorageCreateTransactionSdkOutput](./client.md#interface-storagecreatetransactionsdkoutput), [Wallet](./client.md#class-wallet)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: makeMerklePathNote

```ts
export function makeMerklePathNote(what: MerklePathNoteWhat, name: string, extra: Partial<MerklePathNote> = {}): MerklePathNote
```

See also: [MerklePathNote](./services.md#interface-merklepathnote), [MerklePathNoteWhat](./services.md#type-merklepathnotewhat)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: makeNoSendExpiryFundingArgs

```ts
export function makeNoSendExpiryFundingArgs(anchorSatoshis: number, protectedLabels: string[] = []): Brc177ValidCreateActionArgs
```

See also: [Brc177ValidCreateActionArgs](./client.md#type-brc177validcreateactionargs)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: makePostBeefServiceError

```ts
export function makePostBeefServiceError(providerName: string, txids: string[], what: "postBeefServiceError" | "postBeefServiceTimeout", timeoutMs?: number): PostBeefResult
```

See also: [PostBeefResult](./client.md#interface-postbeefresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: manifestPhysicalDigests

```ts
export function manifestPhysicalDigests(manifest: ActionBatchManifest): string[]
```

See also: [ActionBatchManifest](./client.md#interface-actionbatchmanifest)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: mapWithConcurrency

```ts
export async function mapWithConcurrency<T, R>(values: T[], maxConcurrency: number, worker: (value: T, index: number) => Promise<R>): Promise<R[]>
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: markConfirmedStaleReqInputs

Ask the configured UTXO-provider collection to classify the request's local
inputs and mark only positively confirmed spent outputs unavailable.
Provider errors and a collection with no providers are inconclusive and
never count as spent.

```ts
export async function markConfirmedStaleReqInputs(req: EntityProvenTxReq, storage: StorageProvider, services: sdk.WalletServices, trx?: sdk.TrxToken, logger?: WalletLoggerInterface): Promise<FailedInputReconciliationResult>
```

See also: [EntityProvenTxReq](./storage.md#class-entityproventxreq), [FailedInputReconciliationResult](./storage.md#interface-failedinputreconciliationresult), [StorageProvider](./storage.md#class-storageprovider), [TrxToken](./client.md#interface-trxtoken), [WalletServices](./client.md#interface-walletservices), [logger](./client.md#variable-logger)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: markStaleInputsAsSpent

After any failed broadcast (doubleSpend, invalidTx, etc.), query each
consumed-input outpoint of the failed transaction against on-chain
UTXO state. For inputs the chain authoritatively confirms are spent
(i.e. NOT a UTXO), update the corresponding wallet basket entry to
spendable=false.

Background: `updateTransactionStatus(failed)` optimistically restores
all consumed-input outputs to spendable=true so the user can retry
with the same inputs. For some failures (genuine doubleSpend, or any
'missing-inputs' outcome where the input has been spent on chain by
a different transaction), restoration is incorrect — the input is
gone and restoring it produces an infinite missing-inputs loop on
the next createAction → broadcast cycle. Apps cannot evict from the
default basket on app-isolated wallets (admin-only policy), so this
self-heal must run inside the wallet.

Different broadcasters classify the same on-chain reality differently
(ARC → doubleSpend, WhatsOnChain/Bitails → invalidTx via
'missing-inputs'); this helper is broadcaster-agnostic because its
decision is based on services.isUtxo, not the aggregate failure
classification.

Pre-broadcast races where concurrent createActions reach the same
UTXO across separate app processes are out of scope; see PR
description.

Conservatively scoped:
  - Only inputs found in the failing user's basket are touched.
  - Inputs whose on-chain UTXO status cannot be determined (service
    error / inconclusive) are left spendable=true. Eviction is opt-in
    based on positive evidence of stale state.
  - Inputs the chain confirms are still UTXOs (e.g. a competing tx
    itself failed, or a malformed/fee failure where inputs are intact)
    are left spendable=true — preserving the existing transient-retry
    semantics callers depend on.

Returns counts for instrumentation and the set of stale outpoints
that were actually evicted (added to history note for diagnostics).

```ts
export async function markStaleInputsAsSpent(ar: AggregatePostBeefTxResult, storage: StorageProvider, services: sdk.WalletServices, trx?: sdk.TrxToken, logger?: WalletLoggerInterface): Promise<{
    checked: number;
    staleConfirmed: number;
    staleOutpoints: string[];
}>
```

See also: [AggregatePostBeefTxResult](./storage.md#interface-aggregatepostbeeftxresult), [StorageProvider](./storage.md#class-storageprovider), [TrxToken](./client.md#interface-trxtoken), [WalletServices](./client.md#interface-walletservices), [logger](./client.md#variable-logger)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: markSyncProofInsertOnly

Record that preflight found no row which this candidate may replace.

```ts
export function markSyncProofInsertOnly(candidate: TableProvenTx): void
```

See also: [TableProvenTx](./storage.md#interface-tableproventx)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: markSyncProofReconciled

Mark a fully validated reconciliation without changing the source cursor timestamp.

```ts
export function markSyncProofReconciled(candidate: TableProvenTx): void
```

See also: [TableProvenTx](./storage.md#interface-tableproventx)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: markUserInputsSpent

```ts
export async function markUserInputsSpent(storage: StorageProvider, userId: number, tx: BsvTransaction, transactionId: number): Promise<SpentInputTransition[]>
```

See also: [SpentInputTransition](./storage.md#interface-spentinputtransition), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: maxDate

```ts
export function maxDate(d1?: Date, d2?: Date): Date | undefined
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: mergeInputBeefs

For each input of `rawTx`, ensure the source txid is represented in `beef`.

When `requiredLevels` is undefined/0 and `knownTxids` contains the source txid,
a txid-only stub is merged rather than recursing into storage.

```ts
export async function mergeInputBeefs(rawTx: number[], beef: Beef, trustSelf: "known" | undefined, knownTxids: string[] | undefined, trx: TrxToken | undefined, requiredLevels: number | undefined, getValidBeef: (txid: string, beef: Beef, trustSelf: "known" | undefined, knownTxids: string[] | undefined, trx: TrxToken | undefined, requiredLevels: number | undefined) => Promise<unknown>): Promise<void>
```

See also: [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: mergeInputsIntoBeef

Convenience wrapper for the external-sharing path where `trustSelf` and
`requiredLevels` are always absent.

```ts
export async function mergeInputsIntoBeef(rawTx: number[], beef: Beef, knownTxids: string[], trx: TrxToken | undefined, getValidBeef: (txid: string, beef: Beef, trustSelf: undefined, knownTxids: string[], trx: TrxToken | undefined) => Promise<unknown>): Promise<void>
```

See also: [TrxToken](./client.md#interface-trxtoken)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: mergePlannerBeef

```ts
export function mergePlannerBeef(state: ActionBatchPlannerState, tx: Transaction): void
```

See also: [ActionBatchPlannerState](./client.md#interface-actionbatchplannerstate)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizeArcProviderConfig

Snapshot security-relevant ARC/Arcade constructor configuration exactly once.

```ts
export function normalizeArcProviderConfig(config: string | ArcConfig | undefined, defaultDeploymentId: () => string): NormalizedArcProviderConfig
```

See also: [ArcConfig](./services.md#interface-arcconfig), [NormalizedArcProviderConfig](./services.md#interface-normalizedarcproviderconfig)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizeBulkFileDataValidationRequest

Normalize and snapshot a complete validator request before asynchronous work.

```ts
export function normalizeBulkFileDataValidationRequest(request: unknown): BulkFileDataValidationRequest
```

See also: [BulkFileDataValidationRequest](./services.md#interface-bulkfiledatavalidationrequest)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizeBulkHeaderFileInfo

```ts
export function normalizeBulkHeaderFileInfo(value: unknown, allowStoredBoolean = false): BulkHeaderFileInfo
```

See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizeBulkHeaderFileSequence

```ts
export function normalizeBulkHeaderFileSequence(files: unknown, allowStoredBoolean = false): BulkHeaderFileInfo[]
```

See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizeBulkHeaderFilesInfo

```ts
export function normalizeBulkHeaderFilesInfo(value: unknown): BulkHeaderFilesInfo
```

See also: [BulkHeaderFilesInfo](./services.md#interface-bulkheaderfilesinfo)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizeFiatCurrencies

```ts
export function normalizeFiatCurrencies(value: unknown, extras: readonly FiatCurrencyCode[] = []): FiatCurrencyCode[]
```

See also: [FiatCurrencyCode](./client.md#type-fiatcurrencycode)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizeFiatCurrency

```ts
export function normalizeFiatCurrency(value: unknown, name = "currency"): FiatCurrencyCode
```

See also: [FiatCurrencyCode](./client.md#type-fiatcurrencycode)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizeFiatExchangeRates

```ts
export function normalizeFiatExchangeRates(value: unknown, required: readonly FiatCurrencyCode[], now = Date.now()): FiatExchangeRates
```

See also: [FiatCurrencyCode](./client.md#type-fiatcurrencycode), [FiatExchangeRates](./client.md#interface-fiatexchangerates)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizeFiatRate

```ts
export function normalizeFiatRate(value: unknown, currency: string): number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizeFiatRateTimestamps

```ts
export function normalizeFiatRateTimestamps(value: unknown, now = Date.now()): Record<string, Date> | undefined
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizeFiatTimestamp

```ts
export function normalizeFiatTimestamp(value: unknown, now = Date.now()): Date
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizeMonitorIdentityKey

```ts
export function normalizeMonitorIdentityKey(value: unknown, name = "identityKey"): string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizePostRawHex

```ts
export function normalizePostRawHex(value: unknown, maximumBytes: number, name = "rawTx"): string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizePostTxids

```ts
export function normalizePostTxids(value: unknown, name = "txids", allowEmpty = false): string[]
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizeTxid

```ts
export function normalizeTxid(value: unknown, name = "txid"): string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: normalizeWalletOutpoint

```ts
export function normalizeWalletOutpoint(value: unknown): string | undefined
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: notifyTransactionsOfProof

Notify each transaction that a proof has been found.
Mutates `req` history notes in place.

The `addNote` callback avoids coupling this helper to a specific entity type.
Returns false if any transaction update failed so callers can retain the
request for later status repair.

```ts
export async function notifyTransactionsOfProof(ids: number[], provenTxId: number, addNote: (note: ReqHistoryNote) => void, updateTransaction: (id: number, update: {
    provenTxId: number;
    status: "completed";
}) => Promise<unknown>): Promise<boolean>
```

See also: [ReqHistoryNote](./client.md#interface-reqhistorynote)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: offsetPrivKey

```ts
export function offsetPrivKey(privKey: string, keyOffset?: string): {
    offsetPrivKey: string;
    keyOffset: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: offsetPubKey

```ts
export function offsetPubKey(pubKey: string, keyOffset?: string): {
    offsetPubKey: string;
    keyOffset: string;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: optionalArraysEqual

```ts
export function optionalArraysEqual(arr1?: number[], arr2?: number[]): boolean
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: optionalMonitorInteger

```ts
export function optionalMonitorInteger(value: unknown, minimum: number, maximum: number): number | undefined
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: parseBrc177NoSendExpiryLabels

```ts
export function parseBrc177NoSendExpiryLabels(labels: string[] | undefined): Brc177NoSendExpiry | undefined
```

See also: [Brc177NoSendExpiry](./client.md#interface-brc177nosendexpiry)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: parseResults$

```ts
export async function* parseResults$(lookupResult: LookupAnswer): AsyncIterable<VerifiableCertificate>
```

See also: [parseResults](./client.md#variable-parseresults)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: parseTxScriptOffsets

```ts
export function parseTxScriptOffsets(rawTx: number[] | Uint8Array): TxScriptOffsets
```

See also: [TxScriptOffsets](./client.md#interface-txscriptoffsets)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: planAction

```ts
export async function planAction(state: ActionBatchPlannerState, args: Validation.ValidCreateActionArgs): Promise<ActionBatchPlannedAction>
```

See also: [ActionBatchPlannedAction](./client.md#interface-actionbatchplannedaction), [ActionBatchPlannerState](./client.md#interface-actionbatchplannerstate)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: plannerInputLockingScript

```ts
export function plannerInputLockingScript(state: ActionBatchPlannerState, input: Pick<StorageCreateTransactionSdkInput, "sourceTxid" | "sourceVout">): number[]
```

See also: [ActionBatchPlannerState](./client.md#interface-actionbatchplannerstate), [StorageCreateTransactionSdkInput](./client.md#interface-storagecreatetransactionsdkinput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: plannerOutputLockingScript

```ts
export function plannerOutputLockingScript(state: ActionBatchPlannerState, output: PlannerOutput): number[]
```

See also: [ActionBatchPlannerState](./client.md#interface-actionbatchplannerstate), [PlannerOutput](./client.md#interface-planneroutput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: populateUtxoDetails

Populate UTXO details from a WoC result array

```ts
export function populateUtxoDetails(r: GetUtxoStatusResult, result: Array<{
    tx_hash: string;
    value: number;
    height: number;
    tx_pos: number;
}>, outpoint?: string): void
```

See also: [GetUtxoStatusResult](./client.md#interface-getutxostatusresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: prepareActionBatchCommit

```ts
export async function prepareActionBatchCommit(storage: StorageProvider, auth: AuthId, manifest: ActionBatchManifest): Promise<PrepareActionBatchCommitResult>
```

See also: [ActionBatchManifest](./client.md#interface-actionbatchmanifest), [AuthId](./client.md#interface-authid), [PrepareActionBatchCommitResult](./client.md#interface-prepareactionbatchcommitresult), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: prepareNoSendExpiry

```ts
export async function prepareNoSendExpiry(storage: StorageProvider, auth: AuthId, target: Validation.ValidCreateActionArgs): Promise<StoragePrepareNoSendExpiryResult>
```

See also: [AuthId](./client.md#interface-authid), [StoragePrepareNoSendExpiryResult](./client.md#interface-storagepreparenosendexpiryresult), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: processAction

```ts
export async function processAction(storage: StorageProvider, auth: AuthId, args: StorageProcessActionArgs): Promise<StorageProcessActionResults>
```

See also: [AuthId](./client.md#interface-authid), [StorageProcessActionArgs](./client.md#interface-storageprocessactionargs), [StorageProcessActionResults](./client.md#interface-storageprocessactionresults), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: processAction

```ts
export async function processAction(prior: PendingSignAction | undefined, wallet: Wallet, auth: AuthId, vargs: Validation.ValidProcessActionArgs): Promise<StorageProcessActionResults>
```

See also: [AuthId](./client.md#interface-authid), [PendingSignAction](./client.md#interface-pendingsignaction), [StorageProcessActionResults](./client.md#interface-storageprocessactionresults), [Wallet](./client.md#class-wallet)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: processNoSendExpiryLifecycle

```ts
export async function processNoSendExpiryLifecycle(storage: StorageProvider): Promise<NoSendExpiryLifecycleResult>
```

See also: [NoSendExpiryLifecycleResult](./storage.md#interface-nosendexpirylifecycleresult), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: proofOfWorkLimitBits

The compact encoding of the highest proof-of-work target `chain` admits.

Only `'regtest'` raises the limit. Every other chain — and an omitted chain,
which is how every caller that predates this parameter asks — keeps the mainnet
limit, so no existing validation is relaxed.

```ts
export function proofOfWorkLimitBits(chain?: Chain): number
```

See also: [Chain](./client.md#type-chain)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: proveCertificate

```ts
export async function proveCertificate(wallet: Wallet, auth: AuthId, vargs: Validation.ValidProveCertificateArgs): Promise<ProveCertificateResult>
```

See also: [AuthId](./client.md#interface-authid), [Wallet](./client.md#class-wallet)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: pruneBeefForTxids

Return a minimal BEEF when the source contains data outside the requested
transaction dependency closure. Return undefined when no pruning is needed.

This form lets forwarding clients retain the caller's original bytes in the
common no-op case instead of rebuilding and reserializing an equivalent BEEF.

```ts
export function pruneBeefForTxids(source: Beef, txids: string[]): Beef | undefined
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: publicArcadeUrl

Credential-free public Arcade host for supported networks.

```ts
export function publicArcadeUrl(chain: Chain): string | undefined
```

See also: [Chain](./client.md#type-chain)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: putActionBatchBlob

```ts
export async function putActionBatchBlob(storage: StorageProvider, auth: AuthId, args: PutActionBatchBlobArgs): Promise<void>
```

See also: [AuthId](./client.md#interface-authid), [PutActionBatchBlobArgs](./client.md#interface-putactionbatchblobargs), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: putActionBatchPack

```ts
export async function putActionBatchPack(storage: StorageProvider, auth: AuthId, args: PutActionBatchPackArgs): Promise<void>
```

See also: [AuthId](./client.md#interface-authid), [PutActionBatchPackArgs](./client.md#interface-putactionbatchpackargs), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: quarantineReqInputs

Conservatively quarantine every locally-owned input of a transaction after
Arcade supplies explicit missing-input/conflict evidence. This path is
deliberately independent of explorer or UTXO providers: a positive
broadcaster verdict is enough to stop the failed transaction from feeding
the same inputs into another action. A later validated mined proof remains
able to repair the transaction through the ordinary proof recovery path.

```ts
export async function quarantineReqInputs(req: EntityProvenTxReq, storage: StorageProvider, trx?: sdk.TrxToken, logger?: WalletLoggerInterface): Promise<FailedInputReconciliationResult>
```

See also: [EntityProvenTxReq](./storage.md#class-entityproventxreq), [FailedInputReconciliationResult](./storage.md#interface-failedinputreconciliationresult), [StorageProvider](./storage.md#class-storageprovider), [TrxToken](./client.md#interface-trxtoken), [logger](./client.md#variable-logger)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: quarantineReqInputsFromFailedParents

Keep only inputs created by a locally terminal parent unavailable after the
failed-child transition releases its allocations. Other inputs may still be
valid UTXOs and must remain reusable.

```ts
export async function quarantineReqInputsFromFailedParents(req: EntityProvenTxReq, failedParentTxids: string[], storage: StorageProvider, trx?: sdk.TrxToken, logger?: WalletLoggerInterface): Promise<FailedInputReconciliationResult>
```

See also: [EntityProvenTxReq](./storage.md#class-entityproventxreq), [FailedInputReconciliationResult](./storage.md#interface-failedinputreconciliationresult), [StorageProvider](./storage.md#class-storageprovider), [TrxToken](./client.md#interface-trxtoken), [logger](./client.md#variable-logger)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: randomBytes

```ts
export function randomBytes(count: number): number[]
```

Returns

count cryptographically secure random bytes as array of bytes

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: randomBytesBase64

```ts
export function randomBytesBase64(count: number): string
```

Returns

count cryptographically secure random bytes as base64 encoded string

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: randomBytesHex

```ts
export function randomBytesHex(count: number): string
```

Returns

count cryptographically secure random bytes as hex encoded string

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: randomizeOutputVouts

Pure Fisher-Yates vout assignment shared by legacy and batch planning.

```ts
export function randomizeOutputVouts<T extends {
    vout: number;
}>(outputs: T[], randomVals?: number[]): void
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: rawTransactionBytes

```ts
export function rawTransactionBytes(rawTx: number[] | Uint8Array): number[]
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: readUInt32BE

```ts
export function readUInt32BE(a: number[] | Uint8Array, offset: number): number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: readUInt32LE

```ts
export function readUInt32LE(a: number[] | Uint8Array, offset: number): number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: redeemServiceCharges

```ts
export function redeemServiceCharges(privateKeyWif: string, charges: TableCommission[]): Array<{}>
```

See also: [TableCommission](./storage.md#interface-tablecommission)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: regtestArcadeUrl

Arcade broadcaster / ARC endpoint for regtest, or `undefined` when `REGTEST_ARCADE_URL` is unset.

```ts
export function regtestArcadeUrl(): string | undefined
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: regtestChaintracksUrl

ChainTracks service URL for regtest. Falls back to `${REGTEST_ARCADE_URL}/chaintracks/v1` when
`REGTEST_CHAINTRACKS_URL` is unset (mirrors the tstn layout). Throws when neither is configured.

```ts
export function regtestChaintracksUrl(): string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: renewActionBatch

```ts
export async function renewActionBatch(storage: StorageProvider, auth: AuthId, batchId: string): Promise<RenewActionBatchResult>
```

See also: [AuthId](./client.md#interface-authid), [RenewActionBatchResult](./client.md#interface-renewactionbatchresult), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: repeatableRandom

```ts
export function repeatableRandom(randomVals?: number[]): () => number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: requireConclusiveUtxo

Convert an internal tri-state classification to the historical boolean
contract only when a provider supplied a conclusive answer.

```ts
export function requireConclusiveUtxo(classification: OutputUtxoClassification): boolean
```

See also: [OutputUtxoClassification](./services.md#interface-outpututxoclassification)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: requireMonitorInteger

```ts
export function requireMonitorInteger(value: unknown, name: string, minimum: number, maximum: number): number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: restoreInputsToSpendable

```ts
export async function restoreInputsToSpendable(storage: StorageProvider, transitions: SpentInputTransition[]): Promise<void>
```

See also: [SpentInputTransition](./storage.md#interface-spentinputtransition), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: resumeActionBatch

Reacquire exactly the persisted inputs owned by one expired client
workspace. This is deliberately explicit: another action may not become a
member merely because it happens to use the same Wallet instance.

```ts
export async function resumeActionBatch(storage: StorageProvider, auth: AuthId, args: ResumeActionBatchArgs): Promise<ResumeActionBatchResult>
```

See also: [AuthId](./client.md#interface-authid), [ResumeActionBatchArgs](./client.md#interface-resumeactionbatchargs), [ResumeActionBatchResult](./client.md#interface-resumeactionbatchresult), [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: reviewUtxoOutputs

Classify a bounded set of wallet outputs without treating provider failure as
proof that an output was spent. Read-only reviews always return their
conclusive and unknown partitions. Atomic release requires every verdict to
be conclusive; the operator-only conclusive mode releases the positively
spent subset while retaining and reporting unknowns.

```ts
export async function reviewUtxoOutputs(storage: StorageProvider, auth: AuthId, outputs: TableOutput[], releaseMode: UtxoReviewReleaseMode = "none"): Promise<ReviewUtxoOutputsResult>
```

See also: [AuthId](./client.md#interface-authid), [ReviewUtxoOutputsResult](./storage.md#interface-reviewutxooutputsresult), [StorageProvider](./storage.md#class-storageprovider), [TableOutput](./storage.md#interface-tableoutput), [UtxoReviewReleaseMode](./storage.md#type-utxoreviewreleasemode)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: safeDiagnostic

Convert an untrusted diagnostic to bounded, single-line text suitable for logs and status APIs.

```ts
export function safeDiagnostic(value: unknown, maximum = 512): string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: sameSyncProof

Compare proof authority fields, excluding local IDs and timestamps.

```ts
export function sameSyncProof(a: TableProvenTx, b: TableProvenTx): boolean
```

See also: [TableProvenTx](./storage.md#interface-tableproventx)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: selectBulkHeaderFiles

```ts
export function selectBulkHeaderFiles(files: BulkHeaderFileInfo[], chain: Chain, maxPerFile: number): BulkHeaderFileInfo[]
```

See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo), [Chain](./client.md#type-chain)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: selectCanonicalChange

Pure exact / least-over / largest-under change selection policy.

```ts
export function selectCanonicalChange<T extends CanonicalFundingCandidate>(outputs: T[], targetSatoshis: number, exactSatoshis?: number): T | undefined
```

See also: [CanonicalFundingCandidate](./storage.md#interface-canonicalfundingcandidate)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: selectNoSendExpiryFundingAnchor

```ts
export function selectNoSendExpiryFundingAnchor(outputs: StorageCreateTransactionSdkOutput[], anchorSatoshis: number): StorageCreateTransactionSdkOutput
```

See also: [StorageCreateTransactionSdkOutput](./client.md#interface-storagecreatetransactionsdkoutput)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: serializeBaseBlockHeader

Serializes a block header as an 80 byte Buffer.
The exact serialized format is defined in the Bitcoin White Paper
such that computing a double sha256 hash of the buffer computes
the block hash for the header.

```ts
export function serializeBaseBlockHeader(header: BaseBlockHeader, buffer?: number[], offset?: number): number[] {
    const validated = copyBaseHeaderData(header);
    validateBaseBlockHeaderFormat(validated);
    const writer = new Utils.Writer();
    writer.writeUInt32LE(validated.version);
    writer.write(asArray(validated.previousHash).reverse());
    writer.write(asArray(validated.merkleRoot).reverse());
    writer.writeUInt32LE(validated.time);
    writer.writeUInt32LE(validated.bits);
    writer.writeUInt32LE(validated.nonce);
    const data = writer.toArray();
    if (buffer != null) {
        if (!Array.isArray(buffer))
            throw new WERR_INVALID_PARAMETER("buffer", "an array");
        offset ??= 0;
        if (!Number.isSafeInteger(offset) || offset < 0 || offset + data.length > buffer.length) {
            throw new WERR_INVALID_PARAMETER("offset", "a non-negative safe integer with 80 writable bytes");
        }
        for (let i = 0; i < data.length; i++) {
            buffer[offset + i] = data[i];
        }
    }
    return data;
}
```

See also: [BaseBlockHeader](./client.md#interface-baseblockheader), [WERR_INVALID_PARAMETER](./client.md#class-werr_invalid_parameter), [asArray](./client.md#function-asarray), [validateBaseBlockHeaderFormat](./services.md#function-validatebaseblockheaderformat), [writeUInt32LE](./services.md#function-writeuint32le)

Returns

80 byte Buffer

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: serializeBaseBlockHeaders

```ts
export function serializeBaseBlockHeaders(headers: BlockHeader[]): Uint8Array
```

See also: [BlockHeader](./client.md#interface-blockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: setDisableDoubleSpendCheckForTest

```ts
export function setDisableDoubleSpendCheckForTest(v: boolean)
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: setResultBeef

```ts
export function setResultBeef(result: object, beef: Beef): void
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: sha256Hash

Calculate the SHA256 hash of an array of bytes

```ts
export function sha256Hash(data: number[] | Uint8Array): number[] {
    if (!Array.isArray(data)) {
        data = asArray(data);
    }
    const first = new Hash.SHA256().update(data).digest();
    return first;
}
```

See also: [asArray](./client.md#function-asarray)

Returns

sha256 hash of buffer contents.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: sha256HashOfBinaryFile

Computes sha256 hash of file contents read as bytes with no encoding.

```ts
export async function sha256HashOfBinaryFile(fs: ChaintracksFsApi, filepath: string, bufferSize = 80000): Promise<{
    hash: string;
    length: number;
}>
```

See also: [ChaintracksFsApi](./services.md#interface-chaintracksfsapi)

Returns

`{hash, length}` where `hash` is base64 string form of file hash and `length` is file length in bytes.

Argument Details

+ **filepath**
  + Full filepath to file.
+ **bufferSize**
  + Optional read buffer size to use. Defaults to 80,000 bytes. Currently ignored.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: shareReqsWithWorld

```ts
export async function shareReqsWithWorld(storage: StorageProvider, userId: number, txids: string[], isDelayed: boolean, r?: GetReqsAndBeefResult, logger?: WalletLoggerInterface): Promise<{
    swr: SendWithResult[];
    ndr: ReviewActionResult[] | undefined;
}>
```

See also: [GetReqsAndBeefResult](./storage.md#interface-getreqsandbeefresult), [ReviewActionResult](./client.md#interface-reviewactionresult), [StorageProvider](./storage.md#class-storageprovider), [logger](./client.md#variable-logger)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: signAction

```ts
export async function signAction(wallet: Wallet, auth: AuthId, args: SignActionArgs): Promise<SignActionResultX>
```

See also: [AuthId](./client.md#interface-authid), [SignActionResultX](./client.md#interface-signactionresultx), [Wallet](./client.md#class-wallet)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: snapshotMerklePathResult

Snapshot the provider envelope before inspecting proof availability or
diagnostics. The optional legacy array mode is bounded for older custom
WalletServices implementations; ordinary providers return one path.

```ts
export function snapshotMerklePathResult(value: unknown, allowLegacyArray = false, providerName?: string): SnapshotMerklePathResult
```

See also: [SnapshotMerklePathResult](./services.md#interface-snapshotmerklepathresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: snapshotPostBeefRequest

```ts
export function snapshotPostBeefRequest(beef: Beef, txids: string[]): ValidatedPostBeefRequest
```

See also: [ValidatedPostBeefRequest](./services.md#interface-validatedpostbeefrequest)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: stageTransactionOutputs

```ts
export function stageTransactionOutputs(state: ActionBatchPlannerState, tx: Transaction, dcr: Pick<StorageCreateActionResult, "outputs" | "derivationPrefix">): void
```

See also: [ActionBatchPlannerState](./client.md#interface-actionbatchplannerstate), [StorageCreateActionResult](./client.md#interface-storagecreateactionresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: stampLog

If a log is being kept, add a time stamped line.

```ts
export function stampLog(log: string | undefined | {
    log?: string;
}, lineToAdd: string): string | undefined
```

Returns

undefined or log extended by time stamped `lineToAdd` and new line.

Argument Details

+ **log**
  + Optional time stamped log to extend, or an object with a log property to update
+ **lineToAdd**
  + Content to add to line.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: stampLogFormat

Replaces individual timestamps with delta msecs.
Looks for two network crossings and adjusts clock for clock skew if found.
Assumes log built by repeated calls to `stampLog`

```ts
export function stampLogFormat(log?: string): string
```

Returns

reformated multi-line event log

Argument Details

+ **log**
  + Each logged event starts with ISO time stamp, space, rest of line, terminated by `\n`.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: stnArcadeUrl

Arcade broadcaster / ARC endpoint for stn, or `undefined` when unset.

```ts
export function stnArcadeUrl(): string | undefined
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: stnChaintracksUrl

ChainTracks service URL for stn. Falls back to the configured Arcade host's
legacy-compatible path when STN_CHAINTRACKS_URL is unset.

```ts
export function stnChaintracksUrl(): string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: subWork

Subtract Buffer encoded chainwork values

```ts
export function subWork(work1: string, work2: string): string
```

Returns

work1 - work2 as Buffer encoded chainWork value

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: supportedActionBatchPackEncodings

```ts
export function supportedActionBatchPackEncodings(): ActionBatchPackEncoding[]
```

See also: [ActionBatchPackEncoding](./client.md#type-actionbatchpackencoding)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: swapByteOrder

Returns a copy of a Buffer with byte order reversed.

```ts
export function swapByteOrder(buffer: number[]): number[] {
    return buffer.slice().reverse();
}
```

Returns

new buffer with byte order reversed.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: syncProofUpdatedAt

A local correction must be discoverable by subsequent incremental readers.

```ts
export function syncProofUpdatedAt(candidate: TableProvenTx, existing?: Date): Date
```

See also: [TableProvenTx](./storage.md#interface-tableproventx)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: targetForStorage

```ts
export function targetForStorage(args: Validation.ValidCreateActionArgs): Validation.ValidCreateActionArgs
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: throwDummyReviewActions

Throws a WERR_REVIEW_ACTIONS with a full set of properties to test data formats and propagation.

```ts
export function throwDummyReviewActions()
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: toBinaryBaseBlockHeader

Serializes a block header as an 80 byte array.
The exact serialized format is defined in the Bitcoin White Paper
such that computing a double sha256 hash of the array computes
the block hash for the header.

```ts
export function toBinaryBaseBlockHeader(header: BaseBlockHeader): number[] {
    const writer = new Utils.Writer();
    writer.writeUInt32LE(header.version);
    writer.writeReverse(asArray(header.previousHash));
    writer.writeReverse(asArray(header.merkleRoot));
    writer.writeUInt32LE(header.time);
    writer.writeUInt32LE(header.bits);
    writer.writeUInt32LE(header.nonce);
    const r = writer.toArray();
    return r;
}
```

See also: [BaseBlockHeader](./client.md#interface-baseblockheader), [asArray](./client.md#function-asarray), [writeUInt32LE](./services.md#function-writeuint32le)

Returns

80 byte array

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: toLookupNetworkPreset

Maps a Chain to a network preset suitable for LookupResolver / SHIPBroadcaster.
Unlike `toWalletNetwork`, this returns `'local'` for `mock` chain.

```ts
export function toLookupNetworkPreset(chain: Chain): "mainnet" | "testnet" | "teratestnet" | "local"
```

See also: [Chain](./client.md#type-chain)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: toWalletNetwork

```ts
export function toWalletNetwork(chain: Chain): WalletNetwork
```

See also: [Chain](./client.md#type-chain)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: transactionInputSize

```ts
export function transactionInputSize(scriptSize: number): number
```

Returns

serialized byte length a transaction input

Argument Details

+ **scriptSize**
  + byte length of input script

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: transactionOutputSize

```ts
export function transactionOutputSize(scriptSize: number): number
```

Returns

serialized byte length a transaction output

Argument Details

+ **scriptSize**
  + byte length of output script

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: transactionSize

Compute the serialized binary transaction size in bytes
given the number of inputs and outputs,
and the size of each script.

```ts
export function transactionSize(inputs: number[], outputs: number[]): number
```

Returns

total transaction size in bytes

Argument Details

+ **inputs**
  + array of input script lengths, in bytes
+ **outputs**
  + array of output script lengths, in bytes

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: tstnArcadeUrl

Arcade broadcaster / ARC endpoint for tstn, or `undefined` when `TSTN_ARCADE_URL` is unset.

```ts
export function tstnArcadeUrl(): string | undefined
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: tstnChaintracksUrl

ChainTracks service URL for tstn. Falls back to `${TSTN_ARCADE_URL}/chaintracks/v1` when
`TSTN_CHAINTRACKS_URL` is unset (mirrors the ttn layout). Throws when neither is configured.

```ts
export function tstnChaintracksUrl(): string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: updateChaintracksFiatExchangeRates

```ts
export async function updateChaintracksFiatExchangeRates(targetCurrencies: string[], options: WalletServicesOptions): Promise<FiatExchangeRates>
```

See also: [FiatExchangeRates](./client.md#interface-fiatexchangerates), [WalletServicesOptions](./client.md#interface-walletservicesoptions)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: updateExchangeratesapi

```ts
export async function updateExchangeratesapi(targetCurrencies: string[], options: WalletServicesOptions): Promise<FiatExchangeRates>
```

See also: [FiatExchangeRates](./client.md#interface-fiatexchangerates), [WalletServicesOptions](./client.md#interface-walletservicesoptions)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: updateReqsFromAggregateResults

```ts
export async function updateReqsFromAggregateResults(txids: string[], r: PostReqsToNetworkResult, apbrs: Record<string, AggregatePostBeefTxResult>, storage: StorageProvider, services?: sdk.WalletServices, trx?: sdk.TrxToken, logger?: WalletLoggerInterface): Promise<void>
```

See also: [AggregatePostBeefTxResult](./storage.md#interface-aggregatepostbeeftxresult), [PostReqsToNetworkResult](./storage.md#interface-postreqstonetworkresult), [StorageProvider](./storage.md#class-storageprovider), [TrxToken](./client.md#interface-trxtoken), [WalletServices](./client.md#interface-walletservices), [logger](./client.md#variable-logger)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: upgradeLegacyManagedChangeBasketDefault

Normalize a legacy default while retaining every other field and every
operator-selected non-default value. Used by migrations, sync, and restore.

```ts
export function upgradeLegacyManagedChangeBasketDefault<T extends ManagedChangeBasketDefaults>(basket: T): T
```

See also: [ManagedChangeBasketDefaults](./storage.md#interface-managedchangebasketdefaults)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validBulkHeaderFilesByFileHash

Hash map of known valid bulk header files by their `fileHash`.

```ts
export function validBulkHeaderFilesByFileHash(): Record<string, BulkHeaderFileInfo>
```

See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo)

Returns

object where keys are file hashes of known bulk header files.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateActionBatchInlinePayload

```ts
export function validateActionBatchInlinePayload(manifest: ActionBatchManifest): void
```

See also: [ActionBatchManifest](./client.md#interface-actionbatchmanifest)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateActionBatchSendWith

```ts
export function validateActionBatchSendWith(sendWith: unknown): void
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateAgainstDirtyHashes

Throws Error if blockHash is in the dirtyHashes list.

```ts
export function validateAgainstDirtyHashes(blockHash: string): void
```

See also: [blockHash](./services.md#function-blockhash)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateArcadeTxData

Validate and snapshot the untrusted Arcade `GET /tx/{txid}` response.

```ts
export function validateArcadeTxData(value: unknown, expectedTxid: string, responseStatus = 200): ArcMinerGetTxData
```

See also: [ArcMinerGetTxData](./services.md#interface-arcminergettxdata)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateBaseBlockHeaderFormat

Validates the exact data representation of an unpositioned 80-byte block
header before it reaches a chain lookup, queue, or serializer.

```ts
export function validateBaseBlockHeaderFormat(header: BaseBlockHeader): void
```

See also: [BaseBlockHeader](./client.md#interface-baseblockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateBufferOfHeaders

Validate headers contained in an array of bytes. The headers must be consecutive block headers, 80 bytes long,
 where the hash of each header equals the previousHash of the following header.

```ts
export function validateBufferOfHeaders(buffer: Uint8Array, previousHash: string, offset = 0, count = -1, previousChainWork?: string, chain?: Chain): {
    lastHeaderHash: string;
    lastChainWork: string | undefined;
}
```

See also: [Chain](./client.md#type-chain)

Returns

Header hash of last header validated or previousHash if there where none.

Argument Details

+ **buffer**
  + Buffer of headers to be validated.
+ **previousHash**
  + Expected previousHash of first header.
+ **offset**
  + Optional starting offset within `buffer`.
+ **count**
  + Optional number of headers to validate. Validates to end of buffer if missing.
+ **previousChainWork**
  + Optional chain work through `previousHash`; when present, the result carries it forward.
+ **chain**
  + Optional chain the headers belong to. Selects its proof-of-work limit
(see `proofOfWorkLimitBits`); omitted means the mainnet limit.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateBulkFileData

Validates the contents of a bulk header file.

```ts
export async function validateBulkFileData(bf: BulkHeaderFileInfo, prevHash: string, prevChainWork: string, fetch?: ChaintracksFetchApi): Promise<BulkHeaderFileInfo>
```

See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo), [ChaintracksFetchApi](./services.md#interface-chaintracksfetchapi)

Returns

Validated BulkHeaderFileInfo with `validated` set to true.

Argument Details

+ **bf**
  + BulkHeaderFileInfo containing `data` to validate.
+ **prevHash**
  + Required previous header hash.
+ **prevChainWork**
  + Required previous chain work.
+ **fetch**
  + Optional ChaintracksFetchApi instance for fetching data.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateCompactManifest

```ts
export function validateCompactManifest(manifest: ActionBatchManifest, requireUploaded: boolean = false): void
```

See also: [ActionBatchManifest](./client.md#interface-actionbatchmanifest)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateGenerateChangeSdkParams

```ts
export function validateGenerateChangeSdkParams(params: GenerateChangeSdkParams): ValidateGenerateChangeSdkParamsResult
```

See also: [GenerateChangeSdkParams](./storage.md#interface-generatechangesdkparams), [ValidateGenerateChangeSdkParamsResult](./storage.md#interface-validategeneratechangesdkparamsresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateGenerateChangeSdkResult

```ts
export function validateGenerateChangeSdkResult(params: GenerateChangeSdkParams, r: GenerateChangeSdkResult): {
    ok: boolean;
    log: string;
}
```

See also: [GenerateChangeSdkParams](./storage.md#interface-generatechangesdkparams), [GenerateChangeSdkResult](./storage.md#interface-generatechangesdkresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateGenesisHeader

Verifies that buffer begins with valid genesis block header for the specified chain.

```ts
export function validateGenesisHeader(buffer: Uint8Array, chain: Chain): void
```

See also: [Chain](./client.md#type-chain)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateHeaderDifficulty

Ensures that a header has a valid proof-of-work target and hash.

```ts
export function validateHeaderDifficulty(hash: number[] | Uint8Array, bits: number, chain?: Chain)
```

See also: [Chain](./client.md#type-chain)

Returns

true if the header is valid

Argument Details

+ **hash**
  + The header hash, big-endian.
+ **bits**
  + The header's compact target.
+ **chain**
  + Optional chain the header belongs to. Selects its proof-of-work limit
(see `proofOfWorkLimitBits`); omitted means the mainnet limit.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateHeaderFormat

```ts
export function validateHeaderFormat(header: BlockHeader): void
```

See also: [BlockHeader](./client.md#interface-blockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateHeaderProofOfWork

Ensures that a structured header's computed hash satisfies its declared
proof-of-work target.

```ts
export function validateHeaderProofOfWork(header: BlockHeader, chain?: Chain): true {
    validateConsensusProofOfWork(header.hash, header.bits, chain);
    return true;
}
```

See also: [BlockHeader](./client.md#interface-blockheader), [Chain](./client.md#type-chain)

Returns

true if the header has valid proof-of-work.

Argument Details

+ **header**
  + Header whose format and hash have already been checked.
+ **chain**
  + Optional chain the header belongs to. Selects its proof-of-work limit
(see `proofOfWorkLimitBits`); omitted means the mainnet limit.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateManagedChangePolicy

```ts
export function validateManagedChangePolicy(options?: ManagedChangePolicyOptions): ManagedChangePolicy
```

See also: [ManagedChangePolicy](./storage.md#interface-managedchangepolicy), [ManagedChangePolicyOptions](./storage.md#type-managedchangepolicyoptions)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateManifestActions

```ts
export async function validateManifestActions(storage: StorageProvider, batch: TableActionBatch, manifest: ActionBatchManifest): Promise<{
    actions: ValidatedBatchAction[];
    dependencyBeef: Uint8Array;
    beef: Beef;
}>
```

See also: [ActionBatchManifest](./client.md#interface-actionbatchmanifest), [StorageProvider](./storage.md#class-storageprovider), [TableActionBatch](./storage.md#interface-tableactionbatch), [ValidatedBatchAction](./storage.md#interface-validatedbatchaction)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateMerklePathResult

```ts
export function validateMerklePathResult(requestedTxid: unknown, result: GetMerklePathResult, requireProofOfWork = false, requireHeaderFormat = true, chain?: Chain): ValidatedMerklePathResult
```

See also: [Chain](./client.md#type-chain), [GetMerklePathResult](./client.md#interface-getmerklepathresult), [ValidatedMerklePathResult](./services.md#interface-validatedmerklepathresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateMonitorOptions

```ts
export function validateMonitorOptions(value: unknown): void
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateNoSendExpiryRequest

```ts
export function validateNoSendExpiryRequest(args: Validation.ValidCreateActionArgs): ReturnType<typeof parseBrc177NoSendExpiryLabels>
```

See also: [parseBrc177NoSendExpiryLabels](./client.md#function-parsebrc177nosendexpirylabels)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validatePostBeefResult

```ts
export function validatePostBeefResult(value: unknown, expectedTxids: string[], configuredProviderName: string, allowInternalTimeoutNote = false): PostBeefResult
```

See also: [PostBeefResult](./client.md#interface-postbeefresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validatePostBeefResultOrServiceError

```ts
export function validatePostBeefResultOrServiceError(value: unknown, expectedTxids: string[], configuredProviderName: string): PostBeefResult
```

See also: [PostBeefResult](./client.md#interface-postbeefresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validatePostTxResult

```ts
export function validatePostTxResult(value: unknown, expectedTxid: string, configuredProviderName: string): PostTxResultForTxid
```

See also: [PostTxResultForTxid](./client.md#interface-posttxresultfortxid)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validatePostTxResultOrServiceError

```ts
export function validatePostTxResultOrServiceError(value: unknown, expectedTxid: string, configuredProviderName: string): PostTxResultForTxid
```

See also: [PostTxResultForTxid](./client.md#interface-posttxresultfortxid)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validatePreparedBeefPolicy

```ts
export function validatePreparedBeefPolicy(options?: PreparedBeefOptions): PreparedBeefPolicy
```

See also: [PreparedBeefOptions](./storage.md#interface-preparedbeefoptions), [PreparedBeefPolicy](./storage.md#interface-preparedbeefpolicy)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateRawTxResult

Snapshot and bind a raw-transaction provider result to its requested txid.

```ts
export function validateRawTxResult(value: unknown, expectedTxid: string, providerName?: string): GetRawTxResult
```

See also: [GetRawTxResult](./client.md#interface-getrawtxresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateRequiredInputs

Verify that we are in posession of validity proof data for any inputs being proposed for a new transaction.

`vargs.inputs` is the source of inputs.
`vargs.inputBEEF` may include new user supplied validity data.
'vargs.options.trustSelf === 'known'` indicates whether we can rely on the storage database records.

If there are no inputs, returns an empty `Beef`.

Always pulls rawTx data into first level of validity chains so that parsed transaction data is available
and checks input sourceSatoshis as well as filling in input sourceLockingScript.

This data may be pruned again before being returned to the user based on `vargs.options.knownTxids`.

```ts
export async function validateRequiredInputs(storage: StorageProvider, userId: number, vargs: Validation.ValidCreateActionArgs): Promise<{
    storageBeef: Beef;
    beef: Beef;
    xinputs: XValidCreateActionInput[];
}>
```

See also: [StorageProvider](./storage.md#class-storageprovider), [XValidCreateActionInput](./storage.md#interface-xvalidcreateactioninput)

Returns

containing only validity proof data for only unknown required inputs.

containing verified validity proof data for all required inputs.

extended validated required inputs.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateRequiredOutputs

Convert vargs.outputs:

lockingScript: HexString
satoshis: SatoshiValue
outputDescription: DescriptionString5to50Bytes
basket?: BasketStringUnder300Bytes
customInstructions?: string
tags: BasketStringUnderBytes[]

to XValidCreateActionOutput (which aims for StorageCreateTransactionSdkOutput)

adds:
  vout: number
  providedBy: StorageProvidedBy
  purpose?: string
  derivationSuffix?: string
  keyOffset?: string

```ts
export function validateRequiredOutputs(storage: StorageProvider, userId: number, vargs: Validation.ValidCreateActionArgs): XValidCreateActionOutput[]
```

See also: [StorageProvider](./storage.md#class-storageprovider), [XValidCreateActionOutput](./storage.md#interface-xvalidcreateactionoutput)

Returns

xoutputs

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateScriptHash

```ts
export function validateScriptHash(output: string, outputFormat?: GetUtxoStatusOutputFormat): string
```

See also: [GetUtxoStatusOutputFormat](./client.md#type-getutxostatusoutputformat)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateScriptHashHistoryResult

Validate and own a script-history result before it contributes competing transaction IDs.

```ts
export function validateScriptHashHistoryResult(value: unknown, configuredProviderName?: string): GetScriptHashHistoryResult
```

See also: [GetScriptHashHistoryResult](./client.md#interface-getscripthashhistoryresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateSecondsSinceEpoch

```ts
export function validateSecondsSinceEpoch(time: number): Date
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateStatusForTxidsResult

Copy and validate an external transaction-status provider response before it
can influence wallet transaction state. Provider names may be replaced with
a locally configured name so remote data cannot forge durable attribution.

```ts
export function validateStatusForTxidsResult(value: unknown, requestedTxids: readonly string[], providerName?: string): GetStatusForTxidsResult
```

See also: [GetStatusForTxidsResult](./client.md#interface-getstatusfortxidsresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateStorageFeeModel

```ts
export function validateStorageFeeModel(v?: StorageFeeModel): StorageFeeModel
```

See also: [StorageFeeModel](./client.md#interface-storagefeemodel)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateSyncCheckpoint

Validate remote progress and return only the fields permitted to advance a sync.

```ts
export function validateSyncCheckpoint(value: SyncCheckpoint, previous?: Partial<SyncCheckpoint>): SyncCheckpoint
```

See also: [SyncCheckpoint](./client.md#interface-synccheckpoint)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateSyncProof

Validate proof authority before an RPC proof is admitted or an in-process
backup/conflict proof replaces an existing global row. Network-backed checks
run before the storage merge transaction is opened.

```ts
export async function validateSyncProof(storage: SyncProofValidationStorage, candidate: TableProvenTx): Promise<void>
```

See also: [SyncProofValidationStorage](./storage.md#interface-syncproofvalidationstorage), [TableProvenTx](./storage.md#interface-tableproventx)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateTrustSettings

```ts
export function validateTrustSettings(value: unknown): TrustSettings
```

See also: [TrustSettings](./client.md#interface-trustsettings)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateUtxoStatusResult

Validate, bind, and own a UTXO-oracle result before wallet state uses it.

```ts
export function validateUtxoStatusResult(value: unknown, expectedOutpoint?: string, configuredProviderName?: string): GetUtxoStatusResult
```

See also: [GetUtxoStatusResult](./client.md#interface-getutxostatusresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateWalletSettings

```ts
export function validateWalletSettings(value: unknown): WalletSettings
```

See also: [WalletSettings](./client.md#interface-walletsettings)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: validateWocChainInfo

```ts
export function validateWocChainInfo(value: unknown, expectedChain: Chain): WocChainInfo
```

See also: [Chain](./client.md#type-chain), [WocChainInfo](./services.md#interface-wocchaininfo)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: varUintSize

Returns the byte size required to encode number as Bitcoin VarUint

```ts
export function varUintSize(val: number): 1 | 3 | 5 | 9 {
    if (val < 0)
        throw new WERR_INVALID_PARAMETER("varUint", "non-negative");
    if (val <= 252)
        return 1;
    if (val <= 65535)
        return 3;
    if (val <= 4294967295)
        return 5;
    return 9;
}
```

See also: [WERR_INVALID_PARAMETER](./client.md#class-werr_invalid_parameter)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: verifyActionBatchManifestDigest

```ts
export function verifyActionBatchManifestDigest(manifest: ActionBatchManifest): boolean
```

See also: [ActionBatchManifest](./client.md#interface-actionbatchmanifest)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: verifyHexString

Helper function.

Verifies that a hex string is trimmed and lower case.

```ts
export function verifyHexString(v: string): string
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: verifyId

Helper function.

Verifies that a database record identifier is an integer greater than zero.

```ts
export function verifyId(id: number | undefined | null): number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: verifyInteger

Helper function.

Verifies that an optional or null number has a numeric value.

```ts
export function verifyInteger(v: number | null | undefined): number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: verifyNumber

Helper function.

Verifies that an optional or null number has a numeric value.

```ts
export function verifyNumber(v: number | null | undefined): number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: verifyOne

Helper function.

```ts
export function verifyOne<T>(results: T[], errorDescrition?: string): T
```

Returns

results[0].

Throws

WERR_BAD_REQUEST if results has length other than one.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: verifyOneOrNone

Helper function.

```ts
export function verifyOneOrNone<T>(results: T[]): T | undefined
```

Returns

results[0] or undefined if length is zero.

Throws

WERR_BAD_REQUEST if results has length greater than one.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: verifyOptionalHexString

Helper function.

Verifies that an optional or null hex string is undefined or a trimmed lowercase string.

```ts
export function verifyOptionalHexString(v?: string | null): string | undefined
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: verifyRequestedOutputsUnchanged

Verify that the outputs returned by storage for caller-specified outputs match
exactly what the caller requested in `args.outputs`.

The storage response (`StorageCreateActionResult.outputs`) is ordered, by
contract, as: the caller's `args.outputs` in their original order, followed by
the optional commission output, followed by storage-provided change outputs.
Only the `vout` field is randomized when `randomizeOutputs` is set; the array
order is stable. Therefore array index `i` (for `i < args.outputs.length`)
corresponds to `args.outputs[i]`.

Because the locking script that is ultimately signed is taken from the storage
response, an untrusted storage provider must not be allowed to alter the
recipient script (or amount) of a caller-specified output. Any mismatch is a
hard error. (GHSA-36f9-7rg5-cpf8)

```ts
export function verifyRequestedOutputsUnchanged(storageOutputs: StorageCreateTransactionSdkOutput[], args: Validation.ValidCreateActionArgs): void
```

See also: [StorageCreateTransactionSdkOutput](./client.md#interface-storagecreatetransactionsdkoutput)

Throws

WERR_INVALID_PARAMETER if storage omitted, reclassified, or modified
any caller-specified output.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: verifyTruthy

Helper function.

Verifies that a possibly optional value has a value.

```ts
export function verifyTruthy<T>(v: T | null | undefined, description?: string): T
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: verifyUnlockScripts

```ts
export async function verifyUnlockScripts(txid: string, beef: Beef, verifier?: SpendVerifierInterface): Promise<UnlockScriptVerificationResult>
```

See also: [UnlockScriptVerificationResult](./client.md#interface-unlockscriptverificationresult)

Argument Details

+ **txid**
  + The TXID of a transaction in the beef for which all unlocking scripts must be valid.
+ **beef**
  + Must contain transactions for txid and all its inputs.

Throws

WERR_INVALID_PARAMETER if any unlocking script is invalid, if sourceTXID is invalid, if beef doesn't contain required transactions.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: verifyUnlockScriptsBatch

Verifies every resolvable input from several transactions in one optional
backend batch while preserving per-transaction verification counts.

```ts
export async function verifyUnlockScriptsBatch(txids: readonly string[], beef: Beef, verifier?: SpendVerifierInterface): Promise<UnlockScriptVerificationResult[]>
```

See also: [UnlockScriptVerificationResult](./client.md#interface-unlockscriptverificationresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: verifyUnrequestedOutputsAreChangeOrCommission

Verify that every storage output beyond the caller's requested outputs is
either a change output or the (single, bounded) commission output.

The storage response is ordered `[caller outputs][commission?][change...]`;
`verifyRequestedOutputsUnchanged` already validates the caller region (indices
`< args.outputs.length`). This checks the remainder.

Change outputs (`providedBy: 'storage', purpose: 'change'`) are safe at any
amount: `buildSignableTransaction` ignores the storage-supplied script and
re-derives it client-side (`makeChangeLock` / BRC-29 under the client's own
change key), so a change output can only ever pay the client. A change output
mislabeled by storage is therefore harmless.

The commission output's script, by contrast, is taken verbatim from storage
and cannot be verified client-side. A malicious storage could inject an extra
output — or relabel one as commission — to redirect funds to an attacker while
the caller/UI only sees the requested recipients. To bound that, at most one
commission output is allowed and its amount must not exceed `maxCommission`.
Any other unrecognized output is rejected outright.

```ts
export function verifyUnrequestedOutputsAreChangeOrCommission(storageOutputs: StorageCreateTransactionSdkOutput[], args: Validation.ValidCreateActionArgs, maxCommission: number = MAX_STORAGE_COMMISSION_SATOSHIS): void
```

See also: [MAX_STORAGE_COMMISSION_SATOSHIS](./client.md#variable-max_storage_commission_satoshis), [StorageCreateTransactionSdkOutput](./client.md#interface-storagecreatetransactionsdkoutput)

Throws

WERR_INVALID_PARAMETER if storage returned an unrecognized output, more
than one commission output, or a commission exceeding `maxCommission`.

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: wait

Returns an await'able Promise that resolves in the given number of msecs.

```ts
export async function wait(msecs: number): Promise<void> {
    const MIN_WAIT = 0;
    const MAX_WAIT = 2 * 60 * 1000;
    if (typeof msecs !== "number" ||
        !Number.isFinite(msecs) ||
        Number.isNaN(msecs) ||
        msecs < MIN_WAIT ||
        msecs > MAX_WAIT) {
        throw new WERR_INVALID_PARAMETER("msecs", `a number between ${MIN_WAIT} and ${MAX_WAIT} msecs, not ${msecs}.`);
    }
    return await new Promise(resolve => setTimeout(resolve, msecs));
}
```

See also: [WERR_INVALID_PARAMETER](./client.md#class-werr_invalid_parameter)

Argument Details

+ **msecs**
  + number of milliseconds to wait before resolving the promise.
Must be greater than zero and less than 2 minutes (120,000 msecs)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: workBNtoBuffer

```ts
export function workBNtoBuffer(work: BigNumber): string
```

Returns

Converted chainWork value from BN to hex string of 32 bytes.

Argument Details

+ **work**
  + chainWork as a BigNumber

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: writeUInt32BE

```ts
export function writeUInt32BE(n: number, a: number[] | Uint8Array, offset: number): number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Function: writeUInt32LE

```ts
export function writeUInt32LE(n: number, a: number[] | Uint8Array, offset: number): number
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
#### Types

| | | |
| --- | --- | --- |
| [ActionBatchErrorState](#type-actionbatcherrorstate) | [GetMerklePathService](#type-getmerklepathservice) | [PostReqsToNetworkDetailsStatus](#type-postreqstonetworkdetailsstatus) |
| [ActionBatchMode](#type-actionbatchmode) | [GetRawTxService](#type-getrawtxservice) | [PostTxsService](#type-posttxsservice) |
| [ActionBatchPackEncoding](#type-actionbatchpackencoding) | [GetScriptHashHistoryService](#type-getscripthashhistoryservice) | [PreparedBeefState](#type-preparedbeefstate) |
| [ActionBatchStatus](#type-actionbatchstatus) | [GetStatusForTxidsService](#type-getstatusfortxidsservice) | [ProvenTxReqStatus](#type-proventxreqstatus) |
| [AnyBlockHeader](#type-anyblockheader) | [GetUtxoStatusOutputFormat](#type-getutxostatusoutputformat) | [ReorgListener](#type-reorglistener) |
| [Brc177CreateActionMetadata](#type-brc177createactionmetadata) | [GetUtxoStatusService](#type-getutxostatusservice) | [ReviewActionResultStatus](#type-reviewactionresultstatus) |
| [Brc177NoSendExpiryMode](#type-brc177nosendexpirymode) | [HeaderListener](#type-headerlistener) | [ScriptHashFormat](#type-scripthashformat) |
| [Brc177NoSendExpiryState](#type-brc177nosendexpirystate) | [InsertHeaderResult](#type-insertheaderresult) | [StorageProvidedBy](#type-storageprovidedby) |
| [Brc177ValidCreateActionArgs](#type-brc177validcreateactionargs) | [ManagedChangeInputCandidate](#type-managedchangeinputcandidate) | [SyncProtocolVersion](#type-syncprotocolversion) |
| [ByteEncoding](#type-byteencoding) | [ManagedChangePolicyOptions](#type-managedchangepolicyoptions) | [SyncStatus](#type-syncstatus) |
| [ByteInput](#type-byteinput) | [MerklePathNoteWhat](#type-merklepathnotewhat) | [TransactionStatus](#type-transactionstatus) |
| [Chain](#type-chain) | [MonitorStartupTaskMode](#type-monitorstartuptaskmode) | [UpdateFiatExchangeRateService](#type-updatefiatexchangerateservice) |
| [DBType](#type-dbtype) | [MonitorStorage](#type-monitorstorage) | [UtxoReviewReleaseMode](#type-utxoreviewreleasemode) |
| [EntityStorage](#type-entitystorage) | [OutputUtxoVerdict](#type-outpututxoverdict) |  |
| [FiatCurrencyCode](#type-fiatcurrencycode) | [PostBeefService](#type-postbeefservice) |  |

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---

##### Type: ActionBatchErrorState

```ts
export type ActionBatchErrorState = "missing" | "expired" | "hard-expired" | "inactive" | "conflicted" | "aborted" | "committed"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: ActionBatchMode

```ts
export type ActionBatchMode = "auto" | "legacy"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: ActionBatchPackEncoding

```ts
export type ActionBatchPackEncoding = "identity" | "gzip" | "brotli"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: ActionBatchStatus

```ts
export type ActionBatchStatus = "active" | "prepared" | "committed" | "aborted" | "expired"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: AnyBlockHeader

Union of all block header variants

```ts
export type AnyBlockHeader = BaseBlockHeader | BlockHeader | LiveBlockHeader
```

See also: [BaseBlockHeader](./client.md#interface-baseblockheader), [BlockHeader](./client.md#interface-blockheader), [LiveBlockHeader](./services.md#interface-liveblockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: Brc177CreateActionMetadata

```ts
export type Brc177CreateActionMetadata = Brc177FundingCreateActionMetadata | Brc177ProtectedCreateActionMetadata
```

See also: [Brc177FundingCreateActionMetadata](./client.md#interface-brc177fundingcreateactionmetadata), [Brc177ProtectedCreateActionMetadata](./client.md#interface-brc177protectedcreateactionmetadata)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: Brc177NoSendExpiryMode

```ts
export type Brc177NoSendExpiryMode = "seconds" | "timestamp" | "blockheight"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: Brc177NoSendExpiryState

```ts
export type Brc177NoSendExpiryState = "preparing" | "unsigned" | "signed" | "revocation-requested" | "broadcast" | "reclaiming" | "reclaimed" | "target-won" | "conflicted" | "cancelled"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: Brc177ValidCreateActionArgs

```ts
export type Brc177ValidCreateActionArgs = Validation.ValidCreateActionArgs & {
    brc177?: Brc177CreateActionMetadata;
}
```

See also: [Brc177CreateActionMetadata](./client.md#type-brc177createactionmetadata)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: ByteEncoding

Encoding identifier for buffer-coercion helpers

```ts
export type ByteEncoding = "hex" | "utf8" | "base64"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: ByteInput

Byte array, string, or Uint8Array accepted by buffer-coercion helpers

```ts
export type ByteInput = string | number[] | Uint8Array
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: Chain

```ts
export type Chain = "main" | "test" | "stn" | "ttn" | "tstn" | "regtest" | "mock"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: DBType

```ts
export type DBType = "SQLite" | "MySQL" | "IndexedDB"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: EntityStorage

```ts
export type EntityStorage = StorageProvider
```

See also: [StorageProvider](./storage.md#class-storageprovider)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: FiatCurrencyCode

```ts
export type FiatCurrencyCode = "USD" | "EUR" | "GBP" | "JPY" | "CNY" | "INR" | "AUD" | "CAD" | "CHF" | "HKD" | "SGD" | "NZD" | "SEK" | "NOK" | "MXN"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: GetMerklePathService

```ts
export type GetMerklePathService = (txid: string, services: WalletServices) => Promise<GetMerklePathResult>
```

See also: [GetMerklePathResult](./client.md#interface-getmerklepathresult), [WalletServices](./client.md#interface-walletservices)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: GetRawTxService

```ts
export type GetRawTxService = (txid: string, chain: Chain) => Promise<GetRawTxResult>
```

See also: [Chain](./client.md#type-chain), [GetRawTxResult](./client.md#interface-getrawtxresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: GetScriptHashHistoryService

```ts
export type GetScriptHashHistoryService = (hash: string) => Promise<GetScriptHashHistoryResult>
```

See also: [GetScriptHashHistoryResult](./client.md#interface-getscripthashhistoryresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: GetStatusForTxidsService

```ts
export type GetStatusForTxidsService = (txids: string[]) => Promise<GetStatusForTxidsResult>
```

See also: [GetStatusForTxidsResult](./client.md#interface-getstatusfortxidsresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: GetUtxoStatusOutputFormat

```ts
export type GetUtxoStatusOutputFormat = "hashLE" | "hashBE" | "script"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: GetUtxoStatusService

```ts
export type GetUtxoStatusService = (output: string, outputFormat?: GetUtxoStatusOutputFormat, outpoint?: string) => Promise<GetUtxoStatusResult>
```

See also: [GetUtxoStatusOutputFormat](./client.md#type-getutxostatusoutputformat), [GetUtxoStatusResult](./client.md#interface-getutxostatusresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: HeaderListener

```ts
export type HeaderListener = (header: BlockHeader) => void
```

See also: [BlockHeader](./client.md#interface-blockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: InsertHeaderResult

```ts
export type InsertHeaderResult = {
    added: boolean;
    dupe: boolean;
    isActiveTip: boolean;
    reorgDepth: number;
    priorTip: LiveBlockHeader | undefined;
    deactivatedHeaders: LiveBlockHeader[];
    noPrev: boolean;
    badPrev: boolean;
    noActiveAncestor: boolean;
    noTip: boolean;
}
```

See also: [LiveBlockHeader](./services.md#interface-liveblockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: ManagedChangeInputCandidate

```ts
export type ManagedChangeInputCandidate = Pick<TableOutput, "outputId" | "transactionId" | "satoshis" | "txid" | "vout"> & {
    transactionStatus?: TransactionStatus;
}
```

See also: [TableOutput](./storage.md#interface-tableoutput), [TransactionStatus](./client.md#type-transactionstatus)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: ManagedChangePolicyOptions

```ts
export type ManagedChangePolicyOptions = Partial<ManagedChangePolicy>
```

See also: [ManagedChangePolicy](./storage.md#interface-managedchangepolicy)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: MerklePathNoteWhat

```ts
export type MerklePathNoteWhat = "getMerklePathRetry" | "getMerklePathNotFound" | "getMerklePathBadStatus" | "getMerklePathNoData" | "getMerklePathSuccess" | "getMerklePathNoHeader" | "getMerklePathError" | "getMerklePathInternal"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: MonitorStartupTaskMode

```ts
export type MonitorStartupTaskMode = "none" | "default" | "multiuser" | "alltoother"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: MonitorStorage

```ts
export type MonitorStorage = WalletStorageManager
```

See also: [WalletStorageManager](./storage.md#class-walletstoragemanager)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: OutputUtxoVerdict

```ts
export type OutputUtxoVerdict = "unspent" | "spent" | "unknown"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: PostBeefService

```ts
export type PostBeefService = (beef: Beef, txids: string[]) => Promise<PostBeefResult>
```

See also: [PostBeefResult](./client.md#interface-postbeefresult)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: PostReqsToNetworkDetailsStatus

Indicates status of a new Action following a `createAction` or `signAction` in immediate mode:
When `acceptDelayedBroadcast` is falses.

'success': The action has been broadcast and accepted by the bitcoin processing network.
'doubleSpend': The action has been confirmed to double spend one or more inputs, and by the "first-seen-rule" is the losing transaction.
'invalidTx': The action was rejected by the processing network as an invalid bitcoin transaction.
'serviceError': The broadcast services are currently unable to reach the bitcoin network. The action is now queued for delayed retries.

'invalid': The action was in an invalid state for processing, this status should never be seen by user code.
'unknown': An internal processing error has occured, this status should never be seen by user code.

```ts
export type PostReqsToNetworkDetailsStatus = "success" | "doubleSpend" | "unknown" | "invalid" | "serviceError" | "invalidTx"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: PostTxsService

```ts
export type PostTxsService = (beef: Beef, txids: string[], services: WalletServices) => Promise<PostTxsResult>
```

See also: [PostTxsResult](./client.md#interface-posttxsresult), [WalletServices](./client.md#interface-walletservices)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: PreparedBeefState

```ts
export type PreparedBeefState = "ready" | "stale" | "failed"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: ProvenTxReqStatus

Initial status (attempts === 0):

nosend: transaction was marked 'noSend'. It is complete and signed. It may be sent by an external party. Proof should be sought as if 'unmined'. No error if it remains unknown by network.

unprocessed: indicates req is about to be posted to network by non-acceptDelayedBroadcast application code, after posting status is normally advanced to 'sending'

unsent: rawTx has not yet been sent to the network for processing. req is queued for delayed processing.

sending: At least one attempt to send rawTx to transaction processors has occured without confirmation of acceptance.

unknown: rawTx status is unknown but is believed to have been previously sent to the network.

Attempts > 0 status, processing:

unknown: Last status update received did not recognize txid or wasn't understood.

nonfinal: rawTx has an un-expired nLockTime and is eligible for continuous updating by new transactions with additional outputs and incrementing sequence numbers.

unmined: Last attempt has txid waiting to be mined, possibly just sent without callback

callback: Waiting for proof confirmation callback from transaction processor.

unconfirmed: Potential proof has not been confirmed by chaintracks

Terminal status:

doubleSpend: Transaction spends same input as another transaction.

invalid: rawTx is structuraly invalid or was rejected by the network. Will never be re-attempted or completed.

completed: proven_txs record added, and notifications are complete.

unfail: asigned to force review of a currently invalid ProvenTxReq.

```ts
export type ProvenTxReqStatus = "sending" | "unsent" | "nosend" | "unknown" | "nonfinal" | "unprocessed" | "unmined" | "callback" | "unconfirmed" | "completed" | "invalid" | "doubleSpend" | "unfail"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: ReorgListener

```ts
export type ReorgListener = (depth: number, oldTip: BlockHeader, newTip: BlockHeader, deactivatedHeaders?: BlockHeader[]) => void
```

See also: [BlockHeader](./client.md#interface-blockheader)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: ReviewActionResultStatus

Indicates status of a new Action following a `createAction` or `signAction` in immediate mode:
When `acceptDelayedBroadcast` is falses.

'success': The action has been broadcast and accepted by the bitcoin processing network.
'doubleSpend': The action has been confirmed to double spend one or more inputs, and by the "first-seen-rule" is the losing transaction.
'invalidTx': The action was rejected by the processing network as an invalid bitcoin transaction.
'serviceError': The broadcast services are currently unable to reach the bitcoin network. The action is now queued for delayed retries.

```ts
export type ReviewActionResultStatus = "success" | "doubleSpend" | "serviceError" | "invalidTx"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: ScriptHashFormat

```ts
export type ScriptHashFormat = "hashLE" | "hashBE" | "script"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: StorageProvidedBy

```ts
export type StorageProvidedBy = "you" | "storage" | "you-and-storage"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: SyncProtocolVersion

```ts
export type SyncProtocolVersion = "0.1.0"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: SyncStatus

success: Last sync of this user from this storage was successful.

error: Last sync protocol operation for this user to this storage threw and error.

identified: Configured sync storage has been identified but not sync'ed.

unknown: Sync protocol state is unknown.

```ts
export type SyncStatus = "success" | "error" | "identified" | "updated" | "unknown"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: TransactionStatus

```ts
export type TransactionStatus = "completed" | "failed" | "unprocessed" | "sending" | "unproven" | "unsigned" | "nosend" | "nonfinal" | "unfail"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: UpdateFiatExchangeRateService

```ts
export type UpdateFiatExchangeRateService = (targetCurrencies: string[], options: WalletServicesOptions) => Promise<FiatExchangeRates>
```

See also: [FiatExchangeRates](./client.md#interface-fiatexchangerates), [WalletServicesOptions](./client.md#interface-walletservicesoptions)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Type: UtxoReviewReleaseMode

```ts
export type UtxoReviewReleaseMode = "none" | "atomic" | "conclusive"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
#### Variables

| | | |
| --- | --- | --- |
| [ACTION_BATCH_HARD_LIFETIME_MS](#variable-action_batch_hard_lifetime_ms) | [MAX_FIAT_RATE](#variable-max_fiat_rate) | [dirtyHashes](#variable-dirtyhashes) |
| [ACTION_BATCH_LEASE_MS](#variable-action_batch_lease_ms) | [MAX_FIAT_RESPONSE_RATES](#variable-max_fiat_response_rates) | [exactActionSpendSymbol](#variable-exactactionspendsymbol) |
| [ACTION_BATCH_MAX_BLOB_BYTES](#variable-action_batch_max_blob_bytes) | [MAX_MONITOR_HEIGHT](#variable-max_monitor_height) | [logger](#variable-logger) |
| [ACTION_BATCH_MAX_CONCURRENT_UPLOADS](#variable-action_batch_max_concurrent_uploads) | [MAX_MONITOR_INTERVAL_MSECS](#variable-max_monitor_interval_msecs) | [managedChangeOutputFields](#variable-managedchangeoutputfields) |
| [ACTION_BATCH_MAX_INLINE_BYTES](#variable-action_batch_max_inline_bytes) | [MAX_MONITOR_OFFSET](#variable-max_monitor_offset) | [maxChangeOutputsPerTransaction](#variable-maxchangeoutputspertransaction) |
| [ACTION_BATCH_MAX_PACK_BYTES](#variable-action_batch_max_pack_bytes) | [MAX_MONITOR_PAGE_SIZE](#variable-max_monitor_page_size) | [maxPossibleSatoshis](#variable-maxpossiblesatoshis) |
| [ACTION_BATCH_MAX_PACK_ITEMS](#variable-action_batch_max_pack_items) | [MAX_POST_BEEF_BYTES](#variable-max_post_beef_bytes) | [outputColumnsWithoutLockingScript](#variable-outputcolumnswithoutlockingscript) |
| [ACTION_BATCH_MAX_RESERVATION_EXTENSION_OUTPUTS](#variable-action_batch_max_reservation_extension_outputs) | [MAX_POST_BEEF_TXIDS](#variable-max_post_beef_txids) | [parseResults](#variable-parseresults) |
| [ACTION_BATCH_MAX_RESERVED_OUTPUTS](#variable-action_batch_max_reserved_outputs) | [MAX_RAW_TRANSACTION_BYTES](#variable-max_raw_transaction_bytes) | [queryOverlay](#variable-queryoverlay) |
| [ACTION_BATCH_PACK_ENCODING_HEADER](#variable-action_batch_pack_encoding_header) | [MAX_SCRIPT_HASH_HISTORY_ITEMS](#variable-max_script_hash_history_items) | [specOpFailedActions](#variable-specopfailedactions) |
| [ARCADE_POST_BEEF_CONCURRENCY](#variable-arcade_post_beef_concurrency) | [MAX_STORAGE_COMMISSION_SATOSHIS](#variable-max_storage_commission_satoshis) | [specOpInvalidChange](#variable-specopinvalidchange) |
| [BRC177_NO_SEND_EXPIRY_PREFIX](#variable-brc177_no_send_expiry_prefix) | [MAX_UTXO_REVIEW_CANDIDATES](#variable-max_utxo_review_candidates) | [specOpNoSendActions](#variable-specopnosendactions) |
| [BRC177_NO_SEND_MODULE_PREFIX](#variable-brc177_no_send_module_prefix) | [MAX_UTXO_STATUS_DETAILS](#variable-max_utxo_status_details) | [specOpSetWalletChangeParams](#variable-specopsetwalletchangeparams) |
| [DEFAULT_MANAGED_CHANGE_MAX_OUTPUTS_PER_ACTION](#variable-default_managed_change_max_outputs_per_action) | [PREPARED_BEEF_FORMAT_VERSION](#variable-prepared_beef_format_version) | [specOpThrowReviewActions](#variable-specopthrowreviewactions) |
| [DEFAULT_MANAGED_CHANGE_MIGRATION_INPUTS_PER_ACTION](#variable-default_managed_change_migration_inputs_per_action) | [ProvenTxReqNonTerminalStatus](#variable-proventxreqnonterminalstatus) | [specOpWalletBalance](#variable-specopwalletbalance) |
| [DEFAULT_MANAGED_CHANGE_MINIMUM_SATOSHIS](#variable-default_managed_change_minimum_satoshis) | [ProvenTxReqTerminalStatus](#variable-proventxreqterminalstatus) | [specOpWalletManagedUtxos](#variable-specopwalletmanagedutxos) |
| [DEFAULT_MANAGED_CHANGE_PENDING_COMPARISON_INPUTS](#variable-default_managed_change_pending_comparison_inputs) | [TESTNET_DEFAULT_SETTINGS](#variable-testnet_default_settings) | [transactionColumnsWithoutRawTx](#variable-transactioncolumnswithoutrawtx) |
| [DEFAULT_MANAGED_CHANGE_TARGET_UTXOS](#variable-default_managed_change_target_utxos) | [UTXO_PROVIDER_MAX_CONCURRENCY](#variable-utxo_provider_max_concurrency) | [transformVerifiableCertificatesWithTrust](#variable-transformverifiablecertificateswithtrust) |
| [DEFAULT_SETTINGS](#variable-default_settings) | [UTXO_REVIEW_PROVIDER_TIMEOUT_MSECS](#variable-utxo_review_provider_timeout_msecs) | [validBulkHeaderFiles](#variable-validbulkheaderfiles) |
| [LEGACY_MANAGED_CHANGE_MINIMUM_SATOSHIS](#variable-legacy_managed_change_minimum_satoshis) | [aggregateActionResults](#variable-aggregateactionresults) |  |
| [MAX_FIAT_FUTURE_SKEW_MS](#variable-max_fiat_future_skew_ms) | [brc29ProtocolID](#variable-brc29protocolid) |  |

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---

##### Variable: ACTION_BATCH_HARD_LIFETIME_MS

```ts
ACTION_BATCH_HARD_LIFETIME_MS = 60 * 60 * 1000
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: ACTION_BATCH_LEASE_MS

```ts
ACTION_BATCH_LEASE_MS = 15 * 60 * 1000
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: ACTION_BATCH_MAX_BLOB_BYTES

```ts
ACTION_BATCH_MAX_BLOB_BYTES = 8 * 1024 * 1024
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: ACTION_BATCH_MAX_CONCURRENT_UPLOADS

```ts
ACTION_BATCH_MAX_CONCURRENT_UPLOADS = 4
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: ACTION_BATCH_MAX_INLINE_BYTES

```ts
ACTION_BATCH_MAX_INLINE_BYTES = 4 * 1024 * 1024
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: ACTION_BATCH_MAX_PACK_BYTES

```ts
ACTION_BATCH_MAX_PACK_BYTES = 8 * 1024 * 1024
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: ACTION_BATCH_MAX_PACK_ITEMS

```ts
ACTION_BATCH_MAX_PACK_ITEMS = 4096
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: ACTION_BATCH_MAX_RESERVATION_EXTENSION_OUTPUTS

```ts
ACTION_BATCH_MAX_RESERVATION_EXTENSION_OUTPUTS = 64
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: ACTION_BATCH_MAX_RESERVED_OUTPUTS

```ts
ACTION_BATCH_MAX_RESERVED_OUTPUTS = 256
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: ACTION_BATCH_PACK_ENCODING_HEADER

```ts
ACTION_BATCH_PACK_ENCODING_HEADER = "X-BSV-Action-Batch-Encoding"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: ARCADE_POST_BEEF_CONCURRENCY

```ts
ARCADE_POST_BEEF_CONCURRENCY = 4
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: BRC177_NO_SEND_EXPIRY_PREFIX

```ts
BRC177_NO_SEND_EXPIRY_PREFIX = "p nosend expiry "
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: BRC177_NO_SEND_MODULE_PREFIX

```ts
BRC177_NO_SEND_MODULE_PREFIX = "p nosend "
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: DEFAULT_MANAGED_CHANGE_MAX_OUTPUTS_PER_ACTION

```ts
DEFAULT_MANAGED_CHANGE_MAX_OUTPUTS_PER_ACTION = 8
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: DEFAULT_MANAGED_CHANGE_MIGRATION_INPUTS_PER_ACTION

```ts
DEFAULT_MANAGED_CHANGE_MIGRATION_INPUTS_PER_ACTION = 4
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: DEFAULT_MANAGED_CHANGE_MINIMUM_SATOSHIS

```ts
DEFAULT_MANAGED_CHANGE_MINIMUM_SATOSHIS = 5000
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: DEFAULT_MANAGED_CHANGE_PENDING_COMPARISON_INPUTS

```ts
DEFAULT_MANAGED_CHANGE_PENDING_COMPARISON_INPUTS = 16
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: DEFAULT_MANAGED_CHANGE_TARGET_UTXOS

```ts
DEFAULT_MANAGED_CHANGE_TARGET_UTXOS = 144
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: DEFAULT_SETTINGS

```ts
DEFAULT_SETTINGS = {
    trustSettings: {
        trustLevel: 2,
        trustedCertifiers: [
            {
                name: "Metanet Trust Services",
                description: "Registry of protocols, baskets, certificate types",
                iconUrl: "https://bsvblockchain.org/favicon.ico",
                identityKey: "03daf815fe38f83da0ad83b5bedc520aa488aef5cbc93a93c67a7fe60406cbffe8",
                trust: 4
            },
            {
                name: "SocialCert",
                description: "Certifies social media handles, phones and emails",
                iconUrl: "https://socialcert.net/favicon.ico",
                trust: 3,
                identityKey: "02cf6cdf466951d8dfc9e7c9367511d0007ed6fba35ed42d425cc412fd6cfd4a17"
            }
        ]
    },
    theme: { mode: "dark" },
    permissionMode: "simple"
} as WalletSettings
```

See also: [WalletSettings](./client.md#interface-walletsettings)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: LEGACY_MANAGED_CHANGE_MINIMUM_SATOSHIS

```ts
LEGACY_MANAGED_CHANGE_MINIMUM_SATOSHIS = 32
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: MAX_FIAT_FUTURE_SKEW_MS

```ts
MAX_FIAT_FUTURE_SKEW_MS = 5 * 60 * 1000
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: MAX_FIAT_RATE

```ts
MAX_FIAT_RATE = 1000000000000000
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: MAX_FIAT_RESPONSE_RATES

```ts
MAX_FIAT_RESPONSE_RATES = 256
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: MAX_MONITOR_HEIGHT

```ts
MAX_MONITOR_HEIGHT = 2147483647
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: MAX_MONITOR_INTERVAL_MSECS

```ts
MAX_MONITOR_INTERVAL_MSECS = 365 * 24 * 60 * 60 * 1000
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: MAX_MONITOR_OFFSET

```ts
MAX_MONITOR_OFFSET = 2147483647
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: MAX_MONITOR_PAGE_SIZE

```ts
MAX_MONITOR_PAGE_SIZE = 1000
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: MAX_POST_BEEF_BYTES

```ts
MAX_POST_BEEF_BYTES = 64 * 1024 * 1024
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: MAX_POST_BEEF_TXIDS

```ts
MAX_POST_BEEF_TXIDS = Validation.MAXIMUM_SEND_WITH_TRANSACTIONS
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: MAX_RAW_TRANSACTION_BYTES

```ts
MAX_RAW_TRANSACTION_BYTES = 32 * 1024 * 1024
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: MAX_SCRIPT_HASH_HISTORY_ITEMS

```ts
MAX_SCRIPT_HASH_HISTORY_ITEMS = 4096
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: MAX_STORAGE_COMMISSION_SATOSHIS

```ts
MAX_STORAGE_COMMISSION_SATOSHIS = 500000
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: MAX_UTXO_REVIEW_CANDIDATES

```ts
MAX_UTXO_REVIEW_CANDIDATES = 10000
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: MAX_UTXO_STATUS_DETAILS

```ts
MAX_UTXO_STATUS_DETAILS = 4096
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: PREPARED_BEEF_FORMAT_VERSION

```ts
PREPARED_BEEF_FORMAT_VERSION = 1
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: ProvenTxReqNonTerminalStatus

```ts
ProvenTxReqNonTerminalStatus: ProvenTxReqStatus[] = [
    "sending",
    "unsent",
    "nosend",
    "unknown",
    "nonfinal",
    "unprocessed",
    "unmined",
    "callback",
    "unconfirmed"
]
```

See also: [ProvenTxReqStatus](./client.md#type-proventxreqstatus)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: ProvenTxReqTerminalStatus

```ts
ProvenTxReqTerminalStatus: ProvenTxReqStatus[] = ["completed", "invalid", "doubleSpend"]
```

See also: [ProvenTxReqStatus](./client.md#type-proventxreqstatus)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: TESTNET_DEFAULT_SETTINGS

```ts
TESTNET_DEFAULT_SETTINGS: WalletSettings = {
    ...DEFAULT_SETTINGS,
    trustSettings: {
        ...DEFAULT_SETTINGS.trustSettings,
        trustedCertifiers: DEFAULT_SETTINGS.trustSettings.trustedCertifiers.map(certifier => ({
            ...certifier,
            identityKey: TESTNET_IDENTITY_KEYS[certifier.name] || certifier.identityKey
        }))
    }
}
```

See also: [DEFAULT_SETTINGS](./client.md#variable-default_settings), [WalletSettings](./client.md#interface-walletsettings)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: UTXO_PROVIDER_MAX_CONCURRENCY

```ts
UTXO_PROVIDER_MAX_CONCURRENCY = 4
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: UTXO_REVIEW_PROVIDER_TIMEOUT_MSECS

```ts
UTXO_REVIEW_PROVIDER_TIMEOUT_MSECS = 5000
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: aggregateActionResults

```ts
aggregateActionResults = async (storage: StorageProvider, sendWithResultReqs: SendWithResult[], postToNetworkResult: PostReqsToNetworkResult): Promise<{
    swr: SendWithResult[];
    rar: ReviewActionResult[];
}> => {
    const swr: SendWithResult[] = [];
    const rar: ReviewActionResult[] = [];
    for (const ar of sendWithResultReqs) {
        const txid = ar.txid;
        const d = postToNetworkResult.details.find(d => d.txid === txid);
        if (d == null)
            throw new WERR_INTERNAL(`missing details for ${txid}`);
        const arNdr: ReviewActionResult = { txid: d.txid, status: "success", competingTxs: d.competingTxs };
        switch (d.status) {
            case "success":
                ar.status = "unproven";
                break;
            case "doubleSpend":
                ar.status = "failed";
                arNdr.status = "doubleSpend";
                if (d.competingTxs != null)
                    arNdr.competingBeef = await createMergedBeefOfTxids(d.competingTxs, storage);
                break;
            case "serviceError":
                ar.status = "sending";
                arNdr.status = "serviceError";
                break;
            case "invalidTx":
                ar.status = "failed";
                arNdr.status = "invalidTx";
                break;
            case "unknown":
            case "invalid":
            default:
                throw new WERR_INTERNAL(`processAction with notDelayed status ${d.status} should not occur.`);
        }
        swr.push({ txid, status: ar.status });
        rar.push(arNdr);
    }
    return { swr, rar };
}
```

See also: [PostReqsToNetworkResult](./storage.md#interface-postreqstonetworkresult), [ReviewActionResult](./client.md#interface-reviewactionresult), [StorageProvider](./storage.md#class-storageprovider), [WERR_INTERNAL](./client.md#class-werr_internal), [processAction](./storage.md#function-processaction)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: brc29ProtocolID

```ts
brc29ProtocolID: WalletProtocol = [2, "3241645161d8"]
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: dirtyHashes

```ts
dirtyHashes = {
    "00000000000000000019f112ec0a9982926f1258cdcc558dd7c3b7e5dc7fa148": "This is the first header of the invalid SegWit chain.",
    "0000000000000000004626ff6e3b936941d341c5932ece4357eeccac44e6d56c": "This is the first header of the invalid ABC chain."
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: exactActionSpendSymbol

```ts
exactActionSpendSymbol = Symbol.for("@bsv/wallet-toolbox/exact-action-spend")
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: logger

```ts
logger = (message: string, ...optionalParams: any[]): void => {
    const isSingleTest = process.argv.some(arg => arg === "--testNamePattern" || arg === "-t");
    if (isSingleTest) {
        console.log(message, ...optionalParams);
    }
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: managedChangeOutputFields

```ts
managedChangeOutputFields = {
    type: "P2PKH",
    change: true,
    providedBy: "storage",
    purpose: "change"
} as const
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: maxChangeOutputsPerTransaction

```ts
maxChangeOutputsPerTransaction = 8
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: maxPossibleSatoshis

```ts
maxPossibleSatoshis = 2099999999999999
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: outputColumnsWithoutLockingScript

```ts
outputColumnsWithoutLockingScript = [
    "created_at",
    "updated_at",
    "outputId",
    "userId",
    "transactionId",
    "basketId",
    "spendable",
    "change",
    "vout",
    "satoshis",
    "providedBy",
    "purpose",
    "type",
    "outputDescription",
    "txid",
    "senderIdentityKey",
    "derivationPrefix",
    "derivationSuffix",
    "customInstructions",
    "spentBy",
    "sequenceNumber",
    "spendingDescription",
    "scriptLength",
    "scriptOffset"
]
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: parseResults

```ts
parseResults = async (lookupResult: LookupAnswer): Promise<VerifiableCertificate[]> => {
    if (lookupResult.type !== "output-list")
        return [];
    if (!Array.isArray(lookupResult.outputs) || lookupResult.outputs.length > MAX_IDENTITY_RESULTS)
        return [];
    const parsedResults: VerifiableCertificate[] = [];
    const seen = new Set<string>();
    const shouldYield = isUiRuntime();
    for (const output of lookupResult.outputs) {
        if (shouldYield)
            await yieldToUi();
        const cert = await parseOne(output);
        if (cert != null) {
            const certificateID = `${cert.subject}\0${cert.certifier}\0${cert.type}\0${cert.serialNumber}`;
            if (!seen.has(certificateID)) {
                seen.add(certificateID);
                parsedResults.push(cert);
            }
        }
    }
    return parsedResults;
}
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: queryOverlay

```ts
queryOverlay = async (query: unknown, resolver: LookupResolver): Promise<VerifiableCertificate[]> => {
    const results = await resolver.query({
        service: "ls_identity",
        query
    }, undefined, { graceMs: 300 });
    return await parseResults(results);
}
```

See also: [parseResults](./client.md#variable-parseresults)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: specOpFailedActions

```ts
specOpFailedActions = "97d4eb1e49215e3374cc2c1939a7c43a55e95c7427bf2d45ed63e3b4e0c88153"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: specOpInvalidChange

```ts
specOpInvalidChange = "5a76fd430a311f8bc0553859061710a4475c19fed46e2ff95969aa918e612e57"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: specOpNoSendActions

```ts
specOpNoSendActions = "ac6b20a3bb320adafecd637b25c84b792ad828d3aa510d05dc841481f664277d"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: specOpSetWalletChangeParams

```ts
specOpSetWalletChangeParams = "a4979d28ced8581e9c1c92f1001cc7cb3aabf8ea32e10888ad898f0a509a3929"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: specOpThrowReviewActions

```ts
specOpThrowReviewActions = "a496e747fc3ad5fabdd4ae8f91184e71f87539bd3d962aa2548942faaaf0047a"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: specOpWalletBalance

```ts
specOpWalletBalance = "893b7646de0e1c9f741bd6e9169b76a8847ae34adef7bef1e6a285371206d2e8"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: specOpWalletManagedUtxos

```ts
specOpWalletManagedUtxos = "284570a6213a74ba861c38b1cf790e1e400d9cf9324454b76ea98860b6031c1a"
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: transactionColumnsWithoutRawTx

```ts
transactionColumnsWithoutRawTx = [
    "created_at",
    "updated_at",
    "transactionId",
    "userId",
    "provenTxId",
    "status",
    "reference",
    "isOutgoing",
    "satoshis",
    "version",
    "lockTime",
    "description",
    "txid",
    "noSendExpiryMode",
    "noSendExpiryValue",
    "noSendExpiryDeadline",
    "noSendExpiryState",
    "noSendExpiryAnchorTxid",
    "noSendExpiryAnchorVout",
    "noSendExpiryReleasedAt",
    "noSendExpiryObservedAt",
    "noSendExpiryReclaimTxid",
    "noSendExpiryReclaimDerivationPrefix",
    "noSendExpiryReclaimDerivationSuffix",
    "noSendExpiryReclaimSatoshis"
]
```

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: transformVerifiableCertificatesWithTrust

```ts
transformVerifiableCertificatesWithTrust = (trustSettings: TrustSettings, certificates: VerifiableCertificate[]): DiscoverCertificatesResult => {
    const validatedTrust = validateTrustSettings(trustSettings);
    const identityGroups = new Map<string, IdentityGroup>();
    const certifierCache = new Map(validatedTrust.trustedCertifiers.map(certifier => [certifier.identityKey, certifier] as const));
    certificates.slice(0, MAX_IDENTITY_RESULTS).forEach(cert => {
        const { subject, certifier } = cert;
        if (subject === "" || certifier === "")
            return;
        const trustedCertifier = certifierCache.get(certifier);
        if (trustedCertifier == null)
            return;
        const certifierInfo: IdentityCertifier = {
            name: trustedCertifier.name,
            iconUrl: trustedCertifier.iconUrl ?? "https://bsvblockchain.org/favicon.ico",
            description: trustedCertifier.description,
            trust: trustedCertifier.trust
        };
        const extendedCert: IdentityCertificate = {
            type: cert.type,
            serialNumber: cert.serialNumber,
            subject: cert.subject,
            certifier: cert.certifier,
            revocationOutpoint: cert.revocationOutpoint,
            signature: cert.signature as string,
            fields: { ...cert.fields },
            decryptedFields: { ...cert.decryptedFields } as Record<string, string>,
            publiclyRevealedKeyring: { ...cert.keyring },
            certifierInfo
        };
        let group = identityGroups.get(subject);
        if (group == null) {
            group = { totalTrust: 0, members: [], certifiers: new Set(), certificates: new Set() };
            identityGroups.set(subject, group);
        }
        const certificateID = `${cert.type}\0${cert.serialNumber}\0${certifier}`;
        if (group.certificates.has(certificateID))
            return;
        group.certificates.add(certificateID);
        if (!group.certifiers.has(certifier)) {
            group.certifiers.add(certifier);
            group.totalTrust += certifierInfo.trust;
        }
        group.members.push(extendedCert);
    });
    const finalResults: ExtendedVerifiableCertificate[] = [];
    identityGroups.forEach(group => {
        if (group.totalTrust >= validatedTrust.trustLevel) {
            finalResults.push(...group.members);
        }
    });
    finalResults.sort((a, b) => b.certifierInfo.trust - a.certifierInfo.trust);
    return {
        totalCertificates: finalResults.length,
        certificates: finalResults
    };
}
```

See also: [ExtendedVerifiableCertificate](./client.md#interface-extendedverifiablecertificate), [TrustSettings](./client.md#interface-trustsettings), [validateTrustSettings](./client.md#function-validatetrustsettings)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
##### Variable: validBulkHeaderFiles

```ts
validBulkHeaderFiles: BulkHeaderFileInfo[] = [
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_0.headers",
        firstHeight: 0,
        prevHash: "0000000000000000000000000000000000000000000000000000000000000000",
        count: 100000,
        lastHash: "000000004956cc2edd1a8caa05eacfa3c69f4c490bfc9ace820257834115ab35",
        fileHash: "gAJPUfI2DfAabJTOBxT1rwy1cS4/QULaQHaQWa1RWNk=",
        lastChainWork: "000000000000000000000000000000000000000000000000004143c00b3d47b8",
        prevChainWork: "0000000000000000000000000000000000000000000000000000000000000000",
        chain: "test",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_1.headers",
        firstHeight: 100000,
        prevHash: "000000004956cc2edd1a8caa05eacfa3c69f4c490bfc9ace820257834115ab35",
        count: 100000,
        lastHash: "0000000000c470c4a573272aa4a680c93fc4c2f5df8ce9546441796f73277334",
        fileHash: "OIJ010bnIbFobNppJzCNE9jFI1uANz0iNGvqpoG2xq4=",
        lastChainWork: "00000000000000000000000000000000000000000000000004504f3a4e71aa13",
        prevChainWork: "000000000000000000000000000000000000000000000000004143c00b3d47b8",
        chain: "test",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_2.headers",
        firstHeight: 200000,
        prevHash: "0000000000c470c4a573272aa4a680c93fc4c2f5df8ce9546441796f73277334",
        count: 100000,
        lastHash: "00000000dfe970844d1bf983d0745f709368b5c66224837a17ed633f0dabd300",
        fileHash: "hZXE3im7V4tE0oROWM2mGB9xPXEcpVLRIYUPaYT3VV0=",
        lastChainWork: "00000000000000000000000000000000000000000000000062378b066f9fba96",
        prevChainWork: "00000000000000000000000000000000000000000000000004504f3a4e71aa13",
        chain: "test",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_3.headers",
        firstHeight: 300000,
        prevHash: "00000000dfe970844d1bf983d0745f709368b5c66224837a17ed633f0dabd300",
        count: 100000,
        lastHash: "0000000001127c76ac45f605f9300dfa96a8054533b96413883fdc4378aeb42d",
        fileHash: "BGZxsk/Ooa4BOaoBEMOor+B8wL9ghW5A0We2G2fmyLE=",
        lastChainWork: "0000000000000000000000000000000000000000000000040da9d61d8e129a53",
        prevChainWork: "00000000000000000000000000000000000000000000000062378b066f9fba96",
        chain: "test",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_4.headers",
        firstHeight: 400000,
        prevHash: "0000000001127c76ac45f605f9300dfa96a8054533b96413883fdc4378aeb42d",
        count: 100000,
        lastHash: "0000000001965655a870175b510326e6393114d293896ddb237709eecb381ab8",
        fileHash: "3DjOpFnatZ0OKrpACATfAtBITX2s8JjfYTAnDHVkGuw=",
        lastChainWork: "00000000000000000000000000000000000000000000000461063a8389300d36",
        prevChainWork: "0000000000000000000000000000000000000000000000040da9d61d8e129a53",
        chain: "test",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_5.headers",
        firstHeight: 500000,
        prevHash: "0000000001965655a870175b510326e6393114d293896ddb237709eecb381ab8",
        count: 100000,
        lastHash: "000000000000bb1644b4d9a643b165a52b3ffba077f2a12b8bd1f0a6b6cc0fbc",
        fileHash: "wF008GqnZzAYsOwnmyFzIOmrJthHE3bq6oUg1FvHG1Y=",
        lastChainWork: "0000000000000000000000000000000000000000000000067a8291cfec0aa549",
        prevChainWork: "00000000000000000000000000000000000000000000000461063a8389300d36",
        chain: "test",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_6.headers",
        firstHeight: 600000,
        prevHash: "000000000000bb1644b4d9a643b165a52b3ffba077f2a12b8bd1f0a6b6cc0fbc",
        count: 100000,
        lastHash: "0000000000003e784511e93aca014ecaa6d4ba3637cf373f4b84dcac7c70cca0",
        fileHash: "uc7IW6NRXXtX3oGWwOYjtetTaZ+1zhvijNEwPbK+rAs=",
        lastChainWork: "0000000000000000000000000000000000000000000000078286c7f42f7ec693",
        prevChainWork: "0000000000000000000000000000000000000000000000067a8291cfec0aa549",
        chain: "test",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_7.headers",
        firstHeight: 700000,
        prevHash: "0000000000003e784511e93aca014ecaa6d4ba3637cf373f4b84dcac7c70cca0",
        count: 100000,
        lastHash: "0000000000068f8658ff71cbf8f5b31c837cc6df5bf53e40f05459d4267b53e6",
        fileHash: "yfomaIGZyoW/m7YdpZYNozeNrUmJBwaF0PpLdSADWJE=",
        lastChainWork: "00000000000000000000000000000000000000000000000a551ea869597d2a74",
        prevChainWork: "0000000000000000000000000000000000000000000000078286c7f42f7ec693",
        chain: "test",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_8.headers",
        firstHeight: 800000,
        prevHash: "0000000000068f8658ff71cbf8f5b31c837cc6df5bf53e40f05459d4267b53e6",
        count: 100000,
        lastHash: "0000000000214fbb71abe4695d935b8e089d306899c4a90124b1bc6806e6e299",
        fileHash: "/AIS2PYHdMJBmRF9ECsZmCphoqhDyFWs+aO+3GIpPhg=",
        lastChainWork: "00000000000000000000000000000000000000000000000eb93c12a85efec237",
        prevChainWork: "00000000000000000000000000000000000000000000000a551ea869597d2a74",
        chain: "test",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_9.headers",
        firstHeight: 900000,
        prevHash: "0000000000214fbb71abe4695d935b8e089d306899c4a90124b1bc6806e6e299",
        count: 100000,
        lastHash: "00000000002208a5fee5b9baa4b5519d2cd8ab405754fca13704dc667448f21a",
        fileHash: "lJtRGLYlMnHe6r0xuJJWauJA7DKL4ZYOqkYmUD2iwbM=",
        lastChainWork: "000000000000000000000000000000000000000000000017e96a5ada9f4a8bfb",
        prevChainWork: "00000000000000000000000000000000000000000000000eb93c12a85efec237",
        chain: "test",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_10.headers",
        firstHeight: 1000000,
        prevHash: "00000000002208a5fee5b9baa4b5519d2cd8ab405754fca13704dc667448f21a",
        count: 100000,
        lastHash: "000000000005bc8878ba47a47129c3e21f32f8c10b9658f9ee6db16a83870162",
        fileHash: "tfWVFoIp4A6yXd2c0YietQ7hYlmLf7O884baego+D4E=",
        lastChainWork: "000000000000000000000000000000000000000000000021bf46518c698a4bc8",
        prevChainWork: "000000000000000000000000000000000000000000000017e96a5ada9f4a8bfb",
        chain: "test",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_11.headers",
        firstHeight: 1100000,
        prevHash: "000000000005bc8878ba47a47129c3e21f32f8c10b9658f9ee6db16a83870162",
        count: 100000,
        lastHash: "00000000f8bf61018ddd77d23c112e874682704a290252f635e7df06c8a317b8",
        fileHash: "S0Y9WXGFFJLRsRkQRNvrtImOezjReEQ1eDdB2x5M6Mw=",
        lastChainWork: "0000000000000000000000000000000000000000000000288b285ca9b1bb8065",
        prevChainWork: "000000000000000000000000000000000000000000000021bf46518c698a4bc8",
        chain: "test",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_12.headers",
        firstHeight: 1200000,
        prevHash: "00000000f8bf61018ddd77d23c112e874682704a290252f635e7df06c8a317b8",
        count: 100000,
        lastHash: "0000000000000165e6678be46ec2b15c587611b86da7147f7069a0e7175d62da",
        fileHash: "eFHQB8EaSfs4EKZxVsLhX8UA79kpOI4dR6j/z9P8frI=",
        lastChainWork: "0000000000000000000000000000000000000000000000542144c6af6e9258ea",
        prevChainWork: "0000000000000000000000000000000000000000000000288b285ca9b1bb8065",
        chain: "test",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_13.headers",
        firstHeight: 1300000,
        prevHash: "0000000000000165e6678be46ec2b15c587611b86da7147f7069a0e7175d62da",
        count: 100000,
        lastHash: "00000000000002ef0a47d0f242ab280bded8f4780bad506c71f2e1d2771becd4",
        fileHash: "2MFJLBjHOBnuaDAICQFCL3y+6ejj0k92gbcmLWa1/Xc=",
        lastChainWork: "0000000000000000000000000000000000000000000000dcc85f546d353f7b08",
        prevChainWork: "0000000000000000000000000000000000000000000000542144c6af6e9258ea",
        chain: "test",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_14.headers",
        firstHeight: 1400000,
        prevHash: "00000000000002ef0a47d0f242ab280bded8f4780bad506c71f2e1d2771becd4",
        count: 100000,
        lastHash: "0000000000000168de8736c8a424fd5ebe1dcf0a030ed5fa0699b8c0fafc0b5e",
        fileHash: "lWmP/pOR5ciEnu5tjIrf7OTEaiaMcfqFZQQYT7QH6qg=",
        lastChainWork: "00000000000000000000000000000000000000000000011bed7ab81a56a65cbc",
        prevChainWork: "0000000000000000000000000000000000000000000000dcc85f546d353f7b08",
        chain: "test",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "testNet_15.headers",
        firstHeight: 1500000,
        prevHash: "0000000000000168de8736c8a424fd5ebe1dcf0a030ed5fa0699b8c0fafc0b5e",
        count: 100000,
        lastHash: "00000000000005504bfd1a3ce4688c30c86740390102b6cd464a2fb5e0e3fed1",
        fileHash: "1bCf0R0RsoadANX+6H4NH1b3jNuTPyTayoS1SpQXa2Q=",
        lastChainWork: "000000000000000000000000000000000000000000000156c3b84396da4e60b9",
        prevChainWork: "00000000000000000000000000000000000000000000011bed7ab81a56a65cbc",
        chain: "test",
        validated: true
    },
    {
        chain: "test",
        count: 100000,
        fileHash: "qPjPA41mUU0ieEqud/JO95Agqq8XgzbzS5FLnHIRyPA=",
        fileName: "testNet_16.headers",
        firstHeight: 1600000,
        lastChainWork: "00000000000000000000000000000000000000000000015814b9c82dabd4ea74",
        lastHash: "000000000001561e0532f48401f822f5c0d8797e364b1d612a317eca6983ca36",
        prevChainWork: "000000000000000000000000000000000000000000000156c3b84396da4e60b9",
        prevHash: "00000000000005504bfd1a3ce4688c30c86740390102b6cd464a2fb5e0e3fed1",
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        validated: true
    },
    {
        chain: "test",
        count: 28130,
        fileHash: "2DNTS2vBk4ddDzVz5MbFfRtxuze4FN4wrtKfaxbfC98=",
        fileName: "testNet_17.headers",
        firstHeight: 1700000,
        lastChainWork: "0000000000000000000000000000000000000000000001581bdf712d6fabd4da",
        lastHash: "0000000072d02bc85e05ff155357fbbde7fe80057c4f9354fe5535147de00687",
        prevChainWork: "00000000000000000000000000000000000000000000015814b9c82dabd4ea74",
        prevHash: "000000000001561e0532f48401f822f5c0d8797e364b1d612a317eca6983ca36",
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders"
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "mainNet_0.headers",
        firstHeight: 0,
        prevHash: "0000000000000000000000000000000000000000000000000000000000000000",
        count: 100000,
        lastHash: "000000000002d01c1fccc21636b607dfd930d31d01c3a62104612a1719011250",
        fileHash: "DMXYETHMphmYRh5y0+qsJhj67ML5Ui4LE1eEZDYbnZE=",
        lastChainWork: "000000000000000000000000000000000000000000000000064492eaf00f2520",
        prevChainWork: "0000000000000000000000000000000000000000000000000000000000000000",
        chain: "main",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "mainNet_1.headers",
        firstHeight: 100000,
        prevHash: "000000000002d01c1fccc21636b607dfd930d31d01c3a62104612a1719011250",
        count: 100000,
        lastHash: "00000000000003a20def7a05a77361b9657ff954b2f2080e135ea6f5970da215",
        fileHash: "IID8O84Uny22i10fWHTQr6f9+9eFZ8dhVyegYPGSg+Q=",
        lastChainWork: "00000000000000000000000000000000000000000000001ac0479f335782cb80",
        prevChainWork: "000000000000000000000000000000000000000000000000064492eaf00f2520",
        chain: "main",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "mainNet_2.headers",
        firstHeight: 200000,
        prevHash: "00000000000003a20def7a05a77361b9657ff954b2f2080e135ea6f5970da215",
        count: 100000,
        lastHash: "000000000000000067ecc744b5ae34eebbde14d21ca4db51652e4d67e155f07e",
        fileHash: "wbfV/ZuPvLKHtRJN4QlHiKlpNncuqWA1dMJ6O9mhisc=",
        lastChainWork: "000000000000000000000000000000000000000000005a795f5d6ede10bc6d60",
        prevChainWork: "00000000000000000000000000000000000000000000001ac0479f335782cb80",
        chain: "main",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "mainNet_3.headers",
        firstHeight: 300000,
        prevHash: "000000000000000067ecc744b5ae34eebbde14d21ca4db51652e4d67e155f07e",
        count: 100000,
        lastHash: "0000000000000000030034b661aed920a9bdf6bbfa6d2e7a021f78481882fa39",
        fileHash: "5pklz64as2MG6y9lQiiClZaA82f6xoK1xdzkSqOZLsA=",
        lastChainWork: "0000000000000000000000000000000000000000001229fea679a4cdc26e7460",
        prevChainWork: "000000000000000000000000000000000000000000005a795f5d6ede10bc6d60",
        chain: "main",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "mainNet_4.headers",
        firstHeight: 400000,
        prevHash: "0000000000000000030034b661aed920a9bdf6bbfa6d2e7a021f78481882fa39",
        count: 100000,
        lastHash: "0000000000000000043831d6ebb013716f0580287ee5e5687e27d0ed72e6e523",
        fileHash: "2X78/S+Z/h5ELA63aC3xt6/o4G8JMcAOEiZ00ycKHsM=",
        lastChainWork: "0000000000000000000000000000000000000000007ae4707601d47bc6695487",
        prevChainWork: "0000000000000000000000000000000000000000001229fea679a4cdc26e7460",
        chain: "main",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "mainNet_5.headers",
        firstHeight: 500000,
        prevHash: "0000000000000000043831d6ebb013716f0580287ee5e5687e27d0ed72e6e523",
        count: 100000,
        lastHash: "0000000000000000078f57b9a986b53b73f007c6b27b6f16409ca4eda83034e8",
        fileHash: "Tzm60n66tIuq7wNdP6M1BH77iFzGCPbOMIl6smJ/LRg=",
        lastChainWork: "000000000000000000000000000000000000000000e8f2ea21f069a214067ed7",
        prevChainWork: "0000000000000000000000000000000000000000007ae4707601d47bc6695487",
        chain: "main",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "mainNet_6.headers",
        firstHeight: 600000,
        prevHash: "0000000000000000078f57b9a986b53b73f007c6b27b6f16409ca4eda83034e8",
        count: 100000,
        lastHash: "000000000000000013abf3ab026610ed70e023476db8ce96f68637acdcbcf3cb",
        fileHash: "O7SoyIDxhejB0Qs4rBO4OkfBK2yVZKhxra6YxZMhiIk=",
        lastChainWork: "0000000000000000000000000000000000000000012f32fb33b26aa239be0fc3",
        prevChainWork: "000000000000000000000000000000000000000000e8f2ea21f069a214067ed7",
        chain: "main",
        validated: true
    },
    {
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        fileName: "mainNet_7.headers",
        firstHeight: 700000,
        prevHash: "000000000000000013abf3ab026610ed70e023476db8ce96f68637acdcbcf3cb",
        count: 100000,
        lastHash: "00000000000000000b6ae23bbe9f549844c20943d8c20b8ceedbae8aa1dde8e0",
        fileHash: "+0Wu2GrKgCv4o1yZfdWl60aAgvBj6Rt3xlWj8TQprUw=",
        lastChainWork: "000000000000000000000000000000000000000001483b2995af390c20b58320",
        prevChainWork: "0000000000000000000000000000000000000000012f32fb33b26aa239be0fc3",
        chain: "main",
        validated: true
    },
    {
        chain: "main",
        count: 100000,
        fileHash: "xKYCsMzfbWdwq6RtEos4+4w7F3FroFMXb4tk4Z2gn5s=",
        fileName: "mainNet_8.headers",
        firstHeight: 800000,
        lastChainWork: "000000000000000000000000000000000000000001664db1f2d50327928007e0",
        lastHash: "00000000000000000e7dcc27c06ee353bd37260b2e7e664314c204f0324a5087",
        prevChainWork: "000000000000000000000000000000000000000001483b2995af390c20b58320",
        prevHash: "00000000000000000b6ae23bbe9f549844c20943d8c20b8ceedbae8aa1dde8e0",
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders",
        validated: true
    },
    {
        chain: "main",
        count: 42761,
        fileHash: "iWZR7qvenqLKHANygKBBnikqmiW8GCoVCN7zjVXwgwY=",
        fileName: "mainNet_9.headers",
        firstHeight: 900000,
        lastChainWork: "0000000000000000000000000000000000000000016bf64e6fb83417f3b94c86",
        lastHash: "0000000000000000108a6b142072acf8a781d5fcdd1c9a637d2194ad6b9c09dc",
        prevChainWork: "000000000000000000000000000000000000000001664db1f2d50327928007e0",
        prevHash: "00000000000000000e7dcc27c06ee353bd37260b2e7e664314c204f0324a5087",
        sourceUrl: "https://cdn.projectbabbage.com/blockheaders"
    }
]
```

See also: [BulkHeaderFileInfo](./services.md#interface-bulkheaderfileinfo)

Links: [API](#api), [Interfaces](#interfaces), [Classes](#classes), [Functions](#functions), [Types](#types), [Variables](#variables)

---
